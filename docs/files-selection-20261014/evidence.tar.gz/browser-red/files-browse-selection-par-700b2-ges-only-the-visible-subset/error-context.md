# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: files-browse-selection.spec.ts >> partial visible selection is mixed and select-all changes only the visible subset
- Location: apps/web/tests/browser/files-browse-selection.spec.ts:75:1

# Error details

```
Error: expect(locator).toHaveJSProperty(expected) failed

Locator:  getByRole('checkbox', { name: 'Select visible files', exact: true })
Expected: true
Received: false
Timeout:  5000ms

Call log:
  - Expect "toHaveJSProperty" with timeout 5000ms
  - waiting for getByRole('checkbox', { name: 'Select visible files', exact: true })
    14 × locator resolved to <input type="checkbox" aria-label="Select visible files"/>
       - unexpected value "false"

```

```yaml
- checkbox "Select visible files"
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | import { clientId, installFixtures, json } from "./fixtures";
  3   | import { nativeFile } from "./capability-documents-fixtures";
  4   | 
  5   | const documents = [
  6   |   {
  7   |     ...nativeFile,
  8   |     fileName: "Alpha report.txt",
  9   |     folder: "Reports",
  10  |     source: "manual",
  11  |   },
  12  |   {
  13  |     ...nativeFile,
  14  |     id: "60000000-0000-4000-8000-000000000002",
  15  |     fileName: "Beta report.txt",
  16  |     folder: "Reports",
  17  |     source: "manual",
  18  |   },
  19  |   {
  20  |     ...nativeFile,
  21  |     id: "60000000-0000-4000-8000-000000000003",
  22  |     fileName: "Gamma memo.txt",
  23  |     folder: null,
  24  |     source: "workspace",
  25  |   },
  26  | ];
  27  | async function fixtures(page: Page) {
  28  |   const unexpected = await installFixtures(page);
  29  |   const writes: string[] = [];
  30  |   let reads = 0;
  31  |   page.on("request", (request) => {
  32  |     if (request.url().includes("/api/backend/") && request.method() !== "GET")
  33  |       writes.push(`${request.method()} ${request.url()}`);
  34  |   });
  35  |   await page.route("**/core/engagement/attachments?**", (route) => {
  36  |     reads++;
  37  |     return json(route, documents);
  38  |   });
  39  |   await page.goto(`/portfolio/${clientId}/files`);
  40  |   await expect(
  41  |     page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
  42  |   ).toHaveCount(3);
  43  |   return { writes, unexpected, reads: () => reads };
  44  | }
  45  | const allFiles = (page: Page) =>
  46  |   page
  47  |     .getByRole("group", { name: "File view", exact: true })
  48  |     .getByRole("button", { name: "All files", exact: true });
  49  | const visibleSelection = (page: Page) =>
  50  |   page.getByRole("checkbox", { name: "Select visible files", exact: true });
  51  | 
  52  | for (const folder of ["Reports 2", "Unfiled 1"]) {
  53  |   test(`All files leaves ${folder} and restores the complete current list`, async ({
  54  |     page,
  55  |   }) => {
  56  |     const { writes, unexpected, reads } = await fixtures(page);
  57  |     await page.getByRole("button", { name: folder, exact: true }).click();
  58  |     await expect(
  59  |       page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
  60  |     ).toHaveCount(folder.startsWith("Reports") ? 2 : 1);
  61  |     await allFiles(page).focus();
  62  |     await page.keyboard.press("Enter");
  63  |     await expect(
  64  |       page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
  65  |     ).toHaveCount(3);
  66  |     await expect(
  67  |       page.getByRole("region", { name: "All client files", exact: true }),
  68  |     ).toBeVisible();
  69  |     expect(reads()).toBe(1);
  70  |     expect(writes).toEqual([]);
  71  |     expect(unexpected).toEqual([]);
  72  |   });
  73  | }
  74  | 
  75  | test("partial visible selection is mixed and select-all changes only the visible subset", async ({
  76  |   page,
  77  | }, info) => {
  78  |   const { writes, unexpected, reads } = await fixtures(page);
  79  |   await page
  80  |     .getByRole("checkbox", { name: "Select Alpha report.txt", exact: true })
  81  |     .check();
> 82  |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", true);
      |                                        ^ Error: expect(locator).toHaveJSProperty(expected) failed
  83  |   await visibleSelection(page).focus();
  84  |   await page.keyboard.press("Space");
  85  |   for (const file of documents)
  86  |     await expect(
  87  |       page.getByRole("checkbox", {
  88  |         name: `Select ${file.fileName}`,
  89  |         exact: true,
  90  |       }),
  91  |     ).toBeChecked();
  92  |   await page.getByLabel("Search files", { exact: true }).fill("Gamma");
  93  |   await expect(visibleSelection(page)).toBeChecked();
  94  |   await visibleSelection(page).uncheck();
  95  |   await expect(
  96  |     page.getByText("1 files · 2 selected · 2 outside this view", {
  97  |       exact: true,
  98  |     }),
  99  |   ).toBeVisible();
  100 |   await expect(visibleSelection(page)).not.toBeChecked();
  101 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", false);
  102 |   await page.screenshot({
  103 |     path: info.outputPath("hidden-selection-desktop.png"),
  104 |     fullPage: true,
  105 |   });
  106 |   await page.getByLabel("Search files", { exact: true }).fill("");
  107 |   await expect(
  108 |     page.getByRole("checkbox", {
  109 |       name: "Select Alpha report.txt",
  110 |       exact: true,
  111 |     }),
  112 |   ).toBeChecked();
  113 |   await expect(
  114 |     page.getByRole("checkbox", { name: "Select Beta report.txt", exact: true }),
  115 |   ).toBeChecked();
  116 |   await expect(
  117 |     page.getByRole("checkbox", { name: "Select Gamma memo.txt", exact: true }),
  118 |   ).not.toBeChecked();
  119 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", true);
  120 |   await page
  121 |     .getByRole("button", { name: "Clear selection", exact: true })
  122 |     .click();
  123 |   await expect(visibleSelection(page)).not.toBeChecked();
  124 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", false);
  125 |   for (const file of documents)
  126 |     await expect(
  127 |       page.getByRole("checkbox", {
  128 |         name: `Select ${file.fileName}`,
  129 |         exact: true,
  130 |       }),
  131 |     ).not.toBeChecked();
  132 |   expect(reads()).toBe(1);
  133 |   expect(writes).toEqual([]);
  134 |   expect(unexpected).toEqual([]);
  135 | });
  136 | 
  137 | test("empty filtered results disclose and clear hidden selection without changing filters or writing", async ({
  138 |   page,
  139 | }, info) => {
  140 |   const { writes, unexpected, reads } = await fixtures(page);
  141 |   await page.setViewportSize({ width: 390, height: 844 });
  142 |   await page.emulateMedia({ colorScheme: "dark" });
  143 |   await page
  144 |     .getByRole("checkbox", { name: "Select Alpha report.txt", exact: true })
  145 |     .check();
  146 |   await page.getByLabel("Search files", { exact: true }).fill("No match");
  147 |   await expect(visibleSelection(page)).toBeDisabled();
  148 |   await expect(
  149 |     page.getByText("0 files · 1 selected · 1 outside this view", {
  150 |       exact: true,
  151 |     }),
  152 |   ).toBeVisible();
  153 |   const clear = page.getByRole("button", {
  154 |     name: "Clear selection",
  155 |     exact: true,
  156 |   });
  157 |   await clear.focus();
  158 |   expect(
  159 |     await page.evaluate(
  160 |       () => document.documentElement.scrollWidth <= innerWidth,
  161 |     ),
  162 |   ).toBe(true);
  163 |   await page.evaluate(() => window.scrollTo(0, 0));
  164 |   await page.screenshot({
  165 |     path: info.outputPath("hidden-selection-mobile-dark.png"),
  166 |     fullPage: true,
  167 |   });
  168 |   await clear.focus();
  169 |   await page.keyboard.press("Enter");
  170 |   await expect(page.getByLabel("Search files", { exact: true })).toHaveValue(
  171 |     "No match",
  172 |   );
  173 |   await expect(
  174 |     page.getByRole("button", { name: "Move to folder", exact: true }),
  175 |   ).toBeDisabled();
  176 |   await expect(
  177 |     page.getByRole("button", { name: "New folder", exact: true }),
  178 |   ).toBeDisabled();
  179 |   await expect(
  180 |     page.getByText("0 files · 0 selected", { exact: true }),
  181 |   ).toBeVisible();
  182 |   expect(reads()).toBe(1);
```