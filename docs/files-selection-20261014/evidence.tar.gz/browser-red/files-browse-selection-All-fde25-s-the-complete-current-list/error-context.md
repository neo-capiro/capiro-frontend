# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: files-browse-selection.spec.ts >> All files leaves Unfiled 1 and restores the complete current list
- Location: apps/web/tests/browser/files-browse-selection.spec.ts:53:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('checkbox', { name: /^Select (Alpha|Beta|Gamma)/ })
Expected: 3
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByRole('checkbox', { name: /^Select (Alpha|Beta|Gamma)/ })
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - link "Capiro Home" [ref=e5] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e6]
    - navigation "Workspace" [ref=e7]:
      - link "Meri" [ref=e8] [cursor=pointer]:
        - /url: /meri
      - link "Portfolio" [ref=e9] [cursor=pointer]:
        - /url: /
      - link "Modules" [ref=e10] [cursor=pointer]:
        - /url: /modules
    - navigation "Global actions" [ref=e11]:
      - link "Quick log" [ref=e12] [cursor=pointer]:
        - /url: /portfolio/10000000-0000-4000-8000-000000000001?log=1
      - link "Master calendar" [ref=e13] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e15]
      - button "Test account" [ref=e17] [cursor=pointer]: T
  - generic [ref=e18]:
    - complementary "Portfolio navigation" [ref=e19]:
      - paragraph [ref=e20]: Portfolio
      - navigation "Portfolio" [ref=e21]:
        - link "Portfolio Overview" [ref=e22] [cursor=pointer]:
          - /url: /portfolio
          - generic [ref=e23]: Overview
        - link "Portfolio Clients" [ref=e24] [cursor=pointer]:
          - /url: /portfolio?type=CLIENT
          - generic [ref=e25]: Clients
        - link "Portfolio Prospects" [ref=e26] [cursor=pointer]:
          - /url: /portfolio/prospects
          - generic [ref=e27]: Prospects
      - separator [ref=e28]
      - paragraph [ref=e29]: Test Aerospace
      - navigation "Client" [ref=e30]:
        - link "Overview" [ref=e31] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001
          - generic [ref=e32]: Overview
        - link "Objectives" [ref=e33] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/objectives
          - generic [ref=e34]: Objectives
        - link "Calendar" [ref=e35] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/calendar
          - generic [ref=e36]: Calendar
        - link "Relationships" [ref=e37] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/relationships
          - generic [ref=e38]: Relationships
        - link "Work" [ref=e39] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/work
          - generic [ref=e40]: Work
        - link "Capabilities" [ref=e41] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/capabilities
          - generic [ref=e42]: Capabilities
        - link "Bill Tracker" [ref=e43] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/bills
          - generic [ref=e44]: Bill Tracker
        - link "Opportunities" [ref=e45] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/opportunities
          - generic [ref=e46]: Opportunities
        - link "Files" [ref=e47] [cursor=pointer]:
          - /url: /portfolio/10000000-0000-4000-8000-000000000001/files
          - generic [ref=e48]: Files
      - link "Settings" [ref=e50] [cursor=pointer]:
        - /url: /settings
    - main [ref=e51]:
      - generic [ref=e52]:
        - generic [ref=e53]:
          - navigation "Breadcrumb" [ref=e54]:
            - link "Back to Portfolio" [ref=e55] [cursor=pointer]:
              - /url: /portfolio
            - link "Portfolio" [ref=e56] [cursor=pointer]:
              - /url: /portfolio
            - generic [ref=e57]: /
            - link "Test Aerospace" [ref=e58] [cursor=pointer]:
              - /url: /portfolio/10000000-0000-4000-8000-000000000001
            - generic [ref=e59]: /
            - 'button "Switch client view: Files" [ref=e60] [cursor=pointer]': Files
          - generic [ref=e61]:
            - button "Quick add" [ref=e62] [cursor=pointer]:
              - generic [ref=e63]: Quick add
            - button "Meri actions" [ref=e64] [cursor=pointer]:
              - generic [ref=e65]: Meri actions
            - button "More actions for Test Aerospace" [ref=e66] [cursor=pointer]:
              - img [ref=e67]
        - region "Client identity" [ref=e71]:
          - generic [ref=e72]: TA
          - generic [ref=e73]:
            - strong [ref=e74]: Test Aerospace
            - paragraph [ref=e75]: Aerospace
          - generic [ref=e76]: active client
      - generic [ref=e78]:
        - generic [ref=e79]:
          - heading "Client files" [level=1] [ref=e80]
          - generic [ref=e81]:
            - button "New folder" [disabled] [ref=e82]
            - button "Upload" [ref=e83] [cursor=pointer]
            - button "Create with Meri" [disabled] [ref=e84]
        - generic [ref=e85]:
          - textbox "Search files" [ref=e86]:
            - /placeholder: Search files…
          - group "File source" [ref=e87]:
            - button "All" [pressed] [ref=e88] [cursor=pointer]
            - button "manual" [ref=e89] [cursor=pointer]
            - button "workspace" [ref=e90] [cursor=pointer]
          - generic [ref=e91]:
            - text: Sort by
            - combobox "Sort files" [ref=e92]:
              - option "Created · newest" [selected]
              - option "Name"
        - group "File view" [ref=e93]:
          - button "Folders" [ref=e94] [cursor=pointer]
          - button "All files" [active] [pressed] [ref=e95] [cursor=pointer]
        - generic [ref=e96]:
          - complementary [ref=e97]:
            - generic [ref=e98]:
              - generic [ref=e99]: Folders
              - button "Access" [ref=e100] [cursor=pointer]
            - button "Test Aerospace · 3" [ref=e101] [cursor=pointer]
            - button "Reports 2" [ref=e102] [cursor=pointer]:
              - text: Reports
              - generic [ref=e104]: "2"
            - button "Unfiled 1" [pressed] [ref=e105] [cursor=pointer]:
              - text: Unfiled
              - generic [ref=e107]: "1"
            - separator [ref=e108]
            - generic [ref=e109]: Visible file storage
            - paragraph [ref=e110]: 0.0 MiB
            - generic [ref=e111]: Storage quota is not provided by this service. Only accessible current attachments are counted.
          - region "Folder Unfiled" [ref=e112]:
            - generic [ref=e113]:
              - generic [ref=e114]:
                - button "Test Aerospace" [ref=e115] [cursor=pointer]
                - generic [ref=e116]: ›
                - strong [ref=e117]: Unfiled
                - generic [ref=e118]: 1 files
              - button "Upload here" [ref=e119] [cursor=pointer]
            - generic [ref=e120]:
              - generic [ref=e121]: 1 files · 0 selected
              - button "Move to folder" [disabled] [ref=e122]
            - table [ref=e124]:
              - rowgroup [ref=e125]:
                - row "Select visible files Name Linked to / location Created Owner Status Actions" [ref=e126]:
                  - columnheader "Select visible files" [ref=e127]:
                    - checkbox "Select visible files" [ref=e128]
                  - columnheader "Name" [ref=e129]
                  - columnheader "Linked to / location" [ref=e130]
                  - columnheader "Created" [ref=e131]
                  - columnheader "Owner" [ref=e132]
                  - columnheader "Status" [ref=e133]
                  - columnheader "Actions" [ref=e134]:
                    - generic [ref=e135]: Actions
              - rowgroup [ref=e136]:
                - row "Select Gamma memo.txt txt Gamma memo.txt workspace Unfiled 10/1/2026 Test user Text searchable Actions for Gamma memo.txt" [ref=e137]:
                  - cell "Select Gamma memo.txt" [ref=e138]:
                    - checkbox "Select Gamma memo.txt" [ref=e139]
                  - cell "txt Gamma memo.txt workspace" [ref=e140]:
                    - button "txt Gamma memo.txt" [ref=e141] [cursor=pointer]:
                      - generic [ref=e142]: txt
                      - text: Gamma memo.txt
                    - generic [ref=e143]: workspace
                  - cell "Unfiled" [ref=e144]
                  - cell "10/1/2026" [ref=e145]
                  - cell "Test user" [ref=e146]
                  - cell "Text searchable" [ref=e147]:
                    - generic [ref=e148]: Text searchable
                  - cell "Actions for Gamma memo.txt" [ref=e149]:
                    - button "Actions for Gamma memo.txt" [ref=e150] [cursor=pointer]: ⋯
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | import { clientId, installFixtures, json } from "./fixtures";
  3   | import { nativeFile } from "./capability-documents-fixtures";
  4   | 
  5   | const documents = [
  6   |   {
  7   |     ...nativeFile,
  8   |     fileName: "Alpha report.txt",
  9   |     folder: "Reports",
  10  |     source: "manual",
  11  |   },
  12  |   {
  13  |     ...nativeFile,
  14  |     id: "60000000-0000-4000-8000-000000000002",
  15  |     fileName: "Beta report.txt",
  16  |     folder: "Reports",
  17  |     source: "manual",
  18  |   },
  19  |   {
  20  |     ...nativeFile,
  21  |     id: "60000000-0000-4000-8000-000000000003",
  22  |     fileName: "Gamma memo.txt",
  23  |     folder: null,
  24  |     source: "workspace",
  25  |   },
  26  | ];
  27  | async function fixtures(page: Page) {
  28  |   const unexpected = await installFixtures(page);
  29  |   const writes: string[] = [];
  30  |   let reads = 0;
  31  |   page.on("request", (request) => {
  32  |     if (request.url().includes("/api/backend/") && request.method() !== "GET")
  33  |       writes.push(`${request.method()} ${request.url()}`);
  34  |   });
  35  |   await page.route("**/core/engagement/attachments?**", (route) => {
  36  |     reads++;
  37  |     return json(route, documents);
  38  |   });
  39  |   await page.goto(`/portfolio/${clientId}/files`);
  40  |   await expect(
  41  |     page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
  42  |   ).toHaveCount(3);
  43  |   return { writes, unexpected, reads: () => reads };
  44  | }
  45  | const allFiles = (page: Page) =>
  46  |   page
  47  |     .getByRole("group", { name: "File view", exact: true })
  48  |     .getByRole("button", { name: "All files", exact: true });
  49  | const visibleSelection = (page: Page) =>
  50  |   page.getByRole("checkbox", { name: "Select visible files", exact: true });
  51  | 
  52  | for (const folder of ["Reports 2", "Unfiled 1"]) {
  53  |   test(`All files leaves ${folder} and restores the complete current list`, async ({
  54  |     page,
  55  |   }) => {
  56  |     const { writes, unexpected, reads } = await fixtures(page);
  57  |     await page.getByRole("button", { name: folder, exact: true }).click();
  58  |     await expect(
  59  |       page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
  60  |     ).toHaveCount(folder.startsWith("Reports") ? 2 : 1);
  61  |     await allFiles(page).focus();
  62  |     await page.keyboard.press("Enter");
  63  |     await expect(
  64  |       page.getByRole("checkbox", { name: /^Select (Alpha|Beta|Gamma)/ }),
> 65  |     ).toHaveCount(3);
      |       ^ Error: expect(locator).toHaveCount(expected) failed
  66  |     await expect(
  67  |       page.getByRole("region", { name: "All client files", exact: true }),
  68  |     ).toBeVisible();
  69  |     expect(reads()).toBe(1);
  70  |     expect(writes).toEqual([]);
  71  |     expect(unexpected).toEqual([]);
  72  |   });
  73  | }
  74  | 
  75  | test("partial visible selection is mixed and select-all changes only the visible subset", async ({
  76  |   page,
  77  | }, info) => {
  78  |   const { writes, unexpected, reads } = await fixtures(page);
  79  |   await page
  80  |     .getByRole("checkbox", { name: "Select Alpha report.txt", exact: true })
  81  |     .check();
  82  |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", true);
  83  |   await visibleSelection(page).focus();
  84  |   await page.keyboard.press("Space");
  85  |   for (const file of documents)
  86  |     await expect(
  87  |       page.getByRole("checkbox", {
  88  |         name: `Select ${file.fileName}`,
  89  |         exact: true,
  90  |       }),
  91  |     ).toBeChecked();
  92  |   await page.getByLabel("Search files", { exact: true }).fill("Gamma");
  93  |   await expect(visibleSelection(page)).toBeChecked();
  94  |   await visibleSelection(page).uncheck();
  95  |   await expect(
  96  |     page.getByText("1 files · 2 selected · 2 outside this view", {
  97  |       exact: true,
  98  |     }),
  99  |   ).toBeVisible();
  100 |   await expect(visibleSelection(page)).not.toBeChecked();
  101 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", false);
  102 |   await page.screenshot({
  103 |     path: info.outputPath("hidden-selection-desktop.png"),
  104 |     fullPage: true,
  105 |   });
  106 |   await page.getByLabel("Search files", { exact: true }).fill("");
  107 |   await expect(
  108 |     page.getByRole("checkbox", {
  109 |       name: "Select Alpha report.txt",
  110 |       exact: true,
  111 |     }),
  112 |   ).toBeChecked();
  113 |   await expect(
  114 |     page.getByRole("checkbox", { name: "Select Beta report.txt", exact: true }),
  115 |   ).toBeChecked();
  116 |   await expect(
  117 |     page.getByRole("checkbox", { name: "Select Gamma memo.txt", exact: true }),
  118 |   ).not.toBeChecked();
  119 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", true);
  120 |   await page
  121 |     .getByRole("button", { name: "Clear selection", exact: true })
  122 |     .click();
  123 |   await expect(visibleSelection(page)).not.toBeChecked();
  124 |   await expect(visibleSelection(page)).toHaveJSProperty("indeterminate", false);
  125 |   for (const file of documents)
  126 |     await expect(
  127 |       page.getByRole("checkbox", {
  128 |         name: `Select ${file.fileName}`,
  129 |         exact: true,
  130 |       }),
  131 |     ).not.toBeChecked();
  132 |   expect(reads()).toBe(1);
  133 |   expect(writes).toEqual([]);
  134 |   expect(unexpected).toEqual([]);
  135 | });
  136 | 
  137 | test("empty filtered results disclose and clear hidden selection without changing filters or writing", async ({
  138 |   page,
  139 | }, info) => {
  140 |   const { writes, unexpected, reads } = await fixtures(page);
  141 |   await page.setViewportSize({ width: 390, height: 844 });
  142 |   await page.emulateMedia({ colorScheme: "dark" });
  143 |   await page
  144 |     .getByRole("checkbox", { name: "Select Alpha report.txt", exact: true })
  145 |     .check();
  146 |   await page.getByLabel("Search files", { exact: true }).fill("No match");
  147 |   await expect(visibleSelection(page)).toBeDisabled();
  148 |   await expect(
  149 |     page.getByText("0 files · 1 selected · 1 outside this view", {
  150 |       exact: true,
  151 |     }),
  152 |   ).toBeVisible();
  153 |   const clear = page.getByRole("button", {
  154 |     name: "Clear selection",
  155 |     exact: true,
  156 |   });
  157 |   await clear.focus();
  158 |   expect(
  159 |     await page.evaluate(
  160 |       () => document.documentElement.scrollWidth <= innerWidth,
  161 |     ),
  162 |   ).toBe(true);
  163 |   await page.evaluate(() => window.scrollTo(0, 0));
  164 |   await page.screenshot({
  165 |     path: info.outputPath("hidden-selection-mobile-dark.png"),
```