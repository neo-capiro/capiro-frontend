# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: files-browse-selection.spec.ts >> empty filtered results disclose and clear hidden selection without changing filters or writing
- Location: apps/web/tests/browser/files-browse-selection.spec.ts:170:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 11

- Array []
+ Array [
+   Object {
+     "id": "scrollable-region-focusable",
+     "impact": "serious",
+     "targets": Array [
+       Array [
+         ".tableWrap",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - button "Toggle navigation" [ref=e5] [cursor=pointer]:
      - img [ref=e6]
    - link "Capiro Home" [ref=e7] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e8]
    - button "Switch workspace" [ref=e10] [cursor=pointer]
    - navigation "Global actions" [ref=e11]:
      - link "Quick log" [ref=e12] [cursor=pointer]:
        - /url: /portfolio/10000000-0000-4000-8000-000000000001?log=1
      - link "Master calendar" [ref=e13] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e15]
      - button "Test account" [ref=e17] [cursor=pointer]: T
  - main [ref=e19]:
    - generic [ref=e20]:
      - generic [ref=e21]:
        - navigation "Breadcrumb" [ref=e22]:
          - link "Back to Portfolio" [ref=e23] [cursor=pointer]:
            - /url: /portfolio
          - link "Portfolio" [ref=e24] [cursor=pointer]:
            - /url: /portfolio
          - generic [ref=e25]: /
          - link "Test Aerospace" [ref=e26] [cursor=pointer]:
            - /url: /portfolio/10000000-0000-4000-8000-000000000001
          - generic [ref=e27]: /
          - 'button "Switch client view: Files" [ref=e28] [cursor=pointer]': Files
        - generic [ref=e29]:
          - button "Quick add" [ref=e30] [cursor=pointer]:
            - generic [ref=e31]: Quick add
          - button "Meri actions" [ref=e32] [cursor=pointer]:
            - generic [ref=e33]: Meri actions
          - button "More actions for Test Aerospace" [ref=e34] [cursor=pointer]:
            - img [ref=e35]
      - region "Client identity" [ref=e39]:
        - generic [ref=e40]: TA
        - generic [ref=e41]:
          - strong [ref=e42]: Test Aerospace
          - paragraph [ref=e43]: Aerospace
        - generic [ref=e44]: active client
    - generic [ref=e46]:
      - generic [ref=e47]:
        - heading "Client files" [level=1] [ref=e48]
        - generic [ref=e49]:
          - button "New folder" [ref=e50] [cursor=pointer]
          - button "Upload" [ref=e51] [cursor=pointer]
          - button "Create with Meri" [disabled] [ref=e52]
      - generic [ref=e53]:
        - textbox "Search files" [ref=e54]:
          - /placeholder: Search files…
          - text: No match
        - group "File source" [ref=e55]:
          - button "All" [pressed] [ref=e56] [cursor=pointer]
          - button "manual" [ref=e57] [cursor=pointer]
          - button "workspace" [ref=e58] [cursor=pointer]
        - generic [ref=e59]:
          - text: Sort by
          - combobox "Sort files" [ref=e60]:
            - option "Created · newest" [selected]
            - option "Name"
      - group "File view" [ref=e61]:
        - button "Folders" [ref=e62] [cursor=pointer]
        - button "All files" [pressed] [ref=e63] [cursor=pointer]
      - generic [ref=e64]:
        - complementary [ref=e65]:
          - generic [ref=e66]:
            - generic [ref=e67]: Folders
            - button "Access" [disabled] [ref=e68]
          - button "Test Aerospace · 3" [pressed] [ref=e69] [cursor=pointer]
          - button "Reports 2" [ref=e70] [cursor=pointer]:
            - text: Reports
            - generic [ref=e72]: "2"
          - button "Unfiled 1" [ref=e73] [cursor=pointer]:
            - text: Unfiled
            - generic [ref=e75]: "1"
          - separator [ref=e76]
          - generic [ref=e77]: Visible file storage
          - paragraph [ref=e78]: 0.0 MiB
          - generic [ref=e79]: Storage quota is not provided by this service. Only accessible current attachments are counted.
        - region "All client files" [ref=e80]:
          - generic [ref=e81]:
            - generic [ref=e82]:
              - button "Test Aerospace" [ref=e83] [cursor=pointer]
              - generic [ref=e84]: 0 files
            - button "Upload here" [ref=e85] [cursor=pointer]
          - generic [ref=e86]:
            - generic [ref=e87]: 0 files · 1 selected · 1 outside this view
            - generic [ref=e88]:
              - button "Clear selection" [active] [ref=e89] [cursor=pointer]
              - button "Move to folder" [ref=e90] [cursor=pointer]
          - generic [ref=e91]:
            - table [ref=e92]:
              - rowgroup [ref=e93]:
                - row "Select visible files Name Linked to / location Created Owner Status Actions" [ref=e94]:
                  - columnheader "Select visible files" [ref=e95]:
                    - checkbox "Select visible files" [disabled] [ref=e96]
                  - columnheader "Name" [ref=e97]
                  - columnheader "Linked to / location" [ref=e98]
                  - columnheader "Created" [ref=e99]
                  - columnheader "Owner" [ref=e100]
                  - columnheader "Status" [ref=e101]
                  - columnheader "Actions" [ref=e102]:
                    - generic [ref=e103]: Actions
              - rowgroup
            - paragraph [ref=e104]: No files match this view.
```

# Test source

```ts
  1  | import { expect, type Page, type TestInfo } from "@playwright/test";
  2  | import axe from "axe-core";
  3  | 
  4  | export async function expectAccessibleHome(page: Page, testInfo: TestInfo) {
  5  |   await page.evaluate(() => document.fonts.ready);
  6  |   await page.addScriptTag({ content: axe.source });
  7  |   const result = await page.evaluate(() =>
  8  |     (window as unknown as Window & { axe: typeof axe }).axe.run(document),
  9  |   );
  10 |   await testInfo.attach("axe-full-default-results", {
  11 |     body: JSON.stringify(result, null, 2),
  12 |     contentType: "application/json",
  13 |   });
  14 |   expect(
  15 |     result.violations.map(({ id, impact, nodes }) => ({
  16 |       id,
  17 |       impact,
  18 |       targets: nodes.map((node) => node.target),
  19 |     })),
> 20 |   ).toEqual([]);
     |     ^ Error: expect(received).toEqual(expected) // deep equality
  21 |   return result;
  22 | }
  23 | 
```