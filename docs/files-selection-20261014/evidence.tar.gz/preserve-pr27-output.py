from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import tarfile

root = Path('/workspace/capiro-existing-api-feedback-20261014/apps/web/.next')
evidence = Path('/workspace/capiro-files-selection-evidence-20261014')
base = Path('/tmp/capiro-pr26-next-preserved-20261014.tar.gz')
delta = evidence / 'pr27-next-delta.tar.gz'
manifest = evidence / 'pr27-next-preservation.json'
assert root.is_dir() and not root.is_symlink()
assert not delta.exists() and not manifest.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
base_sha = sha(base.read_bytes())
assert base_sha == '9d088d9784ae4bacefd35173171032ff5398cd701082348fe75c86ff72ae8921'
base_hashes = {}
with tarfile.open(base) as archive:
    for member in archive.getmembers():
        if member.isfile() or member.islnk():
            digest = sha(archive.extractfile(member).read())
            base_hashes.setdefault(digest, member.name)
entries = []
added = set()
with tarfile.open(delta, 'w:gz') as archive:
    for path in [root, *sorted(root.rglob('*'))]:
        stat = path.lstat()
        row = {'path': str(path.relative_to(root.parent)),
               'mode': stat.st_mode & 0o777, 'mtimeNs': stat.st_mtime_ns}
        if path.is_symlink():
            row.update(kind='symlink', target=os.readlink(path))
        elif path.is_dir():
            row.update(kind='directory')
        elif path.is_file():
            data = path.read_bytes()
            digest = sha(data)
            row.update(kind='file', bytes=len(data), sha256=digest)
            if digest in base_hashes:
                row.update(archive='base', member=base_hashes[digest])
            else:
                row.update(archive='delta', member=digest)
                if digest not in added:
                    member = tarfile.TarInfo(digest)
                    member.size = len(data)
                    archive.addfile(member, io.BytesIO(data))
                    added.add(digest)
        else:
            raise ValueError(f'Unsupported generated path: {path}')
        entries.append(row)

# Verify every archived byte against the still-existing owned output before removal.
with tarfile.open(base) as old, tarfile.open(delta) as new:
    verified = {}
    for row in entries:
        path = root.parent / row['path']
        assert path.lstat().st_mode & 0o777 == row['mode']
        if row['kind'] == 'file':
            key = (row['archive'], row['member'])
            if key not in verified:
                archive = old if row['archive'] == 'base' else new
                data = archive.extractfile(row['member']).read()
                verified[key] = (len(data), sha(data))
            assert verified[key] == (row['bytes'], row['sha256'])
            assert sha(path.read_bytes()) == row['sha256']
        elif row['kind'] == 'symlink':
            assert os.readlink(path) == row['target']
        else:
            assert path.is_dir()
receipt = {
    'source': '74bc933c07df35e51b4f15c209ab9a2ddf90191c',
    'root': str(root), 'base': str(base), 'baseSha256': base_sha,
    'delta': str(delta), 'deltaSha256': sha(delta.read_bytes()),
    'deltaBytes': delta.stat().st_size, 'entries': entries,
    'verified': True,
    'restore': 'In an empty destination, create directory entries, read file bytes from the named base/delta archive member, apply recorded modes, restore symlink targets and mtimeNs. Both archives are required. Never extract over existing work.'
}
manifest.write_text(json.dumps(receipt, indent=2) + '\n')
assert json.loads(manifest.read_text()) == receipt
shutil.rmtree(root)
print(json.dumps({'verifiedEntries': len(entries), 'deltaBytes': receipt['deltaBytes'],
                  'preserved': str(manifest), 'removedOnlyGeneratedRoot': str(root)}))
