import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';
import { createServer, request as httpRequest } from 'node:http';
import { cp, mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = '/workspace/capiro-preview-receiving-20261013';
const out = '/workspace/capiro-preview-receiving-evidence-20261013/runtime';
const app = join(root, 'apps/web');
const standalone = join(app, '.next/standalone/apps/web');
await mkdir(out, { recursive: true });
await cp(join(app, 'public'), join(standalone, 'public'), { recursive: true });
await cp(join(app, '.next/static'), join(standalone, '.next/static'), { recursive: true });
const upstreamRequests = [];
const upstream = createServer((request, response) => {
  upstreamRequests.push({ method: request.method, url: request.url });
  response.writeHead(599); response.end('Unexpected backend dispatch');
});
upstream.listen(0, '127.0.0.1'); await once(upstream, 'listening');
const upstreamOrigin = `http://127.0.0.1:${upstream.address().port}`;
const results = [];
const env = { ...process.env, NODE_OPTIONS: '--require /workspace/capiro-preview-receiving-evidence-20261013/network-fence.cjs', CAPIRO_TEST_NETWORK_LOG: '/workspace/capiro-preview-receiving-evidence-20261013/blocked-network.jsonl', HOSTNAME: '127.0.0.1', NODE_ENV: 'production', NEXT_TELEMETRY_DISABLED: '1',
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: '', CLERK_SECRET_KEY: '',
  MERI_ACTION_WORKFLOW_ENABLED: 'true', MERI_DOCUMENT_WORKFLOW_ENABLED: 'true', MERI_DOCUMENT_OPERATION: 'create_word' };
for (const key of ['CORE_API_BASE_URL','STRATEGY_API_BASE_URL','WORKSPACE_API_BASE_URL','INTELLIGENCE_API_BASE_URL','MERI_API_BASE_URL','ONBOARD_API_BASE_URL']) env[key] = upstreamOrigin;

async function freePort() {
  const server = createServer(); server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const port = server.address().port; await new Promise(resolve => server.close(resolve)); return port;
}
async function stop(child) {
  if (child.exitCode !== null) return;
  const exit = once(child, 'exit'); child.kill('SIGTERM');
  const timer = setTimeout(() => child.kill('SIGKILL'), 5000);
  try { await exit; } finally { clearTimeout(timer); }
}
function send(port, path, method = 'GET', headers = {}, unfinishedBody = false) {
  return new Promise((resolve, reject) => {
    let interrupted = false, interruption;
    const request = httpRequest({ hostname: '127.0.0.1', port, path, method, headers, timeout: 5000 }, response => {
      let body = ''; response.setEncoding('utf8'); response.on('data', chunk => body += chunk);
      response.on('end', () => { clearTimeout(interruption); resolve({ status: response.statusCode, headers: response.headers, body }); request.destroy(); });
    });
    request.on('error', cause => { if (!interrupted) reject(cause); }); request.on('timeout', () => request.destroy(new Error('Local probe timed out')));
    if (unfinishedBody) { request.setHeader('Content-Length', '1000000'); request.flushHeaders(); request.write('{'); interruption = setTimeout(() => { interrupted = true; request.destroy(); resolve({ interrupted: true, status: null }); }, 150); }
    else request.end(method === 'POST' ? '{}' : undefined);
  });
}
function verifyHeld(response, method) {
  assert.equal(response.status, 503);
  assert.equal(response.headers['cache-control'], 'private, no-store');
  if (method !== 'HEAD') assert.equal(JSON.parse(response.body).error.code, 'PREVIEW_BACKEND_HELD');
  assert.equal(response.headers['set-cookie'], undefined);
}
async function mode(flag, verify, extra = {}, label = flag) {
  const port = await freePort();
  const child = spawn(process.execPath, [join(standalone, 'server.js')], { cwd: root, env: { ...env, PORT: String(port), CAPIRO_PREVIEW_READ_ONLY: flag, ...extra }, stdio: ['ignore','pipe','pipe'] });
  let log = ''; child.stdout.on('data', chunk => log += chunk); child.stderr.on('data', chunk => log += chunk);
  try {
    let ready = false;
    for (let attempt = 0; attempt < 100; attempt++) {
      try { if ((await send(port, '/healthz')).status === 200) { ready = true; break; } } catch {}
      if (child.exitCode !== null) throw Error('Standalone exited during startup');
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    assert.ok(ready, 'Standalone readiness'); await verify(port);
  } finally { await stop(child); await writeFile(join(out, `server-${label}.log`), log); }
}
let error;
try {
  await mode('true', async port => {
    const paths = ['/api/backend/core/clients', '/api/capiro/settings.personal.get', '/api/capiro/public-form.get', '/api/capiro/public-onboard.pricing', '/api/action-followthrough/session', '/api/documents/create'];
    for (const path of paths) for (const method of ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS']) {
      const response = await send(port, path, method, { Origin: `http://127.0.0.1:${port}` });
      if (path.startsWith('/api/documents/') && method !== 'POST') assert.ok([204,405].includes(response.status));
      else verifyHeld(response, method);
      results.push({ flag: 'true', path, method, status: response.status });
    }
    for (const path of ['/api/backend/core/%63lients','/api/backend/core/%252e%252e/clients','/api/backend/core/clients?readonly=false&_method=GET','/api/backend/core/%2e%2e/clients','/api/capiro/%70ublic-onboard.pricing','/api/documents/%63reate','/api/unknown/clients']) {
      const response = await send(port, path, 'POST', {
        Origin: `http://127.0.0.1:${port}`, 'X-HTTP-Method-Override':'GET', 'X-Method-Override':'GET',
        'X-Original-URL':'/healthz', 'X-Rewrite-URL':'/healthz', 'X-Forwarded-Host':'os.capiro.ai',
        'X-Preview-Read-Only':'false', 'X-Tenant-Id':'capiro-internal',
        'X-Middleware-Subrequest':'src/proxy:src/proxy:src/proxy', Cookie:'__session=forged; CAPIRO_PREVIEW_READ_ONLY=false', Authorization:'Bearer forged',
      });
      if (response.status === 503) verifyHeld(response, 'POST');
      else assert.ok([400,404,405].includes(response.status), `Unexpected routing response: ${path}: ${response.status}`);
      results.push({ flag: 'true', path, method: 'POST', status: response.status });
    }
    for (const path of paths) {
      const response = await send(port, path, 'POST', { Origin:`http://127.0.0.1:${port}` }, true);
      if (!response.interrupted) verifyHeld(response, 'POST');
      assert.deepEqual(upstreamRequests, []);
      results.push({ flag:'true',path,method:'POST',unfinishedBody:true,clientInterrupted:response.interrupted ?? false,status:response.status });
    }
    for (const path of ['/healthz','/','/meri','/modules','/sign-in']) {
      const response = await send(port,path); assert.equal(response.status,200); results.push({flag:'true',path,method:'GET',status:response.status});
    }
  });
  await mode('TRUE', async port => {
    const response = await send(port,'/api/backend/core/clients'); verifyHeld(response,'GET');
    results.push({flag:'TRUE',path:'/api/backend/core/clients',method:'GET',status:response.status});
  });
  await mode('false', async port => {
    const response = await send(port,'/api/backend/core/clients'); assert.equal(response.status,503);
    assert.equal(JSON.parse(response.body).message,'Portfolio service configuration is incomplete.');
    results.push({flag:'false',path:'/api/backend/core/clients',method:'GET',status:response.status,ordinaryConfigurationFailure:true});
  });
  const bindings = { CAPIRO_PREVIEW_READ_BACKEND_SOURCE: '111f269d749cae0249c2141779bd6d7deb93f45c', CAPIRO_PREVIEW_READ_API_BASE_URL: 'https://preview-api.synthetic.invalid/api' };
  for (const [label, extra] of [
    ['wrong-source', { ...bindings, CAPIRO_PREVIEW_READ_BACKEND_SOURCE: 'wrong' }],
    ['ordinary-production-denied', { ...bindings, CAPIRO_PREVIEW_READ_API_BASE_URL: 'https://os.capiro.ai/api' }],
    ['no-target', { ...bindings, CAPIRO_PREVIEW_READ_API_BASE_URL: '' }],
  ]) await mode('true', async port => {
    for (const path of ['/api/backend/core/me', '/api/backend/core/clients', '/api/backend/core/clients/10000000-0000-4000-8000-000000000001', '/api/capiro/me.read', '/api/capiro/clients.list']) {
      const response = await send(port, path); verifyHeld(response, 'GET');
      results.push({ label, path, method:'GET', status:response.status });
    }
  }, extra, label);
  await mode('true', async port => {
    for (const path of ['/api/backend/core/clients', '/api/capiro/clients.list']) {
      const response = await send(port, path);
      assert.equal(response.status, 502, 'Without native identity the admitted candidate cannot dispatch');
      results.push({ label:'candidate-without-native-identity', path, method:'GET', status:response.status });
    }
    for (const path of ['/api/backend/core/me/memberships','/api/backend/intelligence/clients','/api/capiro/me.update','/api/capiro/public-onboard.pricing','/api/action-followthrough/session','/api/documents/create']) {
      const response = await send(port, path, 'POST'); verifyHeld(response, 'POST');
      results.push({ label:'candidate-unallocated', path, method:'POST', status:response.status });
    }
    for (const method of ['HEAD','OPTIONS','POST','PATCH','DELETE']) {
      const response = await send(port, '/api/backend/core/clients', method); verifyHeld(response, method);
      results.push({ label:'candidate-method-denied',path:'/api/backend/core/clients',method,status:response.status });
    }
  }, bindings, 'candidate');
  assert.deepEqual(upstreamRequests, []);
} catch (cause) { error = String(cause?.stack ?? cause); }
finally {
  await new Promise(resolve => upstream.close(resolve));
  await writeFile(join(out,'report.json'),JSON.stringify({ source:execFileSync('git',['rev-parse','HEAD'],{cwd:root}).toString().trim(), results, upstreamRequests, error:error ?? null, passed:!error, nativeAcceptance:false },null,2)+'\n');
}
if (error) throw Error(error);
console.log(JSON.stringify({ observations:results.length, upstreamRequests:upstreamRequests.length, passed:true }));
