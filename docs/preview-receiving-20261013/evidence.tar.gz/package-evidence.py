from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, tarfile, shutil

root=Path(__file__).resolve().parent
out=Path('/workspace/capiro-preview-receiving-publication-20261013')
out.mkdir(exist_ok=False)
excluded={'next','next-qualified','build-generated-node_modules','vite-cache','capiro-vite-cache','tmp'}
records=[]
for path in sorted(root.rglob('*')):
    relative=path.relative_to(root)
    if relative.parts[0] in excluded or (relative.parts[0] == 'final-baseline' and len(relative.parts) > 1 and relative.parts[1] in {'node_modules','cache'}):
        continue
    assert not path.is_symlink(), f'Unexpected symlink: {path}'
    if path.is_file():
        records.append({'path':relative.as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
manifest={'source':'5ca42049325881782bc9d2ac557450d642eccee8','files':records,'excludedGeneratedDirectories':sorted(excluded),'nativeAcceptance':False}
manifestBytes=(json.dumps(manifest,indent=2)+'\n').encode()
(out/'MANIFEST.json').write_bytes(manifestBytes)
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for record in records:
        tar.add(root/record['path'],arcname=record['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    expected={r['path']:r for r in records}
    seen=set()
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in seen
        data=tar.extractfile(member).read();record=expected[member.name]
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
        assert hashlib.sha256((root/member.name).read_bytes()).hexdigest()==record['sha256']
        seen.add(member.name)
    assert seen==set(expected)
receipt={'source':manifest['source'],'atUTC':datetime.now(timezone.utc).isoformat(),'files':len(records),'uncompressedBytes':sum(r['bytes'] for r in records),'archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256(manifestBytes).hexdigest(),'archiveMembersAndOriginalBytesVerified':True,'excluded':sorted(excluded),'fileModesRestored':False}
(out/'EVIDENCE.json').write_text(json.dumps(receipt,indent=2)+'\n')
destination=Path('/workspace/capiro-preview-receiving-20261013/docs/preview-receiving-20261013')
for name in ['MANIFEST.json','EVIDENCE.json','evidence.tar.gz']:
    assert not (destination/name).exists()
    shutil.copy2(out/name,destination/name)
print(json.dumps(receipt,indent=2))
