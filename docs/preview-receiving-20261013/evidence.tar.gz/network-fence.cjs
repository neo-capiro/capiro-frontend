const { appendFileSync } = require('node:fs');
function block() {
  appendFileSync(process.env.CAPIRO_TEST_NETWORK_LOG, JSON.stringify({ externalAttemptBlocked: true }) + '\n');
  throw new Error('External network forbidden during credential-free receiving qualification');
}
const originalFetch = globalThis.fetch;
globalThis.fetch = function (input, options) {
  const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)) return Promise.reject().catch(block);
  return originalFetch(input, options);
};
for (const name of ['node:http', 'node:https']) {
  const module = require(name);
  for (const method of ['request', 'get']) {
    const original = module[method];
    module[method] = function (input, ...args) {
      const hostname = typeof input === 'string' || input instanceof URL ? new URL(input).hostname : input.hostname ?? input.host ?? 'localhost';
      if (!['127.0.0.1', 'localhost', '[::1]'].includes(hostname)) return block();
      return original.call(this, input, ...args);
    };
  }
}
