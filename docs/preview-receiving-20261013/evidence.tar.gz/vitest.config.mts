import original from '/workspace/capiro-preview-receiving-20261013/apps/web/vitest.config.ts';
export default {...original,root:'/workspace/capiro-preview-receiving-20261013/apps/web',cacheDir:'/workspace/capiro-preview-receiving-evidence-20261013/vite-cache'};
