import original from '/workspace/capiro-preview-receiving-20261013/apps/web/src/shared/capiro/vitest.config.mts';
export default {...original, cacheDir:'/workspace/capiro-preview-receiving-evidence-20261013/capiro-vite-cache'};
