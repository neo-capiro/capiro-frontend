# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-customize-entry.spec.ts >> unavailable saved ordering is explained after Customize from a filtered list and remains read-only
- Location: apps/web/tests/browser/portfolio-customize-entry.spec.ts:119:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Saved profile ordering is unavailable in this environment.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Saved profile ordering is unavailable in this environment.')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - button "Toggle navigation"
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - button "Switch workspace"
  - navigation "Global actions":
    - link "Quick log":
      - /url: /portfolio?log=1
    - link "Master calendar":
      - /url: /calendar
    - link "Search Portfolio":
      - /url: /portfolio?search=1
    - button "Updates unavailable" [disabled]
    - button "Test account": T
- main:
  - paragraph: Your client portfolio
  - heading "Portfolio 2" [level=1]
  - combobox "Account owner":
    - option "All owners" [selected]
    - option "Unassigned"
  - textbox "Search profiles":
    - /placeholder: Search profiles…
    - text: Aerospace
  - button "Customize" [expanded]
  - button "Add profile"
  - region "Portfolio pulse":
    - paragraph: Portfolio pulse
    - strong: —
    - text: of work linked to an objective
    - strong: "2"
    - text: Clients
    - strong: —
    - text: Need attention
    - strong: —
    - text: Objectives
    - strong: —
    - text: Off track
    - strong: —
    - text: Strategies
  - region "Portfolio profiles":
    - navigation "Profile type":
      - button "All 2" [pressed]
      - button "Clients 2"
      - link "Prospects":
        - /url: /portfolio/prospects
      - link "Pipeline":
        - /url: /portfolio/prospects?pipeline=1
      - button "New objective"
      - group: Filters and view
    - status: 1 profile of 2
    - button "Refresh profiles"
    - table "Portfolio profiles":
      - rowgroup:
        - row "Organization Type Sector Account owner Status Open":
          - columnheader "Organization"
          - columnheader "Type"
          - columnheader "Sector"
          - columnheader "Account owner"
          - columnheader "Status"
          - columnheader "Open"
      - rowgroup:
        - row "Test Aerospace https://example.test CLIENT Aerospace Owner unavailable ACTIVE Open Test Aerospace":
          - cell "Test Aerospace https://example.test":
            - link "Test Aerospace https://example.test":
              - /url: /portfolio/10000000-0000-4000-8000-000000000001
              - strong: Test Aerospace
              - text: https://example.test
          - cell "CLIENT"
          - cell "Aerospace"
          - cell "Owner unavailable"
          - cell "ACTIVE"
          - cell "Open Test Aerospace":
            - link "Open Test Aerospace":
              - /url: /portfolio/10000000-0000-4000-8000-000000000001
    - paragraph: To rearrange profiles, choose Card view and Saved order, then clear profile filters.
  - complementary "Needs attention":
    - heading "Needs attention" [level=3]
    - note "0 shown alerts": 0 shown
    - text: ↑↓ Most urgent
    - paragraph: Updates automatically. Open an item in its client profile.
    - status: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
    - paragraph: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
    - text: Snapshot
    - time: Oct 11, 6:00 AM UTC
    - button "Refresh alerts"
```

# Test source

```ts
  34  |       : json(route, {
  35  |           ...layoutActor,
  36  |           contractVersion: 1,
  37  |           version,
  38  |           updatedAt: "2026-10-11T00:00:00.000Z",
  39  |           order,
  40  |         });
  41  |   });
  42  |   return { writes, unexpected };
  43  | }
  44  | const positions = (page: Page) =>
  45  |   page
  46  |     .locator("[data-client-id]")
  47  |     .evaluateAll((items) =>
  48  |       items.map((item) => item.getAttribute("data-client-id")),
  49  |     );
  50  | 
  51  | for (const query of [
  52  |   "view=list&sort=name",
  53  |   "sort=recent&q=Aerospace",
  54  |   "view=list&q=No+matching+profile&owner=missing-owner&status=ACTIVE",
  55  | ]) {
  56  |   test(`Customize opens the full saved catalog from ${query} and restores the current view`, async ({
  57  |     page,
  58  |   }, info) => {
  59  |     const { writes, unexpected } = await fixtures(page);
  60  |     await page.goto(`/portfolio?${query}`);
  61  |     await expect(
  62  |       page.getByRole("heading", { name: "Portfolio 2", exact: true }),
  63  |     ).toBeVisible();
  64  |     const before = page.url();
  65  |     const trigger = page.getByRole("button", {
  66  |       name: "Customize",
  67  |       exact: true,
  68  |     });
  69  |     await trigger.focus();
  70  |     await page.keyboard.press("Enter");
  71  |     const later = page.getByRole("button", {
  72  |       name: "Move Alpha Energy later",
  73  |       exact: true,
  74  |     });
  75  |     await expect(later).toBeVisible();
  76  |     await expect(later).toBeEnabled();
  77  |     await expect.poll(() => positions(page)).toEqual(initialOrder);
  78  |     await expect(
  79  |       page
  80  |         .getByRole("status")
  81  |         .filter({ hasText: "Customizing all 2 profiles" }),
  82  |     ).toBeVisible();
  83  |     await expect(page).toHaveURL(before);
  84  |     await expect(page.getByLabel("Search profiles")).toBeDisabled();
  85  |     await later.focus();
  86  |     await page.keyboard.press("Enter");
  87  |     await expect.poll(() => positions(page)).toEqual([clientId, secondId]);
  88  |     await expect(
  89  |       page.getByRole("button", { name: "Done customizing" }),
  90  |     ).toBeDisabled();
  91  |     await page.screenshot({
  92  |       path: info.outputPath("customize-desktop.png"),
  93  |       fullPage: true,
  94  |     });
  95  |     await page.getByRole("button", { name: "Cancel reorder" }).click();
  96  |     await expect.poll(() => positions(page)).toEqual(initialOrder);
  97  |     await page.getByRole("button", { name: "Done customizing" }).click();
  98  |     await expect(trigger).toBeFocused();
  99  |     await expect(trigger).toHaveAttribute("aria-expanded", "false");
  100 |     await expect(page).toHaveURL(before);
  101 |     await expect(page.getByLabel("Search profiles")).toHaveValue(
  102 |       new URL(before).searchParams.get("q") ?? "",
  103 |     );
  104 |     await expect(page.getByLabel("Search profiles")).toBeEnabled();
  105 |     if (query.includes("No+matching"))
  106 |       await expect(
  107 |         page.getByRole("heading", { name: "No profiles found" }),
  108 |       ).toBeVisible();
  109 |     else if (query.includes("view=list"))
  110 |       await expect(
  111 |         page.getByRole("table", { name: "Portfolio profiles" }),
  112 |       ).toBeVisible();
  113 |     else await expect(page.getByRole("article")).toHaveCount(1);
  114 |     expect(writes).toEqual([]);
  115 |     expect(unexpected).toEqual([]);
  116 |   });
  117 | }
  118 | 
  119 | test("unavailable saved ordering is explained after Customize from a filtered list and remains read-only", async ({
  120 |   page,
  121 | }, info) => {
  122 |   const { writes, unexpected } = await fixtures(page, true);
  123 |   await page.setViewportSize({ width: 390, height: 844 });
  124 |   await page.emulateMedia({ colorScheme: "dark" });
  125 |   await page.goto("/portfolio?view=list&q=Aerospace");
  126 |   const before = page.url();
  127 |   const trigger = page.getByRole("button", { name: "Customize", exact: true });
  128 |   await trigger.click();
  129 |   await expect(
  130 |     page.getByText(
  131 |       "Saved profile ordering is unavailable in this environment.",
  132 |       { exact: false },
  133 |     ),
> 134 |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  135 |   await expect(page.getByRole("article")).toHaveCount(2);
  136 |   await expect(
  137 |     page.getByRole("button", {
  138 |       name: "Move Test Aerospace later",
  139 |       exact: true,
  140 |     }),
  141 |   ).toBeDisabled();
  142 |   await expect(
  143 |     page.getByRole("button", { name: "Save order", exact: true }),
  144 |   ).toHaveCount(0);
  145 |   expect(
  146 |     await page.evaluate(
  147 |       () => document.documentElement.scrollWidth <= innerWidth,
  148 |     ),
  149 |   ).toBe(true);
  150 |   await page.screenshot({
  151 |     path: info.outputPath("customize-unavailable-mobile-dark.png"),
  152 |     fullPage: true,
  153 |   });
  154 |   await page.getByRole("button", { name: "Done customizing" }).click();
  155 |   await expect(trigger).toBeFocused();
  156 |   await expect(page).toHaveURL(before);
  157 |   await expect(
  158 |     page.getByRole("table", { name: "Portfolio profiles" }),
  159 |   ).toBeVisible();
  160 |   expect(writes).toEqual([]);
  161 |   expect(unexpected).toEqual([]);
  162 | });
  163 | 
```