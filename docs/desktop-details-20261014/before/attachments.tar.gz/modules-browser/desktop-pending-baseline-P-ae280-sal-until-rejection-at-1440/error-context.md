# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-pending-baseline.spec.ts >> Planner pending writes freeze the submitted draft and dismissal until rejection at 1440
- Location: test/browser/desktop-pending-baseline.spec.ts:6:3

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByLabel('Task name', { exact: true })
Expected: disabled
Received: enabled
Timeout:  5000ms

Call log:
  - Expect "toBeDisabled" with timeout 5000ms
  - waiting for getByLabel('Task name', { exact: true })
    14 × locator resolved to <input required="" id="task-name" maxlength="500" data-slot="input" value="Test submitted draft" class="file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-n…/>
       - unexpected value "enabled"

```

```yaml
- textbox "Task name": Test submitted draft
```

# Test source

```ts
  1   | import { test } from "./runtime-observed-test";
  2   | import { expect } from "@playwright/test";
  3   | import { operationFixtures, testIdentity } from "./fixtures";
  4   | import { nextTask } from "./next-modules-fixtures";
  5   | for (const width of [1440]) {
  6   |   test(`Planner pending writes freeze the submitted draft and dismissal until rejection at ${width}`, async ({
  7   |     page,
  8   |   }) => {
  9   |     await page.setViewportSize({ width, height: 1040 });
  10  |     await operationFixtures(page, {
  11  |       "me.read": testIdentity,
  12  |       "planner.bootstrap": {
  13  |         me: { id: "test-user", name: "Test User" },
  14  |         people: [],
  15  |         projects: [],
  16  |       },
  17  |       "planner.tasks": { items: [nextTask], nextCursor: null },
  18  |     });
  19  |     let release!: () => void;
  20  |     const held = new Promise<void>((resolve) => {
  21  |       release = resolve;
  22  |     });
  23  |     let writes = 0;
  24  |     await page.route("**/api/capiro/planner.task.create", async (route) => {
  25  |       writes++;
  26  |       await held;
  27  |       await route.fulfill({
  28  |         status: 409,
  29  |         json: { message: "Synthetic concurrent edit" },
  30  |       });
  31  |     });
  32  |     await page.goto("/modules/planner");
  33  |     await page.getByRole("button", { name: "+ New task", exact: true }).click();
  34  |     const name = page.getByLabel("Task name", { exact: true });
  35  |     await page.getByRole("button", { name: "Save task", exact: true }).click();
  36  |     expect(writes).toBe(0);
  37  |     expect(
  38  |       await name.evaluate(
  39  |         (input) => (input as HTMLInputElement).validity.valueMissing,
  40  |       ),
  41  |     ).toBe(true);
  42  |     await name.fill("Test submitted draft");
  43  |     await page
  44  |       .getByText("Task type, repeat, collaborators and dependencies", {
  45  |         exact: true,
  46  |       })
  47  |       .click();
  48  |     await page
  49  |       .getByRole("dialog")
  50  |       .getByLabel("Task type", { exact: true })
  51  |       .click();
  52  |     await page.getByRole("option", { name: "approval", exact: true }).click();
  53  |     await page.getByRole("button", { name: "Save task", exact: true }).click();
  54  |     try {
  55  |       await expect(
  56  |         page.getByRole("button", { name: "Saving…", exact: true }),
  57  |       ).toBeDisabled();
> 58  |       await expect(name).toBeDisabled();
      |                          ^ Error: expect(locator).toBeDisabled() failed
  59  |       for (const label of [
  60  |         "Assignee",
  61  |         "Priority",
  62  |         "Status",
  63  |         "Task type",
  64  |         "Approval",
  65  |         "Repeat",
  66  |       ]) {
  67  |         const trigger = page
  68  |           .getByRole("dialog")
  69  |           .getByLabel(label, { exact: true });
  70  |         await trigger.scrollIntoViewIfNeeded();
  71  |         const box = await trigger.boundingBox();
  72  |         expect(box).not.toBeNull();
  73  |         await page.mouse.click(
  74  |           box!.x + box!.width / 2,
  75  |           box!.y + box!.height / 2,
  76  |         );
  77  |         await expect(page.getByRole("listbox")).toHaveCount(0);
  78  |       }
  79  |       await expect(
  80  |         page.getByRole("button", { name: "Cancel", exact: true }),
  81  |       ).toBeDisabled();
  82  |       await page.keyboard.press("Escape");
  83  |       await expect(page.getByRole("dialog")).toBeVisible();
  84  |       await page
  85  |         .getByRole("button", { name: "Close dialog", exact: true })
  86  |         .click();
  87  |       await expect(page.getByRole("dialog")).toBeVisible();
  88  |       expect(writes).toBe(1);
  89  |     } finally {
  90  |       release();
  91  |     }
  92  |     await expect(page.getByRole("alert")).toContainText(
  93  |       "Synthetic concurrent edit",
  94  |     );
  95  |     await expect(name).toBeEnabled();
  96  |     await expect(name).toHaveValue("Test submitted draft");
  97  |     await page.getByRole("button", { name: "Cancel", exact: true }).click();
  98  |     await expect(page.getByRole("dialog")).toBeHidden();
  99  |   });
  100 | }
  101 | 
```