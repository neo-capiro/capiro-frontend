# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-task-drawer.spec.ts >> Desktop Planner detail uses the Figma drawer at 1440 light
- Location: test/browser/desktop-task-drawer.spec.ts:8:5

# Error details

```
Error: expect(received).toBeCloseTo(expected, precision)

Expected: 760
Received: 360

Expected precision:    0
Expected difference: < 0.5
Received difference:   400
```

# Page snapshot

```yaml
- generic:
  - generic:
    - generic:
      - link:
        - /url: "#main-content"
        - text: Skip to content
      - banner:
        - link:
          - /url: /
          - img
        - navigation:
          - link:
            - /url: /meri
            - generic:
              - img
          - link:
            - /url: /
            - generic:
              - img
          - link:
            - /url: /modules
            - generic:
              - img
        - navigation:
          - link:
            - /url: /?log=1
            - generic:
              - img
          - link:
            - /url: /calendar
            - generic:
              - img
          - link:
            - /url: /modules/intelligence
            - generic:
              - img
          - button [disabled]:
            - generic:
              - img
          - link:
            - /url: /settings/personal
            - generic:
              - img
      - generic:
        - complementary:
          - paragraph: Modules
          - navigation:
            - link:
              - /url: /modules
              - generic:
                - img
              - generic: Module hub
            - link:
              - /url: /modules/engagement
              - generic:
                - img
              - generic: Engagement
            - link:
              - /url: /modules/planner
              - generic:
                - img
              - generic: Planner
            - link:
              - /url: /modules/calendar
              - generic:
                - img
              - generic: Calendar
            - link:
              - /url: /modules/workspace
              - generic:
                - img
              - generic: Workspace
            - link:
              - /url: /modules/strategies
              - generic:
                - img
              - generic: Strategies
            - link:
              - /url: /modules/directory
              - generic:
                - img
              - generic: Directory
            - link:
              - /url: /modules/intelligence
              - generic:
                - img
              - generic: Intelligence
            - link:
              - /url: /modules/research-portfolios
              - generic:
                - img
              - generic: Research portfolios
          - link:
            - /url: /settings/personal
            - generic:
              - img
            - generic: Settings
        - main:
          - navigation:
            - link:
              - /url: /modules
              - text: ← Modules
            - generic: /
            - combobox:
              - generic: Planner
              - img
          - generic:
            - generic:
              - generic:
                - heading [level=1]: Planner
                - paragraph: Coordinate tasks, projects and capacity across your permitted work.
              - generic:
                - button: Refresh
            - tablist:
              - tab [selected]: My tasks
              - tab: All tasks
              - tab: Projects
              - tab: Inbox
              - tab: Portfolios
              - tab: Goals
              - tab: Workload
              - tab: Capacity
              - tab: Reporting
              - tab: Timesheets
              - tab: Templates
              - tab: Rules
              - tab: Forms
            - generic:
              - generic:
                - tablist:
                  - tab [selected]: List
                  - tab: Board
                  - tab: Calendar
                  - tab: Timeline
                  - tab: Gantt
                - button: + New task
              - generic:
                - searchbox
                - combobox:
                  - generic: Status · Open
                  - img
                - combobox:
                  - generic: All assignees
                  - img
                - combobox:
                  - generic: Priority · All
                  - img
                - button: Import CSV
                - button: Save view
                - button: My tasks settings
              - paragraph: Time is shown as hours:minutes. This page includes only work you can access.
              - generic:
                - table:
                  - caption: Planner tasks
                  - rowgroup:
                    - row:
                      - columnheader: Task name
                      - columnheader: Assignee
                      - columnheader: Due date
                      - columnheader: Priority
                      - columnheader: Status
                      - columnheader: Estimated
                      - columnheader: Actual
                  - rowgroup:
                    - row:
                      - cell:
                        - generic:
                          - checkbox
                          - button
                          - button: Test appropriation review
                      - cell: Test User
                      - cell: Oct 12
                      - cell:
                        - generic: high
                      - cell:
                        - generic: To do
                      - cell: 1:30
                      - cell: 0:15
    - complementary: Explicit local test fixture · synthetic identity and records
  - dialog "Test appropriation review" [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e4]:
        - heading "Test appropriation review" [level=2] [ref=e5]
        - paragraph [ref=e6]: Synthetic review work
      - button "Close dialog" [active] [ref=e7] [cursor=pointer]: ×
    - generic [ref=e9]:
      - generic [ref=e10]:
        - generic [ref=e11]: todo
        - generic [ref=e12]: high
        - button "Edit task" [ref=e13] [cursor=pointer]
        - button "Archive" [ref=e14] [cursor=pointer]
      - generic [ref=e15]:
        - generic [ref=e16]:
          - term [ref=e17]: Assignee
          - definition [ref=e18]: Test User
        - generic [ref=e19]:
          - term [ref=e20]: Due
          - definition [ref=e21]: Oct 12
        - generic [ref=e22]:
          - term [ref=e23]: Time
          - definition [ref=e24]: 0:15 / 1:30
      - generic [ref=e25]:
        - heading "Projects and dependencies" [level=2] [ref=e28]
        - paragraph [ref=e30]: 0 dependencies · 0 collaborators
      - generic [ref=e31]:
        - generic [ref=e32]:
          - heading "Subtasks" [level=2] [ref=e34]
          - button "+ Subtask" [ref=e35] [cursor=pointer]
        - generic [ref=e37]:
          - generic [ref=e38]: todo
          - generic [ref=e39]: Test appropriation review
      - generic [ref=e40]:
        - generic [ref=e41]:
          - generic [ref=e42]:
            - heading "Attachments" [level=2] [ref=e43]
            - paragraph [ref=e44]: Files up to 25 MiB; backend checks task access for every transfer.
          - button "Upload attachment" [ref=e45] [cursor=pointer]
        - button "Task attachment file" [ref=e46]
        - paragraph [ref=e48]: No attachments yet.
      - button "Add time" [ref=e49] [cursor=pointer]
      - heading "Activity" [level=2] [ref=e53]
      - generic [ref=e55]:
        - generic [ref=e56]:
          - generic [ref=e57]: Comment
          - textbox "Comment" [ref=e58]
        - button "Post comment" [ref=e59] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect } from "@playwright/test";
  2  | import { test } from "./runtime-observed-test";
  3  | import { nextTask, setup, taskId } from "./next-modules-fixtures";
  4  | import { expectAccessibleHome } from "../accessibility";
  5  | 
  6  | for (const colorScheme of ["light", "dark"] as const) {
  7  |   for (const state of ["new", "detail", "edit"] as const) {
  8  |     test(`Desktop Planner ${state} uses the Figma drawer at 1440 ${colorScheme}`, async ({ page }, info) => {
  9  |       await page.setViewportSize({ width: 1440, height: 1040 });
  10 |       await page.emulateMedia({ colorScheme, reducedMotion: "reduce" });
  11 |       await setup(page);
  12 |       await page.goto(state === "new" ? "/modules/planner" : `/modules/planner?task=${taskId}`);
  13 |       if (state === "new")
  14 |         await page.getByRole("button", { name: "+ New task", exact: true }).click();
  15 |       if (state === "edit")
  16 |         await page.getByRole("button", { name: "Edit task", exact: true }).click();
  17 |       const title = state === "new" ? "New task" : state === "edit" ? "Edit task" : nextTask.name;
  18 |       const dialog = page.getByRole("dialog", { name: title, exact: true });
  19 |       await expect(dialog).toBeVisible();
  20 |       const bounds = await dialog.boundingBox();
  21 |       await info.attach("drawer-geometry", { body: JSON.stringify({ state, colorScheme, reference: state === "detail" ? "411:100367" : "819:146214", bounds }), contentType: "application/json" });
  22 |       await page.screenshot({ path: info.outputPath("desktop-drawer.png") });
> 23 |       expect(bounds!.x).toBeCloseTo(760, 0);
     |                         ^ Error: expect(received).toBeCloseTo(expected, precision)
  24 |       expect(bounds!.y).toBeCloseTo(0, 0);
  25 |       expect(bounds!.width).toBeCloseTo(680, 0);
  26 |       expect(bounds!.height).toBeCloseTo(1040, 0);
  27 |       await expectAccessibleHome(page, info);
  28 |       await dialog.getByRole("button", { name: "Close dialog", exact: true }).click();
  29 |       await expect(dialog).toBeHidden();
  30 |     });
  31 |   }
  32 | }
  33 | 
```