# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-task-drawer.spec.ts >> Desktop Planner edit uses the Figma drawer at 1440 light
- Location: test/browser/desktop-task-drawer.spec.ts:8:5

# Error details

```
Error: expect(received).toBeCloseTo(expected, precision)

Expected: 760
Received: 360

Expected precision:    0
Expected difference: < 0.5
Received difference:   400
```

# Page snapshot

```yaml
- generic:
  - generic:
    - generic:
      - link:
        - /url: "#main-content"
        - text: Skip to content
      - banner:
        - link:
          - /url: /
          - img
        - navigation:
          - link:
            - /url: /meri
            - generic:
              - img
          - link:
            - /url: /
            - generic:
              - img
          - link:
            - /url: /modules
            - generic:
              - img
        - navigation:
          - link:
            - /url: /?log=1
            - generic:
              - img
          - link:
            - /url: /calendar
            - generic:
              - img
          - link:
            - /url: /modules/intelligence
            - generic:
              - img
          - button [disabled]:
            - generic:
              - img
          - link:
            - /url: /settings/personal
            - generic:
              - img
      - generic:
        - complementary:
          - paragraph: Modules
          - navigation:
            - link:
              - /url: /modules
              - generic:
                - img
              - generic: Module hub
            - link:
              - /url: /modules/engagement
              - generic:
                - img
              - generic: Engagement
            - link:
              - /url: /modules/planner
              - generic:
                - img
              - generic: Planner
            - link:
              - /url: /modules/calendar
              - generic:
                - img
              - generic: Calendar
            - link:
              - /url: /modules/workspace
              - generic:
                - img
              - generic: Workspace
            - link:
              - /url: /modules/strategies
              - generic:
                - img
              - generic: Strategies
            - link:
              - /url: /modules/directory
              - generic:
                - img
              - generic: Directory
            - link:
              - /url: /modules/intelligence
              - generic:
                - img
              - generic: Intelligence
            - link:
              - /url: /modules/research-portfolios
              - generic:
                - img
              - generic: Research portfolios
          - link:
            - /url: /settings/personal
            - generic:
              - img
            - generic: Settings
        - main:
          - navigation:
            - link:
              - /url: /modules
              - text: ← Modules
            - generic: /
            - combobox:
              - generic: Planner
              - img
          - generic:
            - generic:
              - generic:
                - heading [level=1]: Planner
                - paragraph: Coordinate tasks, projects and capacity across your permitted work.
              - generic:
                - button: Refresh
            - tablist:
              - tab [selected]: My tasks
              - tab: All tasks
              - tab: Projects
              - tab: Inbox
              - tab: Portfolios
              - tab: Goals
              - tab: Workload
              - tab: Capacity
              - tab: Reporting
              - tab: Timesheets
              - tab: Templates
              - tab: Rules
              - tab: Forms
            - generic:
              - generic:
                - tablist:
                  - tab [selected]: List
                  - tab: Board
                  - tab: Calendar
                  - tab: Timeline
                  - tab: Gantt
                - button: + New task
              - generic:
                - searchbox
                - combobox:
                  - generic: Status · Open
                  - img
                - combobox:
                  - generic: All assignees
                  - img
                - combobox:
                  - generic: Priority · All
                  - img
                - button: Import CSV
                - button: Save view
                - button: My tasks settings
              - paragraph: Time is shown as hours:minutes. This page includes only work you can access.
              - generic:
                - table:
                  - caption: Planner tasks
                  - rowgroup:
                    - row:
                      - columnheader: Task name
                      - columnheader: Assignee
                      - columnheader: Due date
                      - columnheader: Priority
                      - columnheader: Status
                      - columnheader: Estimated
                      - columnheader: Actual
                  - rowgroup:
                    - row:
                      - cell:
                        - generic:
                          - checkbox
                          - button
                          - button: Test appropriation review
                      - cell: Test User
                      - cell: Oct 12
                      - cell:
                        - generic: high
                      - cell:
                        - generic: To do
                      - cell: 1:30
                      - cell: 0:15
    - complementary: Explicit local test fixture · synthetic identity and records
  - dialog:
    - banner:
      - generic:
        - heading [level=2]: Test appropriation review
        - paragraph: Synthetic review work
      - button: ×
    - generic:
      - generic:
        - generic:
          - generic: todo
          - generic: high
          - button: Edit task
          - button: Archive
        - generic:
          - generic:
            - term: Assignee
            - definition: Test User
          - generic:
            - term: Due
            - definition: Oct 12
          - generic:
            - term: Time
            - definition: 0:15 / 1:30
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Projects and dependencies
          - generic:
            - paragraph: 0 dependencies · 0 collaborators
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Subtasks
            - button: + Subtask
          - generic:
            - generic:
              - generic: todo
              - generic: Test appropriation review
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Attachments
              - paragraph: Files up to 25 MiB; backend checks task access for every transfer.
            - button: Upload attachment
          - button
          - generic:
            - paragraph: No attachments yet.
        - button: Add time
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Activity
        - generic:
          - generic:
            - generic: Comment
            - textbox
          - button: Post comment
  - dialog "Edit task" [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - heading "Edit task" [level=2] [ref=e6]
        - paragraph [ref=e7]: Task access and updates are checked by the Planner service.
      - button "Close dialog" [active] [ref=e8] [cursor=pointer]: ×
    - generic [ref=e10]:
      - generic [ref=e11]:
        - generic [ref=e12]: Task name
        - textbox "Task name" [ref=e13]: Test appropriation review
      - generic [ref=e14]:
        - generic [ref=e15]: Description
        - textbox "Description" [ref=e16]: Synthetic review work
      - generic [ref=e17]:
        - generic [ref=e18]: Assignee
        - combobox "Assignee" [ref=e19] [cursor=pointer]:
          - generic: Test User
          - img [ref=e20]
        - combobox [ref=e22]
      - group "Projects" [ref=e23]:
        - generic [ref=e24]: Projects
      - generic [ref=e25]:
        - generic [ref=e26]:
          - generic [ref=e27]: Start date
          - textbox "Start date" [ref=e28]
        - generic [ref=e29]:
          - generic [ref=e30]: Due date
          - textbox "Due date" [ref=e31]: 2026-10-12
        - generic [ref=e32]:
          - generic [ref=e33]: Start time
          - textbox "Start time" [disabled] [ref=e34]
        - generic [ref=e35]:
          - generic [ref=e36]: Due time
          - textbox "Due time" [ref=e37]
        - generic [ref=e38]:
          - generic [ref=e39]: Time zone
          - textbox "Time zone" [ref=e40]:
            - /placeholder: America/New_York
        - generic [ref=e41]:
          - generic [ref=e42]: Priority
          - combobox "Priority" [ref=e43] [cursor=pointer]:
            - generic: high
            - img [ref=e44]
          - combobox [ref=e46]
        - generic [ref=e47]:
          - generic [ref=e48]: Status
          - combobox "Status" [ref=e49] [cursor=pointer]:
            - generic: To do
            - img [ref=e50]
          - combobox [ref=e52]
        - generic [ref=e53]:
          - generic [ref=e54]: Estimated minutes
          - spinbutton "Estimated minutes" [ref=e55]: "90"
      - group [ref=e56]:
        - generic "Task type, repeat, collaborators and dependencies" [ref=e57]
      - generic [ref=e58]:
        - button "Cancel" [ref=e59] [cursor=pointer]
        - button "Save task" [ref=e60] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect } from "@playwright/test";
  2  | import { test } from "./runtime-observed-test";
  3  | import { nextTask, setup, taskId } from "./next-modules-fixtures";
  4  | import { expectAccessibleHome } from "../accessibility";
  5  | 
  6  | for (const colorScheme of ["light", "dark"] as const) {
  7  |   for (const state of ["new", "detail", "edit"] as const) {
  8  |     test(`Desktop Planner ${state} uses the Figma drawer at 1440 ${colorScheme}`, async ({ page }, info) => {
  9  |       await page.setViewportSize({ width: 1440, height: 1040 });
  10 |       await page.emulateMedia({ colorScheme, reducedMotion: "reduce" });
  11 |       await setup(page);
  12 |       await page.goto(state === "new" ? "/modules/planner" : `/modules/planner?task=${taskId}`);
  13 |       if (state === "new")
  14 |         await page.getByRole("button", { name: "+ New task", exact: true }).click();
  15 |       if (state === "edit")
  16 |         await page.getByRole("button", { name: "Edit task", exact: true }).click();
  17 |       const title = state === "new" ? "New task" : state === "edit" ? "Edit task" : nextTask.name;
  18 |       const dialog = page.getByRole("dialog", { name: title, exact: true });
  19 |       await expect(dialog).toBeVisible();
  20 |       const bounds = await dialog.boundingBox();
  21 |       await info.attach("drawer-geometry", { body: JSON.stringify({ state, colorScheme, reference: state === "detail" ? "411:100367" : "819:146214", bounds }), contentType: "application/json" });
  22 |       await page.screenshot({ path: info.outputPath("desktop-drawer.png") });
> 23 |       expect(bounds!.x).toBeCloseTo(760, 0);
     |                         ^ Error: expect(received).toBeCloseTo(expected, precision)
  24 |       expect(bounds!.y).toBeCloseTo(0, 0);
  25 |       expect(bounds!.width).toBeCloseTo(680, 0);
  26 |       expect(bounds!.height).toBeCloseTo(1040, 0);
  27 |       await expectAccessibleHome(page, info);
  28 |       await dialog.getByRole("button", { name: "Close dialog", exact: true }).click();
  29 |       await expect(dialog).toBeHidden();
  30 |     });
  31 |   }
  32 | }
  33 | 
```