# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-engagement-coverage.spec.ts >> Desktop Engagement overview and selected meeting preserve distinct intents at 1440 dark
- Location: test/browser/desktop-engagement-coverage.spec.ts:8:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Engagement', exact: true, level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Engagement', exact: true, level: 1 })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri
    - link "Portfolio":
      - /url: /
    - link "Modules":
      - /url: /modules
  - navigation "Workspace actions":
    - link "Quick log":
      - /url: /?log=1
    - link "Master calendar":
      - /url: /calendar
    - link "Search intelligence":
      - /url: /modules/intelligence
    - button "Updates — unavailable" [disabled]
    - link "Account settings":
      - /url: /settings/personal
- complementary:
  - paragraph: Modules
  - navigation "Modules":
    - link "Module hub":
      - /url: /modules
    - link "Engagement":
      - /url: /modules/engagement
    - link "Planner":
      - /url: /modules/planner
    - link "Calendar":
      - /url: /modules/calendar
    - link "Workspace":
      - /url: /modules/workspace
    - link "Strategies":
      - /url: /modules/strategies
    - link "Directory":
      - /url: /modules/directory
    - link "Intelligence":
      - /url: /modules/intelligence
    - link "Research portfolios":
      - /url: /modules/research-portfolios
  - link "Settings":
    - /url: /settings/personal
- main:
  - navigation "Breadcrumb":
    - link "← Modules":
      - /url: /modules
    - combobox "Switch module": Engagement
  - heading "Engagement Manager" [level=1]
  - paragraph: Meetings, outreach and commitments across your permitted clients.
  - combobox "Engagement client scope":
    - option "All permitted clients" [selected]
  - button "+ New meeting"
  - tablist "Engagement sections":
    - tab "Overview" [selected]
    - tab "Plan"
    - tab "Meetings"
    - tab "Outreach"
    - tab "Reports"
    - tab "Team"
    - tab "Library"
    - tab "Commitments"
  - paragraph: Visible meetings
  - strong: "1"
  - text: Current scope
  - paragraph: Outreach records
  - strong: "0"
  - text: Current scope
  - paragraph: Open commitments
  - strong: "0"
  - text: Current scope
  - paragraph: Target offices
  - strong: "0"
  - text: Current scope
  - heading "Across clients" [level=2]
  - paragraph: Meetings and open work returned for your current access.
  - table "Client engagement activity":
    - caption: Client engagement activity
    - rowgroup:
      - row "Client Meetings Open Next meeting":
        - columnheader "Client"
        - columnheader "Meetings"
        - columnheader "Open"
        - columnheader "Next meeting"
    - rowgroup:
      - row "Current Aerospace 1 0 None scheduled":
        - cell "Current Aerospace"
        - cell "1"
        - cell "0"
        - cell "None scheduled"
  - paragraph: Private notes and unshared mail remain visible only to their owner.
  - heading "Target offices" [level=2]
  - paragraph: Review coordination before the next ask.
  - button "Open reports →"
  - heading "Follow-ups needing attention" [level=2]
  - button "Open commitments →"
  - heading "Team workload" [level=2]
  - paragraph: Review follow-up ownership across visible work.
  - button "Open team workload →"
- complementary "Local test fixture": Explicit local test fixture · synthetic identity and records
```

# Test source

```ts
  1  | import { expect } from "@playwright/test";
  2  | import { test } from "./runtime-observed-test";
  3  | import { moduleRouteFixtures } from "./module-route-fixtures";
  4  | import { meeting, setup } from "./next-modules-fixtures";
  5  | import { expectAccessibleHome } from "../accessibility";
  6  | 
  7  | for (const colorScheme of ["light", "dark"] as const) {
  8  |   test(`Desktop Engagement overview and selected meeting preserve distinct intents at 1440 ${colorScheme}`, async ({
  9  |     page,
  10 |   }, info) => {
  11 |     await page.setViewportSize({ width: 1440, height: 1040 });
  12 |     await page.emulateMedia({ colorScheme, reducedMotion: "reduce" });
  13 |     await setup(page, {
  14 |       ...moduleRouteFixtures,
  15 |       "engagement.meetings": [meeting],
  16 |       "engagement.meeting": meeting,
  17 |       "engagement.notes": [],
  18 |       "engagement.debriefs": [],
  19 |     });
  20 |     await page.goto("/modules/engagement?view=overview");
  21 |     await expect(
  22 |       page.getByRole("heading", { name: "Engagement", exact: true, level: 1 }),
> 23 |     ).toBeVisible();
     |       ^ Error: expect(locator).toBeVisible() failed
  24 |     await expect(
  25 |       page.getByRole("tab", { name: "Overview", exact: true }),
  26 |     ).toHaveAttribute("aria-selected", "true");
  27 |     await page.screenshot({
  28 |       path: info.outputPath("desktop-engagement-overview.png"),
  29 |     });
  30 |     await page.getByRole("tab", { name: "Meetings", exact: true }).click();
  31 |     await page.getByRole("button", { name: /Current meeting/ }).click();
  32 |     const detail = page.getByRole("region", {
  33 |       name: "Selected meeting",
  34 |       exact: true,
  35 |     });
  36 |     const list = page.getByRole("region", {
  37 |       name: "Meeting list",
  38 |       exact: true,
  39 |     });
  40 |     await expect(detail).toBeVisible();
  41 |     await expect(list).toBeVisible();
  42 |     await info.attach("engagement-state-coverage", {
  43 |       body: JSON.stringify({
  44 |         overviewReference: "411:93988",
  45 |         selectedMeetingReference: "NO_ADMITTED_FULL_MODULES_DETAIL_FRAME",
  46 |         detail: await detail.boundingBox(),
  47 |         list: await list.boundingBox(),
  48 |         scope: "canonical local fixture; not native or full overview parity",
  49 |       }),
  50 |       contentType: "application/json",
  51 |     });
  52 |     await page.screenshot({
  53 |       path: info.outputPath("desktop-selected-meeting.png"),
  54 |     });
  55 |     await expectAccessibleHome(page, info);
  56 |   });
  57 | }
  58 | 
```