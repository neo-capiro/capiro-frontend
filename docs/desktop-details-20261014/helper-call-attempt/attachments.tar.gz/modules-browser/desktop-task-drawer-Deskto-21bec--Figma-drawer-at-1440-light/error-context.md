# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-task-drawer.spec.ts >> Desktop Planner edit uses the Figma drawer at 1440 light
- Location: test/browser/desktop-task-drawer.spec.ts:56:5

# Error details

```
TypeError: info.attach is not a function
```

# Page snapshot

```yaml
- generic:
  - generic:
    - generic:
      - link:
        - /url: "#main-content"
        - text: Skip to content
      - banner:
        - link:
          - /url: /
          - img
        - navigation:
          - link:
            - /url: /meri
            - generic:
              - img
          - link:
            - /url: /
            - generic:
              - img
          - link:
            - /url: /modules
            - generic:
              - img
        - navigation:
          - link:
            - /url: /?log=1
            - generic:
              - img
          - link:
            - /url: /calendar
            - generic:
              - img
          - link:
            - /url: /modules/intelligence
            - generic:
              - img
          - button [disabled]:
            - generic:
              - img
          - link:
            - /url: /settings/personal
            - generic:
              - img
      - generic:
        - complementary:
          - paragraph: Modules
          - navigation:
            - link:
              - /url: /modules
              - generic:
                - img
              - generic: Module hub
            - link:
              - /url: /modules/engagement
              - generic:
                - img
              - generic: Engagement
            - link:
              - /url: /modules/planner
              - generic:
                - img
              - generic: Planner
            - link:
              - /url: /modules/calendar
              - generic:
                - img
              - generic: Calendar
            - link:
              - /url: /modules/workspace
              - generic:
                - img
              - generic: Workspace
            - link:
              - /url: /modules/strategies
              - generic:
                - img
              - generic: Strategies
            - link:
              - /url: /modules/directory
              - generic:
                - img
              - generic: Directory
            - link:
              - /url: /modules/intelligence
              - generic:
                - img
              - generic: Intelligence
            - link:
              - /url: /modules/research-portfolios
              - generic:
                - img
              - generic: Research portfolios
          - link:
            - /url: /settings/personal
            - generic:
              - img
            - generic: Settings
        - main:
          - navigation:
            - link:
              - /url: /modules
              - text: ← Modules
            - generic: /
            - combobox:
              - generic: Planner
              - img
          - generic:
            - generic:
              - generic:
                - heading [level=1]: Planner
                - paragraph: Coordinate tasks, projects and capacity across your permitted work.
              - generic:
                - button: Refresh
            - tablist:
              - tab [selected]: My tasks
              - tab: All tasks
              - tab: Projects
              - tab: Inbox
              - tab: Portfolios
              - tab: Goals
              - tab: Workload
              - tab: Capacity
              - tab: Reporting
              - tab: Timesheets
              - tab: Templates
              - tab: Rules
              - tab: Forms
            - generic:
              - generic:
                - tablist:
                  - tab [selected]: List
                  - tab: Board
                  - tab: Calendar
                  - tab: Timeline
                  - tab: Gantt
                - button: + New task
              - generic:
                - searchbox
                - combobox:
                  - generic: Status · Open
                  - img
                - combobox:
                  - generic: All assignees
                  - img
                - combobox:
                  - generic: Priority · All
                  - img
                - button: Import CSV
                - button: Save view
                - button: My tasks settings
              - paragraph: Time is shown as hours:minutes. This page includes only work you can access.
              - generic:
                - table:
                  - caption: Planner tasks
                  - rowgroup:
                    - row:
                      - columnheader: Task name
                      - columnheader: Assignee
                      - columnheader: Due date
                      - columnheader: Priority
                      - columnheader: Status
                      - columnheader: Estimated
                      - columnheader: Actual
                  - rowgroup:
                    - row:
                      - cell:
                        - generic:
                          - checkbox
                          - button
                          - button: Test appropriation review
                      - cell: Test User
                      - cell: Oct 12
                      - cell:
                        - generic: high
                      - cell:
                        - generic: To do
                      - cell: 1:30
                      - cell: 0:15
    - complementary: Explicit local test fixture · synthetic identity and records
  - dialog:
    - banner:
      - generic:
        - heading [level=2]: Test appropriation review
        - paragraph: Synthetic review work
      - button: ×
    - generic:
      - generic:
        - generic:
          - generic: todo
          - generic: high
          - button: Edit task
          - button: Archive
        - generic:
          - generic:
            - term: Assignee
            - definition: Test User
          - generic:
            - term: Due
            - definition: Oct 12
          - generic:
            - term: Time
            - definition: 0:15 / 1:30
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Projects and dependencies
          - generic:
            - paragraph: 0 dependencies · 0 collaborators
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Subtasks
            - button: + Subtask
          - generic:
            - generic:
              - generic: todo
              - generic: Test appropriation review
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Attachments
              - paragraph: Files up to 25 MiB; backend checks task access for every transfer.
            - button: Upload attachment
          - button
          - generic:
            - paragraph: No attachments yet.
        - button: Add time
        - generic:
          - generic:
            - generic:
              - heading [level=2]: Activity
        - generic:
          - generic:
            - generic: Comment
            - textbox
          - button: Post comment
  - dialog "Edit task" [ref=e3]:
    - banner [ref=e4]:
      - heading "Edit task" [level=2] [ref=e6]
      - button "Close dialog" [ref=e7] [cursor=pointer]: ×
    - generic [ref=e9]:
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [ref=e12]: Task name
          - textbox "Task name" [ref=e13]: Test appropriation review
        - generic [ref=e14]:
          - generic [ref=e15]: Description
          - textbox "Description" [ref=e16]: Synthetic review work
        - generic [ref=e17]:
          - generic [ref=e18]: Assignee
          - combobox "Assignee" [ref=e19] [cursor=pointer]:
            - generic: Test User
            - img [ref=e20]
          - combobox [ref=e22]
        - group "Projects" [ref=e23]:
          - generic [ref=e24]: Projects
        - generic [ref=e25]:
          - generic [ref=e26]:
            - generic [ref=e27]: Start date
            - textbox "Start date" [ref=e28]
          - generic [ref=e29]:
            - generic [ref=e30]: Due date
            - textbox "Due date" [ref=e31]: 2026-10-12
          - generic [ref=e32]:
            - generic [ref=e33]: Start time
            - textbox "Start time" [disabled] [ref=e34]
          - generic [ref=e35]:
            - generic [ref=e36]: Due time
            - textbox "Due time" [ref=e37]
          - generic [ref=e38]:
            - generic [ref=e39]: Time zone
            - textbox "Time zone" [ref=e40]:
              - /placeholder: America/New_York
          - generic [ref=e41]:
            - generic [ref=e42]: Priority
            - combobox "Priority" [ref=e43] [cursor=pointer]:
              - generic: high
              - img [ref=e44]
            - combobox [ref=e46]
          - generic [ref=e47]:
            - generic [ref=e48]: Status
            - combobox "Status" [ref=e49] [cursor=pointer]:
              - generic: To do
              - img [ref=e50]
            - combobox [ref=e52]
          - generic [ref=e53]:
            - generic [ref=e54]: Estimated minutes
            - spinbutton "Estimated minutes" [ref=e55]: "90"
        - group [ref=e56]:
          - generic "Task type, repeat, collaborators and dependencies" [ref=e57]
          - generic [ref=e58]:
            - generic [ref=e59]:
              - generic [ref=e60]:
                - generic [ref=e61]: Task type
                - combobox "Task type" [ref=e62] [cursor=pointer]:
                  - generic: task
                  - img [ref=e63]
                - combobox [ref=e65]
              - generic [ref=e66]:
                - generic [ref=e67]: Tags (comma separated)
                - textbox "Tags (comma separated)" [ref=e68]
              - generic [ref=e69]:
                - generic [ref=e70]: Repeat
                - combobox "Repeat" [ref=e71] [cursor=pointer]:
                  - generic: none
                  - img [ref=e72]
                - combobox [ref=e74]
            - group "Collaborators" [ref=e75]:
              - generic [ref=e76]: Collaborators
              - generic [ref=e77]:
                - checkbox "Test User" [ref=e78]
                - text: Test User
            - group "Depends on" [ref=e79]:
              - generic [ref=e80]: Depends on
      - generic [ref=e81]:
        - button "Cancel" [ref=e82] [cursor=pointer]
        - button "Save task" [active] [ref=e83] [cursor=pointer]
```

# Test source

```ts
  53  |           ? element.value
  54  |           : element.textContent,
  55  |       foreground: css.color,
  56  |       fontSize: css.fontSize,
  57  |       fontWeight: css.fontWeight,
  58  |       ancestors,
  59  |     };
  60  |   });
  61  |   const blockers: string[] = [];
  62  |   for (const ancestor of evidence.ancestors) {
  63  |     if (
  64  |       ancestor.opacity !== "1" ||
  65  |       ancestor.filter !== "none" ||
  66  |       ancestor.backdropFilter !== "none" ||
  67  |       ancestor.mixBlendMode !== "normal"
  68  |     )
  69  |       blockers.push(`Unsupported compositing: ${JSON.stringify(ancestor)}`);
  70  |   }
  71  |   let backgrounds: string[] | undefined;
  72  |   const overlays: { channels: number[]; alpha: number }[] = [];
  73  |   for (const ancestor of evidence.ancestors) {
  74  |     if (ancestor.image !== "none") {
  75  |       const stops = ancestor.image.match(/rgba?\([^)]+\)/g);
  76  |       if (
  77  |         !ancestor.image.startsWith("linear-gradient(") ||
  78  |         !stops ||
  79  |         stops.length !== 2
  80  |       )
  81  |         blockers.push(`Unsupported image: ${ancestor.image}`);
  82  |       else {
  83  |         backgrounds = stops;
  84  |         for (const stop of stops) {
  85  |           const channels = stop.match(/[\d.]+/g)!.map(Number);
  86  |           if (
  87  |             channels[0] !== channels[1] ||
  88  |             channels[1] !== channels[2] ||
  89  |             (channels[3] !== undefined && channels[3] !== 1)
  90  |           )
  91  |             blockers.push(`Nonopaque or nongrayscale gradient: ${stop}`);
  92  |         }
  93  |       }
  94  |       break;
  95  |     }
  96  |     if (
  97  |       ancestor.background !== "rgba(0, 0, 0, 0)" &&
  98  |       ancestor.background !== "transparent"
  99  |     ) {
  100 |       const channels = ancestor.background.match(/[\d.]+/g)?.map(Number);
  101 |       if (
  102 |         !/^rgba?\(/.test(ancestor.background) ||
  103 |         !channels ||
  104 |         ![3, 4].includes(channels.length) ||
  105 |         channels.some((value) => !Number.isFinite(value))
  106 |       ) {
  107 |         blockers.push(`Unsupported solid background: ${ancestor.background}`);
  108 |         break;
  109 |       }
  110 |       const alpha = channels[3] ?? 1;
  111 |       if (
  112 |         alpha < 0 ||
  113 |         alpha > 1 ||
  114 |         channels.slice(0, 3).some((value) => value < 0 || value > 255)
  115 |       ) {
  116 |         blockers.push(`Invalid solid background: ${ancestor.background}`);
  117 |         break;
  118 |       }
  119 |       if (alpha < 1) {
  120 |         overlays.push({ channels: channels.slice(0, 3), alpha });
  121 |         continue;
  122 |       }
  123 |       backgrounds = [ancestor.background];
  124 |       break;
  125 |     }
  126 |   }
  127 |   backgrounds = backgrounds?.map((background) => {
  128 |     let channels = background
  129 |       .match(/[\d.]+/g)!
  130 |       .map(Number)
  131 |       .slice(0, 3);
  132 |     for (const overlay of [...overlays].reverse())
  133 |       channels = channels.map(
  134 |         (value, index) =>
  135 |           overlay.channels[index]! * overlay.alpha +
  136 |           value * (1 - overlay.alpha),
  137 |       );
  138 |     return `rgb(${channels.join(", ")})`;
  139 |   });
  140 |   const foreground = luminance(evidence.foreground);
  141 |   const values = backgrounds?.map(luminance) ?? [];
  142 |   const contrasts = values.map(
  143 |     (background) =>
  144 |       (Math.max(foreground, background) + 0.05) /
  145 |       (Math.min(foreground, background) + 0.05),
  146 |   );
  147 |   if (
  148 |     values.length === 2 &&
  149 |     foreground >= Math.min(...values) &&
  150 |     foreground <= Math.max(...values)
  151 |   )
  152 |     contrasts.push(1);
> 153 |   await info.attach(`rendered-contrast-${label}`, {
      |              ^ TypeError: info.attach is not a function
  154 |     body: JSON.stringify(
  155 |       { ...evidence, overlays, backgrounds, contrasts, blockers },
  156 |       null,
  157 |       2,
  158 |     ),
  159 |     contentType: "application/json",
  160 |   });
  161 |   expect(blockers).toEqual([]);
  162 |   expect(backgrounds?.length).toBeGreaterThan(0);
  163 |   expect(Math.min(...contrasts)).toBeGreaterThanOrEqual(4.5);
  164 | }
  165 | 
  166 | /** Preserve axe's incomplete report and separately resolve its rendered bounds. */
  167 | export async function expectGradientIncompletes(
  168 |   page: Page,
  169 |   info: TestInfo,
  170 |   incomplete: AxeResults["incomplete"],
  171 | ) {
  172 |   for (const rule of incomplete) {
  173 |     expect(rule.id).toBe("color-contrast");
  174 |     for (const [index, node] of rule.nodes.entries()) {
  175 |       expect(node.target).toHaveLength(1);
  176 |       const selector = node.target[0];
  177 |       if (typeof selector !== "string")
  178 |         throw new Error(
  179 |           "Nested contrast target requires separate rendered review",
  180 |         );
  181 |       await expectRenderedContrast(
  182 |         page.locator(selector),
  183 |         info,
  184 |         `axe-incomplete-${index}`,
  185 |       );
  186 |     }
  187 |   }
  188 | }
  189 | 
```