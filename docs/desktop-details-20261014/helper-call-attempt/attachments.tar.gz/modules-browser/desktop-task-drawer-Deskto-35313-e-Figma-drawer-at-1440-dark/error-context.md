# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-task-drawer.spec.ts >> Desktop Planner new uses the Figma drawer at 1440 dark
- Location: test/browser/desktop-task-drawer.spec.ts:56:5

# Error details

```
TypeError: info.attach is not a function
```

# Page snapshot

```yaml
- generic:
  - generic:
    - generic:
      - link:
        - /url: "#main-content"
        - text: Skip to content
      - banner:
        - link:
          - /url: /
          - img
        - navigation:
          - link:
            - /url: /meri
            - generic:
              - img
          - link:
            - /url: /
            - generic:
              - img
          - link:
            - /url: /modules
            - generic:
              - img
        - navigation:
          - link:
            - /url: /?log=1
            - generic:
              - img
          - link:
            - /url: /calendar
            - generic:
              - img
          - link:
            - /url: /modules/intelligence
            - generic:
              - img
          - button [disabled]:
            - generic:
              - img
          - link:
            - /url: /settings/personal
            - generic:
              - img
      - generic:
        - complementary:
          - paragraph: Modules
          - navigation:
            - link:
              - /url: /modules
              - generic:
                - img
              - generic: Module hub
            - link:
              - /url: /modules/engagement
              - generic:
                - img
              - generic: Engagement
            - link:
              - /url: /modules/planner
              - generic:
                - img
              - generic: Planner
            - link:
              - /url: /modules/calendar
              - generic:
                - img
              - generic: Calendar
            - link:
              - /url: /modules/workspace
              - generic:
                - img
              - generic: Workspace
            - link:
              - /url: /modules/strategies
              - generic:
                - img
              - generic: Strategies
            - link:
              - /url: /modules/directory
              - generic:
                - img
              - generic: Directory
            - link:
              - /url: /modules/intelligence
              - generic:
                - img
              - generic: Intelligence
            - link:
              - /url: /modules/research-portfolios
              - generic:
                - img
              - generic: Research portfolios
          - link:
            - /url: /settings/personal
            - generic:
              - img
            - generic: Settings
        - main:
          - navigation:
            - link:
              - /url: /modules
              - text: ← Modules
            - generic: /
            - combobox:
              - generic: Planner
              - img
          - generic:
            - generic:
              - generic:
                - heading [level=1]: Planner
                - paragraph: Coordinate tasks, projects and capacity across your permitted work.
              - generic:
                - button: Refresh
            - tablist:
              - tab [selected]: My tasks
              - tab: All tasks
              - tab: Projects
              - tab: Inbox
              - tab: Portfolios
              - tab: Goals
              - tab: Workload
              - tab: Capacity
              - tab: Reporting
              - tab: Timesheets
              - tab: Templates
              - tab: Rules
              - tab: Forms
            - generic:
              - generic:
                - tablist:
                  - tab [selected]: List
                  - tab: Board
                  - tab: Calendar
                  - tab: Timeline
                  - tab: Gantt
                - button: + New task
              - generic:
                - searchbox
                - combobox:
                  - generic: Status · Open
                  - img
                - combobox:
                  - generic: All assignees
                  - img
                - combobox:
                  - generic: Priority · All
                  - img
                - button: Import CSV
                - button: Save view
                - button: My tasks settings
              - paragraph: Time is shown as hours:minutes. This page includes only work you can access.
              - generic:
                - table:
                  - caption: Planner tasks
                  - rowgroup:
                    - row:
                      - columnheader: Task name
                      - columnheader: Assignee
                      - columnheader: Due date
                      - columnheader: Priority
                      - columnheader: Status
                      - columnheader: Estimated
                      - columnheader: Actual
                  - rowgroup:
                    - row:
                      - cell:
                        - generic:
                          - checkbox
                          - button
                          - button: Test appropriation review
                      - cell: Test User
                      - cell: Oct 12
                      - cell:
                        - generic: high
                      - cell:
                        - generic: To do
                      - cell: 1:30
                      - cell: 0:15
    - complementary: Explicit local test fixture · synthetic identity and records
  - dialog "New task" [ref=e2]:
    - banner [ref=e3]:
      - heading "New task" [level=2] [ref=e5]
      - button "Close dialog" [ref=e6] [cursor=pointer]: ×
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - generic [ref=e11]: Task name
          - textbox "Task name" [ref=e12]
        - generic [ref=e13]:
          - generic [ref=e14]: Description
          - textbox "Description" [ref=e15]
        - generic [ref=e16]:
          - generic [ref=e17]: Assignee
          - combobox "Assignee" [ref=e18] [cursor=pointer]:
            - generic: Unassigned
            - img [ref=e19]
          - combobox [ref=e21]
        - group "Projects" [ref=e22]:
          - generic [ref=e23]: Projects
        - generic [ref=e24]:
          - generic [ref=e25]:
            - generic [ref=e26]: Start date
            - textbox "Start date" [ref=e27]
          - generic [ref=e28]:
            - generic [ref=e29]: Due date
            - textbox "Due date" [ref=e30]
          - generic [ref=e31]:
            - generic [ref=e32]: Start time
            - textbox "Start time" [disabled] [ref=e33]
          - generic [ref=e34]:
            - generic [ref=e35]: Due time
            - textbox "Due time" [disabled] [ref=e36]
          - generic [ref=e37]:
            - generic [ref=e38]: Time zone
            - textbox "Time zone" [ref=e39]:
              - /placeholder: America/New_York
          - generic [ref=e40]:
            - generic [ref=e41]: Priority
            - combobox "Priority" [ref=e42] [cursor=pointer]:
              - generic: none
              - img [ref=e43]
            - combobox [ref=e45]
          - generic [ref=e46]:
            - generic [ref=e47]: Status
            - combobox "Status" [ref=e48] [cursor=pointer]:
              - generic: To do
              - img [ref=e49]
            - combobox [ref=e51]
          - generic [ref=e52]:
            - generic [ref=e53]: Estimated minutes
            - spinbutton "Estimated minutes" [ref=e54]: "0"
        - group [ref=e55]:
          - generic "Task type, repeat, collaborators and dependencies" [ref=e56]
          - generic [ref=e57]:
            - generic [ref=e58]:
              - generic [ref=e59]:
                - generic [ref=e60]: Task type
                - combobox "Task type" [ref=e61] [cursor=pointer]:
                  - generic: task
                  - img [ref=e62]
                - combobox [ref=e64]
              - generic [ref=e65]:
                - generic [ref=e66]: Tags (comma separated)
                - textbox "Tags (comma separated)" [ref=e67]
              - generic [ref=e68]:
                - generic [ref=e69]: Repeat
                - combobox "Repeat" [ref=e70] [cursor=pointer]:
                  - generic: none
                  - img [ref=e71]
                - combobox [ref=e73]
            - group "Collaborators" [ref=e74]:
              - generic [ref=e75]: Collaborators
              - generic [ref=e76]:
                - checkbox "Test User" [ref=e77]
                - text: Test User
            - group "Depends on" [ref=e78]:
              - generic [ref=e79]: Depends on
              - generic [ref=e80]:
                - checkbox "Test appropriation review" [ref=e81]
                - text: Test appropriation review
      - generic [ref=e82]:
        - button "Cancel" [ref=e83] [cursor=pointer]
        - button "Save task" [active] [ref=e84] [cursor=pointer]
```

# Test source

```ts
  53  |           ? element.value
  54  |           : element.textContent,
  55  |       foreground: css.color,
  56  |       fontSize: css.fontSize,
  57  |       fontWeight: css.fontWeight,
  58  |       ancestors,
  59  |     };
  60  |   });
  61  |   const blockers: string[] = [];
  62  |   for (const ancestor of evidence.ancestors) {
  63  |     if (
  64  |       ancestor.opacity !== "1" ||
  65  |       ancestor.filter !== "none" ||
  66  |       ancestor.backdropFilter !== "none" ||
  67  |       ancestor.mixBlendMode !== "normal"
  68  |     )
  69  |       blockers.push(`Unsupported compositing: ${JSON.stringify(ancestor)}`);
  70  |   }
  71  |   let backgrounds: string[] | undefined;
  72  |   const overlays: { channels: number[]; alpha: number }[] = [];
  73  |   for (const ancestor of evidence.ancestors) {
  74  |     if (ancestor.image !== "none") {
  75  |       const stops = ancestor.image.match(/rgba?\([^)]+\)/g);
  76  |       if (
  77  |         !ancestor.image.startsWith("linear-gradient(") ||
  78  |         !stops ||
  79  |         stops.length !== 2
  80  |       )
  81  |         blockers.push(`Unsupported image: ${ancestor.image}`);
  82  |       else {
  83  |         backgrounds = stops;
  84  |         for (const stop of stops) {
  85  |           const channels = stop.match(/[\d.]+/g)!.map(Number);
  86  |           if (
  87  |             channels[0] !== channels[1] ||
  88  |             channels[1] !== channels[2] ||
  89  |             (channels[3] !== undefined && channels[3] !== 1)
  90  |           )
  91  |             blockers.push(`Nonopaque or nongrayscale gradient: ${stop}`);
  92  |         }
  93  |       }
  94  |       break;
  95  |     }
  96  |     if (
  97  |       ancestor.background !== "rgba(0, 0, 0, 0)" &&
  98  |       ancestor.background !== "transparent"
  99  |     ) {
  100 |       const channels = ancestor.background.match(/[\d.]+/g)?.map(Number);
  101 |       if (
  102 |         !/^rgba?\(/.test(ancestor.background) ||
  103 |         !channels ||
  104 |         ![3, 4].includes(channels.length) ||
  105 |         channels.some((value) => !Number.isFinite(value))
  106 |       ) {
  107 |         blockers.push(`Unsupported solid background: ${ancestor.background}`);
  108 |         break;
  109 |       }
  110 |       const alpha = channels[3] ?? 1;
  111 |       if (
  112 |         alpha < 0 ||
  113 |         alpha > 1 ||
  114 |         channels.slice(0, 3).some((value) => value < 0 || value > 255)
  115 |       ) {
  116 |         blockers.push(`Invalid solid background: ${ancestor.background}`);
  117 |         break;
  118 |       }
  119 |       if (alpha < 1) {
  120 |         overlays.push({ channels: channels.slice(0, 3), alpha });
  121 |         continue;
  122 |       }
  123 |       backgrounds = [ancestor.background];
  124 |       break;
  125 |     }
  126 |   }
  127 |   backgrounds = backgrounds?.map((background) => {
  128 |     let channels = background
  129 |       .match(/[\d.]+/g)!
  130 |       .map(Number)
  131 |       .slice(0, 3);
  132 |     for (const overlay of [...overlays].reverse())
  133 |       channels = channels.map(
  134 |         (value, index) =>
  135 |           overlay.channels[index]! * overlay.alpha +
  136 |           value * (1 - overlay.alpha),
  137 |       );
  138 |     return `rgb(${channels.join(", ")})`;
  139 |   });
  140 |   const foreground = luminance(evidence.foreground);
  141 |   const values = backgrounds?.map(luminance) ?? [];
  142 |   const contrasts = values.map(
  143 |     (background) =>
  144 |       (Math.max(foreground, background) + 0.05) /
  145 |       (Math.min(foreground, background) + 0.05),
  146 |   );
  147 |   if (
  148 |     values.length === 2 &&
  149 |     foreground >= Math.min(...values) &&
  150 |     foreground <= Math.max(...values)
  151 |   )
  152 |     contrasts.push(1);
> 153 |   await info.attach(`rendered-contrast-${label}`, {
      |              ^ TypeError: info.attach is not a function
  154 |     body: JSON.stringify(
  155 |       { ...evidence, overlays, backgrounds, contrasts, blockers },
  156 |       null,
  157 |       2,
  158 |     ),
  159 |     contentType: "application/json",
  160 |   });
  161 |   expect(blockers).toEqual([]);
  162 |   expect(backgrounds?.length).toBeGreaterThan(0);
  163 |   expect(Math.min(...contrasts)).toBeGreaterThanOrEqual(4.5);
  164 | }
  165 | 
  166 | /** Preserve axe's incomplete report and separately resolve its rendered bounds. */
  167 | export async function expectGradientIncompletes(
  168 |   page: Page,
  169 |   info: TestInfo,
  170 |   incomplete: AxeResults["incomplete"],
  171 | ) {
  172 |   for (const rule of incomplete) {
  173 |     expect(rule.id).toBe("color-contrast");
  174 |     for (const [index, node] of rule.nodes.entries()) {
  175 |       expect(node.target).toHaveLength(1);
  176 |       const selector = node.target[0];
  177 |       if (typeof selector !== "string")
  178 |         throw new Error(
  179 |           "Nested contrast target requires separate rendered review",
  180 |         );
  181 |       await expectRenderedContrast(
  182 |         page.locator(selector),
  183 |         info,
  184 |         `axe-incomplete-${index}`,
  185 |       );
  186 |     }
  187 |   }
  188 | }
  189 | 
```