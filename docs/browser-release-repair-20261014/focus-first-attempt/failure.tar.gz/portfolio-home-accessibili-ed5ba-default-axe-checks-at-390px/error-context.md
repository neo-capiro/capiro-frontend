# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-home-accessibility.spec.ts >> Portfolio home preserves accessible names, descriptions and default axe checks at 390px
- Location: tests/browser/portfolio-home-accessibility.spec.ts:10:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 2
Received:    1
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - button "Toggle navigation" [ref=e5] [cursor=pointer]:
      - img [ref=e6]
    - link "Capiro Home" [ref=e7] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e8]
    - navigation "Workspace" [ref=e9]:
      - link "Meri" [ref=e10] [cursor=pointer]:
        - /url: /meri
      - link "Portfolio" [ref=e11] [cursor=pointer]:
        - /url: /
      - link "Modules" [ref=e12] [cursor=pointer]:
        - /url: /modules
    - navigation "Global actions" [ref=e13]:
      - link "Quick log" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?log=1
      - link "Master calendar" [ref=e15] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e16] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e17]
      - button "Test account" [ref=e19] [cursor=pointer]: T
  - main [ref=e21]:
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Your client portfolio
          - heading "Portfolio 1" [level=1] [ref=e26]
        - generic [ref=e27]:
          - combobox "Account owner" [ref=e29]:
            - option "All owners" [selected]
            - option "Unassigned"
          - generic [ref=e30]:
            - img [ref=e31]
            - textbox "Search profiles" [ref=e34]:
              - /placeholder: Search profiles…
          - button "Customize" [ref=e35] [cursor=pointer]
          - button "Add profile" [ref=e36] [cursor=pointer]:
            - img [ref=e37]
            - text: Add profile
      - region "Portfolio pulse" [ref=e38]:
        - generic [ref=e40]:
          - strong [ref=e41]: —
          - generic [ref=e42]:
            - text: of work linked
            - text: to an objective
        - region "Portfolio pulse metrics" [active] [ref=e43]:
          - generic [ref=e44]:
            - strong [ref=e45]: "1"
            - generic [ref=e46]: Clients
          - generic [ref=e47]:
            - strong [ref=e48]: —
            - generic [ref=e49]: Need attention
          - generic [ref=e50]:
            - strong [ref=e51]: —
            - generic [ref=e52]: Objectives
          - generic [ref=e53]:
            - strong [ref=e54]: —
            - generic [ref=e55]: Off track
          - generic [ref=e56]:
            - strong [ref=e57]: —
            - generic [ref=e58]: Strategies
      - generic [ref=e59]:
        - complementary "Needs attention" [ref=e60]:
          - generic [ref=e61]:
            - heading "Needs attention" [level=2] [ref=e62]
            - note "0 shown alerts" [ref=e63]: 0 shown
            - generic "Ordered by the source service" [ref=e64]: ↑↓ Most urgent
          - paragraph [ref=e65]: Updates automatically. Open an item in its client profile.
          - status [ref=e66]: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
          - generic [ref=e67]:
            - paragraph [ref=e68]: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
            - generic [ref=e69]:
              - generic [ref=e70]:
                - text: Snapshot
                - time [ref=e71]: Oct 11, 6:00 AM UTC
              - button "Refresh alerts" [ref=e72] [cursor=pointer]
        - region "Portfolio profiles" [ref=e73]:
          - navigation "Profile type" [ref=e74]:
            - button "All 1" [pressed] [ref=e75] [cursor=pointer]:
              - text: All
              - generic [ref=e76]: "1"
            - button "Clients 1" [ref=e77] [cursor=pointer]:
              - text: Clients
              - generic [ref=e78]: "1"
            - link "Prospects" [ref=e79] [cursor=pointer]:
              - /url: /portfolio/prospects
            - link "Pipeline" [ref=e80] [cursor=pointer]:
              - /url: /portfolio/prospects?pipeline=1
            - generic [ref=e81]:
              - button "New objective" [ref=e82] [cursor=pointer]
              - group [ref=e83]:
                - generic "Filters and view" [ref=e84] [cursor=pointer]
                - option "All statuses" [selected]
                - option "ACTIVE"
                - option "All sectors" [selected]
                - option "Aerospace"
                - option "Saved order" [selected]
                - option "Recently added"
                - option "Name A–Z"
          - status [ref=e85]: 1 profile
          - button "Refresh profiles" [ref=e86] [cursor=pointer]
          - region "Organization profile order" [ref=e87]:
            - status [ref=e88]:
              - text: Saved profile ordering is unavailable in this environment. Reordering requires a current accessible catalog. Your ordinary view remains available.
              - button "Retry saved order" [ref=e89] [cursor=pointer]
            - article [ref=e92]:
              - generic [ref=e93]:
                - generic [ref=e94]: TA
                - generic [ref=e95]:
                  - heading "Open Test Aerospace" [level=2] [ref=e96]:
                    - link "Open Test Aerospace" [ref=e97] [cursor=pointer]:
                      - /url: /portfolio/10000000-0000-4000-8000-000000000001
                      - text: Test Aerospace
                  - generic [ref=e98]: Aerospace
              - generic [ref=e99]:
                - 'note "Profile status: ACTIVE" [ref=e100]': ACTIVE
                - 'img "Account owner: unavailable" [ref=e101]': —
            - status [ref=e102]
          - button "+ Add profile" [ref=e103] [cursor=pointer]
```

# Test source

```ts
  1   | import {
  2   |   expect,
  3   |   type Locator,
  4   |   type Page,
  5   |   type TestInfo,
  6   | } from "@playwright/test";
  7   | 
  8   | /** Test-only observation; never provides data or session/approval authority. */
  9   | export async function observeHomeIsolation(page: Page, testInfo: TestInfo) {
  10  |   const baseURL = testInfo.project.use.baseURL;
  11  |   if (!baseURL) throw new Error("A leased local baseURL is required");
  12  |   const origin = new URL(baseURL).origin;
  13  |   const foreign: string[] = [],
  14  |     errors: string[] = [];
  15  |   page.on("pageerror", (error) => errors.push(error.message));
  16  |   await page.route("**/*", (route) => {
  17  |     const requested = route.request().url();
  18  |     if (new URL(requested).origin !== origin) {
  19  |       foreign.push(requested);
  20  |       return route.abort("blockedbyclient");
  21  |     }
  22  |     return route.fallback();
  23  |   });
  24  |   return () => {
  25  |     expect(foreign).toEqual([]);
  26  |     expect(errors).toEqual([]);
  27  |   };
  28  | }
  29  | 
  30  | /** Reach the actual sequential focus order, without forced focus or sleeps. */
  31  | export async function tabTo(page: Page, target: Locator) {
  32  |   await expect(target).toBeVisible();
  33  |   for (let step = 0; step < 64; step += 1) {
  34  |     await page.keyboard.press("Tab");
  35  |     // Finish focus-induced scrolling before advancing to another control.
  36  |     await page.evaluate(
  37  |       () =>
  38  |         new Promise<void>((resolve) => requestAnimationFrame(() => resolve())),
  39  |     );
  40  |     if (await target.evaluate((element) => element === document.activeElement))
  41  |       return;
  42  |   }
  43  |   await expect(target).toBeFocused();
  44  | }
  45  | 
  46  | export async function expectFocusEvidence(target: Locator, testInfo: TestInfo) {
  47  |   await expect(target).toBeFocused();
  48  |   const focus = await target.evaluate((element) => {
  49  |     const style = getComputedStyle(element);
  50  |     const rect = element.getBoundingClientRect();
  51  |     return {
  52  |       focusVisible: element.matches(":focus-visible"),
  53  |       outlineStyle: style.outlineStyle,
  54  |       outlineWidth: parseFloat(style.outlineWidth),
  55  |       outlineColor: style.outlineColor,
  56  |       inViewport:
  57  |         rect.top >= 0 &&
  58  |         rect.bottom <= innerHeight &&
  59  |         rect.left >= 0 &&
  60  |         rect.right <= innerWidth,
  61  |     };
  62  |   });
  63  |   await testInfo.attach("focused-control-style", {
  64  |     body: JSON.stringify(focus, null, 2),
  65  |     contentType: "application/json",
  66  |   });
  67  |   expect(focus.focusVisible).toBe(true);
  68  |   expect(focus.outlineStyle).not.toBe("none");
> 69  |   expect(focus.outlineWidth).toBeGreaterThanOrEqual(2);
      |                              ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  70  |   expect(focus.outlineColor).not.toMatch(/transparent|rgba\([^)]*, 0\)$/);
  71  |   expect(focus.inViewport).toBe(true);
  72  |   await testInfo.attach("focused-control-page", {
  73  |     body: await target.page().screenshot({ fullPage: true }),
  74  |     contentType: "image/png",
  75  |   });
  76  | }
  77  | 
  78  | /** Assert the browser's real hit target before an unforced pointer click. */
  79  | export async function pointWithLink(
  80  |   page: Page,
  81  |   target: Locator,
  82  |   expectedLink: string | null,
  83  | ) {
  84  |   await target.scrollIntoViewIfNeeded();
  85  |   const rect = await target.boundingBox();
  86  |   if (!rect) throw new Error("Visible pointer target has no bounds");
  87  |   const point = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
  88  |   const hitLink = await page.evaluate(
  89  |     ({ x, y }) =>
  90  |       document.elementFromPoint(x, y)?.closest("a")?.getAttribute("href") ??
  91  |       null,
  92  |     point,
  93  |   );
  94  |   expect(hitLink).toBe(expectedLink);
  95  |   return point;
  96  | }
  97  | 
  98  | export async function clickObservedPoint(
  99  |   page: Page,
  100 |   target: Locator,
  101 |   expectedLink: string | null,
  102 | ) {
  103 |   const point = await pointWithLink(page, target, expectedLink);
  104 |   await page.mouse.click(point.x, point.y);
  105 | }
  106 | 
```