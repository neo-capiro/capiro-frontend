# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-portfolio-incompletes.spec.ts >> Portfolio incomplete contrast and names are reviewed at 390px dark
- Location: tests/browser/acceptance-portfolio-incompletes.spec.ts:11:5

# Error details

```
Error: Expected opaque computed RGB: rgba(255, 255, 255, 0.02)
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - button "Toggle navigation" [ref=e5] [cursor=pointer]:
      - img [ref=e6]
    - link "Capiro Home" [ref=e7] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e8]
    - navigation "Workspace" [ref=e9]:
      - link "Meri" [ref=e10] [cursor=pointer]:
        - /url: /meri
      - link "Portfolio" [ref=e11] [cursor=pointer]:
        - /url: /
      - link "Modules" [ref=e12] [cursor=pointer]:
        - /url: /modules
    - navigation "Global actions" [ref=e13]:
      - link "Quick log" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?log=1
      - link "Master calendar" [ref=e15] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e16] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e17]
      - button "Test account" [ref=e19] [cursor=pointer]: T
  - main [ref=e21]:
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Your client portfolio
          - heading "Portfolio 1" [level=1] [ref=e26]
        - generic [ref=e27]:
          - combobox "Account owner" [ref=e29]:
            - option "All owners" [selected]
            - option "Unassigned"
          - generic [ref=e30]:
            - img [ref=e31]
            - textbox "Search profiles" [ref=e34]:
              - /placeholder: Search profiles…
          - button "Customize" [ref=e35] [cursor=pointer]
          - button "Add profile" [ref=e36] [cursor=pointer]:
            - img [ref=e37]
            - text: Add profile
      - region "Portfolio pulse" [ref=e38]:
        - generic [ref=e40]:
          - strong [ref=e41]: —
          - generic [ref=e42]:
            - text: of work linked
            - text: to an objective
        - generic [ref=e43]:
          - generic [ref=e44]:
            - strong [ref=e45]: "1"
            - generic [ref=e46]: Clients
          - generic [ref=e47]:
            - strong [ref=e48]: —
            - generic [ref=e49]: Need attention
          - generic [ref=e50]:
            - strong [ref=e51]: —
            - generic [ref=e52]: Objectives
          - generic [ref=e53]:
            - strong [ref=e54]: —
            - generic [ref=e55]: Off track
          - generic [ref=e56]:
            - strong [ref=e57]: —
            - generic [ref=e58]: Strategies
      - generic [ref=e59]:
        - complementary "Needs attention" [ref=e60]:
          - generic [ref=e61]:
            - heading "Needs attention" [level=2] [ref=e62]
            - note "0 shown alerts" [ref=e63]: 0 shown
            - generic "Ordered by the source service" [ref=e64]: ↑↓ Most urgent
          - paragraph [ref=e65]: Updates automatically. Open an item in its client profile.
          - status [ref=e66]: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
          - generic [ref=e67]:
            - paragraph [ref=e68]: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
            - generic [ref=e69]:
              - generic [ref=e70]:
                - text: Snapshot
                - time [ref=e71]: Oct 11, 6:00 AM UTC
              - button "Refresh alerts" [ref=e72] [cursor=pointer]
        - region "Portfolio profiles" [ref=e73]:
          - navigation "Profile type" [ref=e74]:
            - button "All 1" [pressed] [ref=e75] [cursor=pointer]:
              - text: All
              - generic [ref=e76]: "1"
            - button "Clients 1" [ref=e77] [cursor=pointer]:
              - text: Clients
              - generic [ref=e78]: "1"
            - link "Prospects" [ref=e79] [cursor=pointer]:
              - /url: /portfolio/prospects
            - link "Pipeline" [ref=e80] [cursor=pointer]:
              - /url: /portfolio/prospects?pipeline=1
            - generic [ref=e81]:
              - button "New objective" [ref=e82] [cursor=pointer]
              - group [ref=e83]:
                - generic "Filters and view" [ref=e84] [cursor=pointer]
                - option "All statuses" [selected]
                - option "ACTIVE"
                - option "All sectors" [selected]
                - option "Aerospace"
                - option "Saved order" [selected]
                - option "Recently added"
                - option "Name A–Z"
          - status [ref=e85]: 1 profile
          - button "Refresh profiles" [ref=e86] [cursor=pointer]
          - region "Organization profile order" [ref=e87]:
            - status [ref=e88]:
              - text: Saved profile ordering is unavailable in this environment. Reordering requires a current accessible catalog. Your ordinary view remains available.
              - button "Retry saved order" [ref=e89] [cursor=pointer]
            - article [ref=e92]:
              - generic [ref=e93]:
                - generic [ref=e94]: TA
                - generic [ref=e95]:
                  - heading "Open Test Aerospace" [level=2] [ref=e96]:
                    - link "Open Test Aerospace" [ref=e97] [cursor=pointer]:
                      - /url: /portfolio/10000000-0000-4000-8000-000000000001
                      - text: Test Aerospace
                  - generic [ref=e98]: Aerospace
              - generic [ref=e99]:
                - 'note "Profile status: ACTIVE" [ref=e100]': ACTIVE
                - 'img "Account owner: unavailable" [ref=e101]': —
            - status [ref=e102]
          - button "+ Add profile" [ref=e103] [cursor=pointer]
```

# Test source

```ts
  1   | import {
  2   |   expect,
  3   |   type Locator,
  4   |   type Page,
  5   |   type TestInfo,
  6   | } from "@playwright/test";
  7   | import type { AxeResults } from "axe-core";
  8   | 
  9   | function luminance(color: string) {
  10  |   const channels = color.match(/[\d.]+/g)?.map(Number);
  11  |   if (
  12  |     !channels ||
  13  |     channels.length < 3 ||
  14  |     (channels[3] !== undefined && channels[3] !== 1)
  15  |   )
> 16  |     throw new Error(`Expected opaque computed RGB: ${color}`);
      |           ^ Error: Expected opaque computed RGB: rgba(255, 255, 255, 0.02)
  17  |   const linear = channels.slice(0, 3).map((value) => {
  18  |     const srgb = value / 255;
  19  |     return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
  20  |   });
  21  |   return linear[0]! * 0.2126 + linear[1]! * 0.7152 + linear[2]! * 0.0722;
  22  | }
  23  | 
  24  | /** Bounds opaque grayscale gradients using actual rendered ancestor/compositing data.
  25  |  * Unsupported effects fail for manual review; they never silently receive a pass. */
  26  | export async function expectRenderedContrast(
  27  |   target: Locator,
  28  |   info: TestInfo,
  29  |   label: string,
  30  | ) {
  31  |   await expect(target).toBeVisible();
  32  |   const evidence = await target.evaluate((element) => {
  33  |     const css = getComputedStyle(element);
  34  |     const ancestors = [];
  35  |     let node: Element | null = element;
  36  |     while (node) {
  37  |       const style = getComputedStyle(node);
  38  |       ancestors.push({
  39  |         tag: node.tagName,
  40  |         background: style.backgroundColor,
  41  |         image: style.backgroundImage,
  42  |         opacity: style.opacity,
  43  |         filter: style.filter,
  44  |         backdropFilter: style.backdropFilter,
  45  |         mixBlendMode: style.mixBlendMode,
  46  |       });
  47  |       node = node.parentElement;
  48  |     }
  49  |     return {
  50  |       text:
  51  |         element instanceof HTMLTextAreaElement ||
  52  |         element instanceof HTMLInputElement
  53  |           ? element.value
  54  |           : element.textContent,
  55  |       foreground: css.color,
  56  |       fontSize: css.fontSize,
  57  |       fontWeight: css.fontWeight,
  58  |       ancestors,
  59  |     };
  60  |   });
  61  |   const blockers: string[] = [];
  62  |   for (const ancestor of evidence.ancestors) {
  63  |     if (
  64  |       ancestor.opacity !== "1" ||
  65  |       ancestor.filter !== "none" ||
  66  |       ancestor.backdropFilter !== "none" ||
  67  |       ancestor.mixBlendMode !== "normal"
  68  |     )
  69  |       blockers.push(`Unsupported compositing: ${JSON.stringify(ancestor)}`);
  70  |   }
  71  |   let backgrounds: string[] | undefined;
  72  |   for (const ancestor of evidence.ancestors) {
  73  |     if (ancestor.image !== "none") {
  74  |       const stops = ancestor.image.match(/rgba?\([^)]+\)/g);
  75  |       if (
  76  |         !ancestor.image.startsWith("linear-gradient(") ||
  77  |         !stops ||
  78  |         stops.length !== 2
  79  |       )
  80  |         blockers.push(`Unsupported image: ${ancestor.image}`);
  81  |       else {
  82  |         backgrounds = stops;
  83  |         for (const stop of stops) {
  84  |           const channels = stop.match(/[\d.]+/g)!.map(Number);
  85  |           if (
  86  |             channels[0] !== channels[1] ||
  87  |             channels[1] !== channels[2] ||
  88  |             (channels[3] !== undefined && channels[3] !== 1)
  89  |           )
  90  |             blockers.push(`Nonopaque or nongrayscale gradient: ${stop}`);
  91  |         }
  92  |       }
  93  |       break;
  94  |     }
  95  |     if (
  96  |       ancestor.background !== "rgba(0, 0, 0, 0)" &&
  97  |       ancestor.background !== "transparent"
  98  |     ) {
  99  |       backgrounds = [ancestor.background];
  100 |       break;
  101 |     }
  102 |   }
  103 |   const foreground = luminance(evidence.foreground);
  104 |   const values = backgrounds?.map(luminance) ?? [];
  105 |   const contrasts = values.map(
  106 |     (background) =>
  107 |       (Math.max(foreground, background) + 0.05) /
  108 |       (Math.min(foreground, background) + 0.05),
  109 |   );
  110 |   if (
  111 |     values.length === 2 &&
  112 |     foreground >= Math.min(...values) &&
  113 |     foreground <= Math.max(...values)
  114 |   )
  115 |     contrasts.push(1);
  116 |   await info.attach(`rendered-contrast-${label}`, {
```