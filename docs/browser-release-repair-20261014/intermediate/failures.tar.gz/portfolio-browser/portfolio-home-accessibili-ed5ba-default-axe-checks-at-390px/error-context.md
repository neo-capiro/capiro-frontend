# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-home-accessibility.spec.ts >> Portfolio home preserves accessible names, descriptions and default axe checks at 390px
- Location: tests/browser/portfolio-home-accessibility.spec.ts:6:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 11

- Array []
+ Array [
+   Object {
+     "id": "scrollable-region-focusable",
+     "impact": "serious",
+     "targets": Array [
+       Array [
+         "._pulseStats_14kfi_27",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - button "Toggle navigation" [ref=e5] [cursor=pointer]:
      - img [ref=e6]
    - link "Capiro Home" [ref=e7] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e8]
    - navigation "Workspace" [ref=e9]:
      - link "Meri" [ref=e10] [cursor=pointer]:
        - /url: /meri
      - link "Portfolio" [ref=e11] [cursor=pointer]:
        - /url: /
      - link "Modules" [ref=e12] [cursor=pointer]:
        - /url: /modules
    - navigation "Global actions" [ref=e13]:
      - link "Quick log" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?log=1
      - link "Master calendar" [ref=e15] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e16] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e17]
      - button "Test account" [ref=e19] [cursor=pointer]: T
  - main [ref=e21]:
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Your client portfolio
          - heading "Portfolio 1" [level=1] [ref=e26]
        - generic [ref=e27]:
          - combobox "Account owner" [ref=e29]:
            - option "All owners" [selected]
            - option "Unassigned"
          - generic [ref=e30]:
            - img [ref=e31]
            - textbox "Search profiles" [ref=e34]:
              - /placeholder: Search profiles…
          - button "Customize" [ref=e35] [cursor=pointer]
          - button "Add profile" [ref=e36] [cursor=pointer]:
            - img [ref=e37]
            - text: Add profile
      - region "Portfolio pulse" [ref=e38]:
        - generic [ref=e40]:
          - strong [ref=e41]: —
          - generic [ref=e42]:
            - text: of work linked
            - text: to an objective
        - generic [ref=e43]:
          - generic [ref=e44]:
            - strong [ref=e45]: "1"
            - generic [ref=e46]: Clients
          - generic [ref=e47]:
            - strong [ref=e48]: —
            - generic [ref=e49]: Need attention
          - generic [ref=e50]:
            - strong [ref=e51]: —
            - generic [ref=e52]: Objectives
          - generic [ref=e53]:
            - strong [ref=e54]: —
            - generic [ref=e55]: Off track
          - generic [ref=e56]:
            - strong [ref=e57]: —
            - generic [ref=e58]: Strategies
      - generic [ref=e59]:
        - complementary "Needs attention" [ref=e60]:
          - generic [ref=e61]:
            - heading "Needs attention" [level=2] [ref=e62]
            - note "0 shown alerts" [ref=e63]: 0 shown
            - generic "Ordered by the source service" [ref=e64]: ↑↓ Most urgent
          - paragraph [ref=e65]: Updates automatically. Open an item in its client profile.
          - status [ref=e66]: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
          - generic [ref=e67]:
            - paragraph [ref=e68]: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
            - generic [ref=e69]:
              - generic [ref=e70]:
                - text: Snapshot
                - time [ref=e71]: Oct 11, 6:00 AM UTC
              - button "Refresh alerts" [ref=e72] [cursor=pointer]
        - region "Portfolio profiles" [ref=e73]:
          - navigation "Profile type" [ref=e74]:
            - button "All 1" [pressed] [ref=e75] [cursor=pointer]:
              - text: All
              - generic [ref=e76]: "1"
            - button "Clients 1" [ref=e77] [cursor=pointer]:
              - text: Clients
              - generic [ref=e78]: "1"
            - link "Prospects" [ref=e79] [cursor=pointer]:
              - /url: /portfolio/prospects
            - link "Pipeline" [ref=e80] [cursor=pointer]:
              - /url: /portfolio/prospects?pipeline=1
            - generic [ref=e81]:
              - button "New objective" [ref=e82] [cursor=pointer]
              - group [ref=e83]:
                - generic "Filters and view" [ref=e84] [cursor=pointer]
                - option "All statuses" [selected]
                - option "ACTIVE"
                - option "All sectors" [selected]
                - option "Aerospace"
                - option "Saved order" [selected]
                - option "Recently added"
                - option "Name A–Z"
          - status [ref=e85]: 1 profile
          - button "Refresh profiles" [ref=e86] [cursor=pointer]
          - region "Organization profile order" [ref=e87]:
            - status [ref=e88]:
              - text: Saved profile ordering is unavailable in this environment. Reordering requires a current accessible catalog. Your ordinary view remains available.
              - button "Retry saved order" [ref=e89] [cursor=pointer]
            - article [ref=e92]:
              - generic [ref=e93]:
                - generic [ref=e94]: TA
                - generic [ref=e95]:
                  - heading "Open Test Aerospace" [level=2] [ref=e96]:
                    - link "Open Test Aerospace" [ref=e97] [cursor=pointer]:
                      - /url: /portfolio/10000000-0000-4000-8000-000000000001
                      - text: Test Aerospace
                  - generic [ref=e98]: Aerospace
              - generic [ref=e99]:
                - 'note "Profile status: ACTIVE" [ref=e100]': ACTIVE
                - 'img "Account owner: unavailable" [ref=e101]': —
            - status [ref=e102]
          - button "+ Add profile" [ref=e103] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, type Page, type TestInfo } from "@playwright/test";
  2  | import axe from "axe-core";
  3  | 
  4  | export async function expectAccessibleHome(page: Page, testInfo: TestInfo) {
  5  |   await page.evaluate(() => document.fonts.ready);
  6  |   await page.addScriptTag({ content: axe.source });
  7  |   const result = await page.evaluate(() =>
  8  |     (window as unknown as Window & { axe: typeof axe }).axe.run(document),
  9  |   );
  10 |   await testInfo.attach("axe-full-default-results", {
  11 |     body: JSON.stringify(result, null, 2),
  12 |     contentType: "application/json",
  13 |   });
  14 |   expect(
  15 |     result.violations.map(({ id, impact, nodes }) => ({
  16 |       id,
  17 |       impact,
  18 |       targets: nodes.map((node) => node.target),
  19 |     })),
> 20 |   ).toEqual([]);
     |     ^ Error: expect(received).toEqual(expected) // deep equality
  21 |   return result;
  22 | }
  23 | 
```