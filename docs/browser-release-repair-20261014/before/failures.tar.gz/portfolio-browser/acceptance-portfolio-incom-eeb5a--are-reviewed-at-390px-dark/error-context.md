# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-portfolio-incompletes.spec.ts >> Portfolio incomplete contrast and names are reviewed at 390px dark
- Location: tests/browser/acceptance-portfolio-incompletes.spec.ts:11:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  getByRole('region', { name: 'Portfolio pulse' }).locator('p, small, span.eyebrow').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('region', { name: 'Portfolio pulse' }).locator('p, small, span.eyebrow').first()
    14 × locator resolved to <p class="eyebrow">Portfolio pulse</p>
       - unexpected value "hidden"

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - button "Toggle navigation"
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Workspace":
    - link "Meri":
      - /url: /meri
    - link "Portfolio":
      - /url: /
    - link "Modules":
      - /url: /modules
  - navigation "Global actions":
    - link "Quick log":
      - /url: /portfolio?log=1
    - link "Master calendar":
      - /url: /calendar
    - link "Search Portfolio":
      - /url: /portfolio?search=1
    - button "Updates unavailable" [disabled]
    - button "Test account": T
- main:
  - paragraph: Your client portfolio
  - heading "Portfolio 1" [level=1]
  - combobox "Account owner":
    - option "All owners" [selected]
    - option "Unassigned"
  - textbox "Search profiles":
    - /placeholder: Search profiles…
  - button "Customize"
  - button "Add profile"
  - region "Portfolio pulse":
    - strong: —
    - text: of work linked to an objective
    - strong: "1"
    - text: Clients
    - strong: —
    - text: Need attention
    - strong: —
    - text: Objectives
    - strong: —
    - text: Off track
    - strong: —
    - text: Strategies
  - complementary "Needs attention":
    - heading "Needs attention" [level=3]
    - note "0 shown alerts": 0 shown
    - text: ↑↓ Most urgent
    - paragraph: Updates automatically. Open an item in its client profile.
    - status: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
    - paragraph: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
    - text: Snapshot
    - time: Oct 11, 6:00 AM UTC
    - button "Refresh alerts"
  - region "Portfolio profiles":
    - navigation "Profile type":
      - button "All 1" [pressed]
      - button "Clients 1"
      - link "Prospects":
        - /url: /portfolio/prospects
      - link "Pipeline":
        - /url: /portfolio/prospects?pipeline=1
      - button "New objective"
      - group: Filters and view
    - status: 1 profile
    - button "Refresh profiles"
    - region "Organization profile order":
      - status:
        - text: Saved profile ordering is unavailable in this environment. Reordering requires a current accessible catalog. Your ordinary view remains available.
        - button "Retry saved order"
      - article:
        - heading "Open Test Aerospace" [level=2]:
          - link "Open Test Aerospace":
            - /url: /portfolio/10000000-0000-4000-8000-000000000001
            - text: Test Aerospace
        - text: Aerospace
        - 'note "Profile status: ACTIVE"': ACTIVE
        - 'img "Account owner: unavailable"': —
      - status
    - button "+ Add profile"
```

# Test source

```ts
  1   | import {
  2   |   expect,
  3   |   type Locator,
  4   |   type Page,
  5   |   type TestInfo,
  6   | } from "@playwright/test";
  7   | import type { AxeResults } from "axe-core";
  8   | 
  9   | function luminance(color: string) {
  10  |   const channels = color.match(/[\d.]+/g)?.map(Number);
  11  |   if (
  12  |     !channels ||
  13  |     channels.length < 3 ||
  14  |     (channels[3] !== undefined && channels[3] !== 1)
  15  |   )
  16  |     throw new Error(`Expected opaque computed RGB: ${color}`);
  17  |   const linear = channels.slice(0, 3).map((value) => {
  18  |     const srgb = value / 255;
  19  |     return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
  20  |   });
  21  |   return linear[0]! * 0.2126 + linear[1]! * 0.7152 + linear[2]! * 0.0722;
  22  | }
  23  | 
  24  | /** Bounds opaque grayscale gradients using actual rendered ancestor/compositing data.
  25  |  * Unsupported effects fail for manual review; they never silently receive a pass. */
  26  | export async function expectRenderedContrast(
  27  |   target: Locator,
  28  |   info: TestInfo,
  29  |   label: string,
  30  | ) {
> 31  |   await expect(target).toBeVisible();
      |                        ^ Error: expect(locator).toBeVisible() failed
  32  |   const evidence = await target.evaluate((element) => {
  33  |     const css = getComputedStyle(element);
  34  |     const ancestors = [];
  35  |     let node: Element | null = element;
  36  |     while (node) {
  37  |       const style = getComputedStyle(node);
  38  |       ancestors.push({
  39  |         tag: node.tagName,
  40  |         background: style.backgroundColor,
  41  |         image: style.backgroundImage,
  42  |         opacity: style.opacity,
  43  |         filter: style.filter,
  44  |         backdropFilter: style.backdropFilter,
  45  |         mixBlendMode: style.mixBlendMode,
  46  |       });
  47  |       node = node.parentElement;
  48  |     }
  49  |     return {
  50  |       text:
  51  |         element instanceof HTMLTextAreaElement ||
  52  |         element instanceof HTMLInputElement
  53  |           ? element.value
  54  |           : element.textContent,
  55  |       foreground: css.color,
  56  |       fontSize: css.fontSize,
  57  |       fontWeight: css.fontWeight,
  58  |       ancestors,
  59  |     };
  60  |   });
  61  |   const blockers: string[] = [];
  62  |   for (const ancestor of evidence.ancestors) {
  63  |     if (
  64  |       ancestor.opacity !== "1" ||
  65  |       ancestor.filter !== "none" ||
  66  |       ancestor.backdropFilter !== "none" ||
  67  |       ancestor.mixBlendMode !== "normal"
  68  |     )
  69  |       blockers.push(`Unsupported compositing: ${JSON.stringify(ancestor)}`);
  70  |   }
  71  |   let backgrounds: string[] | undefined;
  72  |   for (const ancestor of evidence.ancestors) {
  73  |     if (ancestor.image !== "none") {
  74  |       const stops = ancestor.image.match(/rgba?\([^)]+\)/g);
  75  |       if (
  76  |         !ancestor.image.startsWith("linear-gradient(") ||
  77  |         !stops ||
  78  |         stops.length !== 2
  79  |       )
  80  |         blockers.push(`Unsupported image: ${ancestor.image}`);
  81  |       else {
  82  |         backgrounds = stops;
  83  |         for (const stop of stops) {
  84  |           const channels = stop.match(/[\d.]+/g)!.map(Number);
  85  |           if (
  86  |             channels[0] !== channels[1] ||
  87  |             channels[1] !== channels[2] ||
  88  |             (channels[3] !== undefined && channels[3] !== 1)
  89  |           )
  90  |             blockers.push(`Nonopaque or nongrayscale gradient: ${stop}`);
  91  |         }
  92  |       }
  93  |       break;
  94  |     }
  95  |     if (
  96  |       ancestor.background !== "rgba(0, 0, 0, 0)" &&
  97  |       ancestor.background !== "transparent"
  98  |     ) {
  99  |       backgrounds = [ancestor.background];
  100 |       break;
  101 |     }
  102 |   }
  103 |   const foreground = luminance(evidence.foreground);
  104 |   const values = backgrounds?.map(luminance) ?? [];
  105 |   const contrasts = values.map(
  106 |     (background) =>
  107 |       (Math.max(foreground, background) + 0.05) /
  108 |       (Math.min(foreground, background) + 0.05),
  109 |   );
  110 |   if (
  111 |     values.length === 2 &&
  112 |     foreground >= Math.min(...values) &&
  113 |     foreground <= Math.max(...values)
  114 |   )
  115 |     contrasts.push(1);
  116 |   await info.attach(`rendered-contrast-${label}`, {
  117 |     body: JSON.stringify(
  118 |       { ...evidence, backgrounds, contrasts, blockers },
  119 |       null,
  120 |       2,
  121 |     ),
  122 |     contentType: "application/json",
  123 |   });
  124 |   expect(blockers).toEqual([]);
  125 |   expect(backgrounds?.length).toBeGreaterThan(0);
  126 |   expect(Math.min(...contrasts)).toBeGreaterThanOrEqual(4.5);
  127 | }
  128 | 
  129 | /** Preserve axe's incomplete report and separately resolve its rendered bounds. */
  130 | export async function expectGradientIncompletes(
  131 |   page: Page,
```