# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-home-accessibility.spec.ts >> Portfolio home preserves accessible names, descriptions and default axe checks at 1440px
- Location: tests/browser/portfolio-home-accessibility.spec.ts:6:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 11

- Array []
+ Array [
+   Object {
+     "id": "heading-order",
+     "impact": "moderate",
+     "targets": Array [
+       Array [
+         "h3",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - link "Capiro Home" [ref=e5] [cursor=pointer]:
      - /url: /
      - img "Capiro" [ref=e6]
    - navigation "Workspace" [ref=e7]:
      - link "Meri" [ref=e8] [cursor=pointer]:
        - /url: /meri
      - link "Portfolio" [ref=e9] [cursor=pointer]:
        - /url: /
      - link "Modules" [ref=e10] [cursor=pointer]:
        - /url: /modules
    - navigation "Global actions" [ref=e11]:
      - link "Quick log" [ref=e12] [cursor=pointer]:
        - /url: /portfolio?log=1
      - link "Master calendar" [ref=e13] [cursor=pointer]:
        - /url: /calendar
      - link "Search Portfolio" [ref=e14] [cursor=pointer]:
        - /url: /portfolio?search=1
      - button "Updates unavailable" [disabled] [ref=e15]
      - button "Test account" [ref=e17] [cursor=pointer]: T
  - generic [ref=e18]:
    - complementary "Portfolio navigation" [ref=e19]:
      - paragraph [ref=e20]: Portfolio
      - navigation "Portfolio" [ref=e21]:
        - link "Portfolio Overview" [ref=e22] [cursor=pointer]:
          - /url: /portfolio
          - generic [ref=e23]: Overview
        - link "Portfolio Clients" [ref=e24] [cursor=pointer]:
          - /url: /portfolio?type=CLIENT
          - generic [ref=e25]: Clients
        - link "Portfolio Prospects" [ref=e26] [cursor=pointer]:
          - /url: /portfolio/prospects
          - generic [ref=e27]: Prospects
      - link "Settings" [ref=e29] [cursor=pointer]:
        - /url: /settings
    - main [ref=e30]:
      - generic [ref=e31]:
        - generic [ref=e32]:
          - generic [ref=e33]:
            - paragraph [ref=e34]: Your client portfolio
            - heading "Portfolio 1" [level=1] [ref=e35]
          - generic [ref=e36]:
            - combobox "Account owner" [ref=e38]:
              - option "All owners" [selected]
              - option "Unassigned"
            - generic [ref=e39]:
              - img [ref=e40]
              - textbox "Search profiles" [ref=e43]:
                - /placeholder: Search profiles…
            - button "Customize" [ref=e44] [cursor=pointer]
            - button "Add profile" [ref=e45] [cursor=pointer]:
              - img [ref=e46]
              - text: Add profile
        - region "Portfolio pulse" [ref=e47]:
          - generic [ref=e48]:
            - paragraph [ref=e49]: Portfolio pulse
            - generic [ref=e50]:
              - strong [ref=e51]: —
              - generic [ref=e52]:
                - text: of work linked
                - text: to an objective
          - generic [ref=e53]:
            - generic [ref=e54]:
              - strong [ref=e55]: "1"
              - generic [ref=e56]: Clients
            - generic [ref=e57]:
              - strong [ref=e58]: —
              - generic [ref=e59]: Need attention
            - generic [ref=e60]:
              - strong [ref=e61]: —
              - generic [ref=e62]: Objectives
            - generic [ref=e63]:
              - strong [ref=e64]: —
              - generic [ref=e65]: Off track
            - generic [ref=e66]:
              - strong [ref=e67]: —
              - generic [ref=e68]: Strategies
        - generic [ref=e69]:
          - complementary "Needs attention" [ref=e70]:
            - generic [ref=e71]:
              - heading "Needs attention" [level=3] [ref=e72]
              - note "0 shown alerts" [ref=e73]: 0 shown
              - generic "Ordered by the source service" [ref=e74]: ↑↓ Most urgent
            - paragraph [ref=e75]: Updates automatically. Open an item in its client profile.
            - status [ref=e76]: No alerts were returned for your accessible clients. Coverage is incomplete; this does not confirm there is nothing to review.
            - generic [ref=e77]:
              - paragraph [ref=e78]: "Limited feed: up to 50 alerts from the first 40 active clients, with up to 20 per client. Some sources may be unavailable."
              - generic [ref=e79]:
                - generic [ref=e80]:
                  - text: Snapshot
                  - time [ref=e81]: Oct 11, 6:00 AM UTC
                - button "Refresh alerts" [ref=e82] [cursor=pointer]
          - region "Portfolio profiles" [ref=e83]:
            - navigation "Profile type" [ref=e84]:
              - button "All 1" [pressed] [ref=e85] [cursor=pointer]:
                - text: All
                - generic [ref=e86]: "1"
              - button "Clients 1" [ref=e87] [cursor=pointer]:
                - text: Clients
                - generic [ref=e88]: "1"
              - link "Prospects" [ref=e89] [cursor=pointer]:
                - /url: /portfolio/prospects
              - link "Pipeline" [ref=e90] [cursor=pointer]:
                - /url: /portfolio/prospects?pipeline=1
              - generic [ref=e91]:
                - button "New objective" [ref=e92] [cursor=pointer]
                - group [ref=e93]:
                  - generic "Filters and view" [ref=e94] [cursor=pointer]
                  - option "All statuses" [selected]
                  - option "ACTIVE"
                  - option "All sectors" [selected]
                  - option "Aerospace"
                  - option "Saved order" [selected]
                  - option "Recently added"
                  - option "Name A–Z"
            - status [ref=e95]: 1 profile
            - button "Refresh profiles" [ref=e96] [cursor=pointer]
            - region "Organization profile order" [ref=e97]:
              - status [ref=e98]:
                - text: Saved profile ordering is unavailable in this environment. Reordering requires a current accessible catalog. Your ordinary view remains available.
                - button "Retry saved order" [ref=e99] [cursor=pointer]
              - article [ref=e102]:
                - generic [ref=e103]:
                  - generic [ref=e104]: TA
                  - generic [ref=e105]:
                    - heading "Open Test Aerospace" [level=2] [ref=e106]:
                      - link "Open Test Aerospace" [ref=e107] [cursor=pointer]:
                        - /url: /portfolio/10000000-0000-4000-8000-000000000001
                        - text: Test Aerospace
                    - generic [ref=e108]: Aerospace
                - generic [ref=e109]:
                  - 'note "Profile status: ACTIVE" [ref=e110]': ACTIVE
                  - 'img "Account owner: unavailable" [ref=e111]': —
              - status [ref=e112]
            - button "+ Add profile" [ref=e113] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, type Page, type TestInfo } from "@playwright/test";
  2  | import axe from "axe-core";
  3  | 
  4  | export async function expectAccessibleHome(page: Page, testInfo: TestInfo) {
  5  |   await page.evaluate(() => document.fonts.ready);
  6  |   await page.addScriptTag({ content: axe.source });
  7  |   const result = await page.evaluate(() =>
  8  |     (window as unknown as Window & { axe: typeof axe }).axe.run(document),
  9  |   );
  10 |   await testInfo.attach("axe-full-default-results", {
  11 |     body: JSON.stringify(result, null, 2),
  12 |     contentType: "application/json",
  13 |   });
  14 |   expect(
  15 |     result.violations.map(({ id, impact, nodes }) => ({
  16 |       id,
  17 |       impact,
  18 |       targets: nodes.map((node) => node.target),
  19 |     })),
> 20 |   ).toEqual([]);
     |     ^ Error: expect(received).toEqual(expected) // deep equality
  21 |   return result;
  22 | }
  23 | 
```