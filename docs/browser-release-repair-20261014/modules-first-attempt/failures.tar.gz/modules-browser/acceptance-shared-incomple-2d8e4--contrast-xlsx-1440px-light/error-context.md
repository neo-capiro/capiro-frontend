# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-shared-incompletes.spec.ts >> Shared incomplete contrast xlsx 1440px light
- Location: test/browser/acceptance-shared-incompletes.spec.ts:21:7

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('button', { name: 'New conversation', exact: true })
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for getByRole('button', { name: 'New conversation', exact: true })
    13 × locator resolved to <button disabled type="button" data-slot="button" title="Conversation service unavailable" class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive…>…</button>
       - unexpected value "inactive"

```

```yaml
- button "New conversation" [disabled]
```

# Test source

```ts
  1   | import {
  2   |   expect,
  3   |   type Locator,
  4   |   type Page,
  5   |   type TestInfo,
  6   | } from "@playwright/test";
  7   | 
  8   | /** Test-only observation; never provides data or session/approval authority. */
  9   | export async function observeHomeIsolation(page: Page, testInfo: TestInfo) {
  10  |   const baseURL = testInfo.project.use.baseURL;
  11  |   if (!baseURL) throw new Error("A leased local baseURL is required");
  12  |   const origin = new URL(baseURL).origin;
  13  |   const foreign: string[] = [],
  14  |     errors: string[] = [];
  15  |   page.on("pageerror", (error) => errors.push(error.message));
  16  |   await page.route("**/*", (route) => {
  17  |     const requested = route.request().url();
  18  |     if (new URL(requested).origin !== origin) {
  19  |       foreign.push(requested);
  20  |       return route.abort("blockedbyclient");
  21  |     }
  22  |     return route.fallback();
  23  |   });
  24  |   return () => {
  25  |     expect(foreign).toEqual([]);
  26  |     expect(errors).toEqual([]);
  27  |   };
  28  | }
  29  | 
  30  | /** Reach the actual sequential focus order, without forced focus or sleeps. */
  31  | export async function tabTo(page: Page, target: Locator) {
  32  |   await expect(target).toBeVisible();
  33  |   for (let step = 0; step < 64; step += 1) {
  34  |     await page.keyboard.press("Tab");
  35  |     // Finish focus-induced scrolling before advancing to another control.
  36  |     await page.evaluate(
  37  |       () =>
  38  |         new Promise<void>((resolve) => requestAnimationFrame(() => resolve())),
  39  |     );
  40  |     if (await target.evaluate((element) => element === document.activeElement))
  41  |       return;
  42  |   }
> 43  |   await expect(target).toBeFocused();
      |                        ^ Error: expect(locator).toBeFocused() failed
  44  | }
  45  | 
  46  | export async function expectFocusEvidence(target: Locator, testInfo: TestInfo) {
  47  |   await expect(target).toBeFocused();
  48  |   const focus = await target.evaluate((element) => {
  49  |     const style = getComputedStyle(element);
  50  |     const rect = element.getBoundingClientRect();
  51  |     return {
  52  |       focusVisible: element.matches(":focus-visible"),
  53  |       outlineStyle: style.outlineStyle,
  54  |       outlineWidth: parseFloat(style.outlineWidth),
  55  |       outlineColor: style.outlineColor,
  56  |       inViewport:
  57  |         rect.top >= 0 &&
  58  |         rect.bottom <= innerHeight &&
  59  |         rect.left >= 0 &&
  60  |         rect.right <= innerWidth,
  61  |     };
  62  |   });
  63  |   await testInfo.attach("focused-control-style", {
  64  |     body: JSON.stringify(focus, null, 2),
  65  |     contentType: "application/json",
  66  |   });
  67  |   expect(focus.focusVisible).toBe(true);
  68  |   expect(focus.outlineStyle).not.toBe("none");
  69  |   expect(focus.outlineWidth).toBeGreaterThanOrEqual(2);
  70  |   expect(focus.outlineColor).not.toMatch(/transparent|rgba\([^)]*, 0\)$/);
  71  |   expect(focus.inViewport).toBe(true);
  72  |   await testInfo.attach("focused-control-page", {
  73  |     body: await target.page().screenshot({ fullPage: true }),
  74  |     contentType: "image/png",
  75  |   });
  76  | }
  77  | 
  78  | /** Assert the browser's real hit target before an unforced pointer click. */
  79  | export async function pointWithLink(
  80  |   page: Page,
  81  |   target: Locator,
  82  |   expectedLink: string | null,
  83  | ) {
  84  |   await target.scrollIntoViewIfNeeded();
  85  |   const rect = await target.boundingBox();
  86  |   if (!rect) throw new Error("Visible pointer target has no bounds");
  87  |   const point = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
  88  |   const hitLink = await page.evaluate(
  89  |     ({ x, y }) =>
  90  |       document.elementFromPoint(x, y)?.closest("a")?.getAttribute("href") ??
  91  |       null,
  92  |     point,
  93  |   );
  94  |   expect(hitLink).toBe(expectedLink);
  95  |   return point;
  96  | }
  97  | 
  98  | export async function clickObservedPoint(
  99  |   page: Page,
  100 |   target: Locator,
  101 |   expectedLink: string | null,
  102 | ) {
  103 |   const point = await pointWithLink(page, target, expectedLink);
  104 |   await page.mouse.click(point.x, point.y);
  105 | }
  106 | 
```