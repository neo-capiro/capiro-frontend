# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-shared-incompletes.spec.ts >> Shared incomplete contrast home 1440px light
- Location: test/browser/acceptance-shared-incompletes.spec.ts:21:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Message draft', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByLabel('Message draft', { exact: true })

```

```yaml
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Portfolio":
      - /url: /portfolio/abcdef00-0000-4000-8000-000000000009
    - link "Modules":
      - /url: /modules?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Quick log":
    - /url: /?log=1&clientId=abcdef00-0000-4000-8000-000000000009
  - link "Master calendar":
    - /url: /calendar?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Search":
    - /url: /modules/intelligence?clientId=abcdef00-0000-4000-8000-000000000009
  - button "Updates — unavailable" [disabled]
  - link "Account settings":
    - /url: /settings/personal
- complementary "Meri navigation":
  - button "New conversation" [disabled]
  - button "Search conversations" [disabled]
  - navigation "Meri workspace":
    - button "Conversations"
    - button "Files"
    - button "Runs" [disabled]
    - button "Approvals" [disabled]
    - button "Memory" [disabled]
    - button "Routines" [disabled]
    - button "Data access" [disabled]
    - link "Recommendation actions":
      - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
  - region "Recent":
    - heading "Recent" [level=2]
    - paragraph: Recent conversations unavailable
  - link "Preferences":
    - /url: /settings/preferences
  - paragraph: Capiro · Your authorized workspace
- main:
  - button "Synthetic action client" [disabled]
  - img "Meri"
  - heading "Meri" [level=1]
  - paragraph: Welcome, Test.
  - region "Current client":
    - paragraph: "Selected client: Synthetic action client"
    - link "Open Portfolio":
      - /url: /
  - region "Conversations unavailable":
    - heading "Conversations unavailable" [level=2]
    - paragraph: The governed conversation connection is not enabled. Recent conversations and approval counts cannot be loaded.
  - region "Available Meri workspaces":
    - link "Open document files":
      - /url: /meri/files?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Open recommendation actions":
      - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
    - paragraph: Each workspace reports its connection status when opened.
- contentinfo:
  - note: Conversation operations require a verified runtime connection. Client and account details come from the connected Capiro services.
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { expectRenderedContrast } from "../rendered-contrast";
  3  | import { tabTo, expectFocusEvidence } from "../accessibility-interaction";
  4  | import {
  5  |   filesFixture,
  6  |   filesUrl,
  7  |   actionClient,
  8  |   connectFiles,
  9  |   expectFilesIsolation,
  10 | } from "./meri-files-fixtures";
  11 | 
  12 | for (const width of [1440, 390]) {
  13 |   for (const theme of ["light", "dark"] as const) {
  14 |     for (const view of [
  15 |       "home",
  16 |       "docx",
  17 |       "xlsx",
  18 |       "unavailable",
  19 |       "modules",
  20 |     ] as const) {
  21 |       test(`Shared incomplete contrast ${view} ${width}px ${theme}`, async ({
  22 |         page,
  23 |       }, info) => {
  24 |         const fixture = await filesFixture(
  25 |           page,
  26 |           view === "xlsx" ? "xlsx" : "docx",
  27 |         );
  28 |         await page.setViewportSize({
  29 |           width,
  30 |           height: width === 1440 ? 1040 : 844,
  31 |         });
  32 |         await page.emulateMedia({
  33 |           colorScheme: theme,
  34 |           reducedMotion: "reduce",
  35 |         });
  36 |         const route =
  37 |           view === "home"
  38 |             ? `/meri?clientId=${actionClient.id}`
  39 |             : view === "modules"
  40 |               ? `/modules?clientId=${actionClient.id}`
  41 |               : filesUrl(actionClient.id, view === "xlsx" ? "xlsx" : "docx") +
  42 |                 (view === "unavailable" ? "&documents-disabled=1" : "");
  43 |         await page.goto(route);
  44 |         if (view === "home")
  45 |           await expect(
  46 |             page.getByLabel("Message draft", { exact: true }),
> 47 |           ).toBeVisible();
     |             ^ Error: expect(locator).toBeVisible() failed
  48 |         else if (view === "modules")
  49 |           await expect(
  50 |             page.getByRole("heading", {
  51 |               name: "Everything in Capiro, across the whole firm",
  52 |             }),
  53 |           ).toBeVisible();
  54 |         else if (view !== "unavailable")
  55 |           await connectFiles(page, view === "xlsx" ? "xlsx" : "docx");
  56 |         else await expect(page.getByRole("main")).toContainText("not enabled");
  57 |         const control =
  58 |           view === "modules"
  59 |             ? page.getByRole("link", { name: "Open Engagement", exact: true })
  60 |             : width === 1440
  61 |               ? page.getByRole("button", {
  62 |                   name: "New conversation",
  63 |                   exact: true,
  64 |                 })
  65 |               : page
  66 |                   .getByRole("navigation", { name: "Meri sections" })
  67 |                   .getByRole("link", { name: "Files", exact: true });
  68 |         await page.mouse.move(0, 0);
  69 |         await expectRenderedContrast(control, info, "rest");
  70 |         await control.hover();
  71 |         await expectRenderedContrast(control, info, "hover");
  72 |         await tabTo(page, control);
  73 |         await expectFocusEvidence(control, info);
  74 |         await expectRenderedContrast(control, info, "focus");
  75 |         if (view !== "modules" && width === 390)
  76 |           await expect(
  77 |             page.getByRole("button", { name: "New conversation", exact: true }),
  78 |           ).toBeHidden();
  79 |         expect(
  80 |           await page.evaluate(() => document.documentElement.scrollWidth),
  81 |         ).toBeLessThanOrEqual(width);
  82 |         expect(fixture.requests).toEqual([]);
  83 |         expectFilesIsolation(fixture);
  84 |       });
  85 |     }
  86 |   }
  87 | }
  88 | 
```