# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-meri-icons.spec.ts >> Meri exact navigation assets retain visible icon treatment in light
- Location: test/browser/acceptance-meri-icons.spec.ts:10:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Message draft', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByLabel('Message draft', { exact: true })

```

```yaml
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Portfolio":
      - /url: /portfolio/abcdef00-0000-4000-8000-000000000009
    - link "Modules":
      - /url: /modules?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Quick log":
    - /url: /?log=1&clientId=abcdef00-0000-4000-8000-000000000009
  - link "Master calendar":
    - /url: /calendar?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Search":
    - /url: /modules/intelligence?clientId=abcdef00-0000-4000-8000-000000000009
  - button "Updates — unavailable" [disabled]
  - link "Account settings":
    - /url: /settings/personal
- complementary "Meri navigation":
  - button "New conversation" [disabled]
  - button "Search conversations" [disabled]
  - navigation "Meri workspace":
    - button "Conversations"
    - button "Files"
    - button "Runs" [disabled]
    - button "Approvals" [disabled]
    - button "Memory" [disabled]
    - button "Routines" [disabled]
    - button "Data access" [disabled]
    - link "Recommendation actions":
      - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
  - region "Recent":
    - heading "Recent" [level=2]
    - paragraph: Recent conversations unavailable
  - link "Preferences":
    - /url: /settings/preferences
  - paragraph: Capiro · Your authorized workspace
- main:
  - button "Synthetic action client" [disabled]
  - img "Meri"
  - heading "Meri" [level=1]
  - paragraph: Welcome, Test.
  - region "Current client":
    - paragraph: "Selected client: Synthetic action client"
    - link "Open Portfolio":
      - /url: /
  - region "Conversations unavailable":
    - heading "Conversations unavailable" [level=2]
    - paragraph: The governed conversation connection is not enabled. Recent conversations and approval counts cannot be loaded.
  - region "Available Meri workspaces":
    - link "Open document files":
      - /url: /meri/files?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Open recommendation actions":
      - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
    - paragraph: Each workspace reports its connection status when opened.
- contentinfo:
  - note: Conversation operations require a verified runtime connection. Client and account details come from the connected Capiro services.
```

# Test source

```ts
  1  | import { test, expect, type Locator } from "@playwright/test";
  2  | import { filesFixture, actionClient } from "./meri-files-fixtures";
  3  | 
  4  | async function filter(icon: Locator) {
  5  |   await expect(icon).toBeVisible();
  6  |   return icon.evaluate((element) => getComputedStyle(element).filter);
  7  | }
  8  | 
  9  | for (const colorScheme of ["light", "dark"] as const) {
  10 |   test(`Meri exact navigation assets retain visible icon treatment in ${colorScheme}`, async ({
  11 |     page,
  12 |   }) => {
  13 |     const fixture = await filesFixture(page);
  14 |     await page.emulateMedia({ colorScheme });
  15 |     await page.goto(`/meri?clientId=${actionClient.id}`);
  16 |     await expect(
  17 |       page.getByLabel("Message draft", { exact: true }),
> 18 |     ).toBeVisible();
     |       ^ Error: expect(locator).toBeVisible() failed
  19 |     const sidebar = page.getByRole("complementary", {
  20 |       name: "Meri navigation",
  21 |     });
  22 |     for (const name of ["Files", "Conversations", "Search conversations"]) {
  23 |       const icon = sidebar
  24 |         .getByRole("button", { name, exact: true })
  25 |         .locator("img");
  26 |       expect(await filter(icon)).toBe(
  27 |         colorScheme === "light" ? "none" : "brightness(0) invert(1)",
  28 |       );
  29 |       await expect(icon).toHaveAttribute("src", /^\/design\/home\/[^/]+\.svg$/);
  30 |     }
  31 |     expect(
  32 |       await filter(
  33 |         sidebar
  34 |           .getByRole("button", { name: "New conversation" })
  35 |           .locator("img"),
  36 |       ),
  37 |     ).toBe(
  38 |       colorScheme === "light" ? "brightness(0) invert(1)" : "brightness(0)",
  39 |     );
  40 |     expect(
  41 |       await filter(
  42 |         page
  43 |           .getByRole("banner")
  44 |           .getByRole("link", { name: "Meri", exact: true })
  45 |           .locator("img"),
  46 |       ),
  47 |     ).toBe("none");
  48 |     expect(fixture.requests).toEqual([]);
  49 |   });
  50 | }
  51 | 
```