# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-meri-theme.spec.ts >> Meri authored dark workspace keeps the shared header light at 390px
- Location: test/browser/acceptance-meri-theme.spec.ts:28:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Message draft', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByLabel('Message draft', { exact: true })

```

```yaml
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Portfolio":
      - /url: /portfolio/abcdef00-0000-4000-8000-000000000009
    - link "Modules":
      - /url: /modules?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Quick log":
    - /url: /?log=1&clientId=abcdef00-0000-4000-8000-000000000009
  - link "Master calendar":
    - /url: /calendar?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Search":
    - /url: /modules/intelligence?clientId=abcdef00-0000-4000-8000-000000000009
  - button "Updates — unavailable" [disabled]
  - link "Account settings":
    - /url: /settings/personal
- navigation "Meri sections":
  - link "Conversations":
    - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Files":
    - /url: /meri/files?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Recommendation actions":
    - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
- main:
  - button "Synthetic action client" [disabled]
  - img "Meri"
  - heading "Meri" [level=1]
  - paragraph: Welcome, Test.
  - region "Current client":
    - paragraph: "Selected client: Synthetic action client"
    - link "Open Portfolio":
      - /url: /
  - region "Conversations unavailable":
    - heading "Conversations unavailable" [level=2]
    - paragraph: The governed conversation connection is not enabled. Recent conversations and approval counts cannot be loaded.
  - region "Available Meri workspaces":
    - link "Open document files":
      - /url: /meri/files?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Open recommendation actions":
      - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
    - paragraph: Each workspace reports its connection status when opened.
- contentinfo:
  - note: Conversation operations require a verified runtime connection. Client and account details come from the connected Capiro services.
```

# Test source

```ts
  1   | import { test, expect, type Locator } from "@playwright/test";
  2   | import { expectAccessibleHome } from "../accessibility";
  3   | import { expectGradientIncompletes } from "../rendered-contrast";
  4   | import { tabTo, expectFocusEvidence } from "../accessibility-interaction";
  5   | import {
  6   |   filesFixture,
  7   |   filesUrl,
  8   |   actionClient,
  9   |   expectFilesIsolation,
  10  | } from "./meri-files-fixtures";
  11  | 
  12  | async function style(locator: Locator) {
  13  |   return locator.evaluate((node) => {
  14  |     const css = getComputedStyle(node);
  15  |     return {
  16  |       color: css.color,
  17  |       background: css.backgroundColor,
  18  |       image: css.backgroundImage,
  19  |       foreground: css.getPropertyValue("--foreground").trim(),
  20  |       card: css.getPropertyValue("--card").trim(),
  21  |       muted: css.getPropertyValue("--muted-foreground").trim(),
  22  |       scheme: css.colorScheme,
  23  |     };
  24  |   });
  25  | }
  26  | 
  27  | for (const width of [1440, 390]) {
  28  |   test(`Meri authored dark workspace keeps the shared header light at ${width}px`, async ({
  29  |     page,
  30  |   }, info) => {
  31  |     const fixture = await filesFixture(page);
  32  |     await page.setViewportSize({ width, height: width === 1440 ? 1040 : 844 });
  33  |     await page.emulateMedia({ colorScheme: "dark" });
  34  |     await page.goto(`/meri?clientId=${actionClient.id}`);
  35  |     const main = page.getByRole("main");
  36  |     await expect(
  37  |       page.getByLabel("Message draft", { exact: true }),
> 38  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  39  |     const dark = await style(main);
  40  |     // Authored Meri collection448:90059 and dark frame448:89992.
  41  |     expect(dark.foreground).toBe("#f5f5f4");
  42  |     expect(dark.card).toBe("#0a0a0a");
  43  |     expect(dark.muted).toBe("#afa6a0");
  44  |     expect(dark.scheme).toBe("dark");
  45  |     expect(dark.image).toContain("linear-gradient");
  46  |     const header = await style(page.getByRole("banner"));
  47  |     expect(header.background).toBe("rgb(255, 255, 255)");
  48  |     expect(header.foreground).toBe("#0a0a0a");
  49  |     const send = page.getByRole("button", {
  50  |       name: "Send unavailable: disconnected fixture",
  51  |       exact: true,
  52  |     });
  53  |     expect((await style(send)).color).toBe("rgb(10, 10, 10)");
  54  |     expect((await style(send)).background).toBe("rgb(245, 245, 244)");
  55  |     const start = page.getByRole("button", {
  56  |       name: "Start research draft",
  57  |       exact: true,
  58  |     });
  59  |     await tabTo(page, start);
  60  |     await expectFocusEvidence(start, info);
  61  |     await page.keyboard.press("Enter");
  62  |     await expect(page.getByLabel("Message draft", { exact: true })).toHaveValue(
  63  |       "Help me research a question about ",
  64  |     );
  65  |     await info.attach("authored-dark-computed", {
  66  |       body: JSON.stringify({ dark, header }, null, 2),
  67  |       contentType: "application/json",
  68  |     });
  69  |     await page.screenshot({
  70  |       path: info.outputPath(`meri-dark-${width}.png`),
  71  |       fullPage: true,
  72  |     });
  73  |     const audit = await expectAccessibleHome(page, info);
  74  |     await expectGradientIncompletes(page, info, audit.incomplete);
  75  |     expect(fixture.requests).toEqual([]);
  76  |     expect(fixture.host.calls("session")).toHaveLength(0);
  77  |     expectFilesIsolation(fixture);
  78  |   });
  79  | 
  80  |   test(`Meri Files theme follows preference through scoped navigation and history at ${width}px`, async ({
  81  |     page,
  82  |   }, info) => {
  83  |     const fixture = await filesFixture(page);
  84  |     await page.setViewportSize({ width, height: width === 1440 ? 1040 : 844 });
  85  |     await page.emulateMedia({ colorScheme: "dark" });
  86  |     const home = `/meri?clientId=${actionClient.id}`;
  87  |     await page.goto(home);
  88  |     await expect(
  89  |       page.getByLabel("Message draft", { exact: true }),
  90  |     ).toBeVisible();
  91  |     await page
  92  |       .getByRole(width === 390 ? "link" : "button", {
  93  |         name: "Files",
  94  |         exact: true,
  95  |       })
  96  |       .click();
  97  |     await expect(page).toHaveURL(filesUrl());
  98  |     await expect(
  99  |       page.getByRole("button", {
  100 |         name: "Connect document service",
  101 |         exact: true,
  102 |       }),
  103 |     ).toBeVisible();
  104 |     expect((await style(page.getByRole("main"))).foreground).toBe("#f5f5f4");
  105 |     await page
  106 |       .getByRole("navigation", { name: "Product modes" })
  107 |       .getByRole("link", { name: "Modules", exact: true })
  108 |       .click();
  109 |     await expect(
  110 |       page.getByRole("heading", {
  111 |         name: "Everything in Capiro, across the whole firm",
  112 |       }),
  113 |     ).toBeVisible();
  114 |     expect((await style(page.getByRole("banner"))).foreground).toBe("#0a0a0a");
  115 |     await page.goBack();
  116 |     await expect(page).toHaveURL(filesUrl());
  117 |     expect((await style(page.getByRole("main"))).foreground).toBe("#f5f5f4");
  118 |     await page.goBack();
  119 |     await expect(page).toHaveURL(home);
  120 |     await page.goForward();
  121 |     await expect(page).toHaveURL(filesUrl());
  122 |     await page.emulateMedia({ colorScheme: "light" });
  123 |     expect((await style(page.getByRole("main"))).foreground).toBe("#0a0a0a");
  124 |     await page.emulateMedia({ colorScheme: "dark" });
  125 |     expect((await style(page.getByRole("main"))).foreground).toBe("#f5f5f4");
  126 |     expect(
  127 |       await page.evaluate(
  128 |         () => document.documentElement.scrollWidth > innerWidth,
  129 |       ),
  130 |     ).toBe(false);
  131 |     await page.screenshot({
  132 |       path: info.outputPath(`files-dark-${width}.png`),
  133 |       fullPage: true,
  134 |     });
  135 |     const audit = await expectAccessibleHome(page, info);
  136 |     await expectGradientIncompletes(page, info, audit.incomplete);
  137 |     expect(fixture.requests).toEqual([]);
  138 |     expect(fixture.host.calls("session")).toHaveLength(0);
```