# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: modules-home-design.spec.ts >> Figma Modules information is available by keyboard at 390px light without changing the heading
- Location: test/browser/modules-home-design.spec.ts:69:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Everything in Capiro, across the whole firm', exact: true, level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Everything in Capiro, across the whole firm', exact: true, level: 1 })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri
    - link "Portfolio":
      - /url: /
    - link "Modules":
      - /url: /modules
  - navigation "Workspace actions":
    - link "Quick log":
      - /url: /?log=1
    - link "Master calendar":
      - /url: /calendar
    - link "Search intelligence":
      - /url: /modules/intelligence
    - button "Updates — unavailable" [disabled]
    - link "Account settings":
      - /url: /settings/personal
- button "Modules menu"
- main:
  - paragraph: Modules
  - heading "Everything in Capiro" [level=1]
  - button "About Modules"
  - text: Scope
  - combobox "Client profile scope":
    - option "All 0 client profiles" [selected]
  - region "How modules and profiles relate":
    - heading "Modules · the whole firm" [level=2]
    - paragraph: Every client and every activity. Anyone at the firm can browse it, even without a client profile.
    - heading "Client profile · just that client" [level=2]
    - paragraph: The same data filtered to one client and arranged around their work, so you stay fully inside it.
  - region "Run the work":
    - heading "Run the work" [level=2]
    - article:
      - link "Engagement":
        - /url: /modules/engagement
        - heading "Engagement" [level=2]
      - paragraph: Meetings, outreach, reports and the meeting library for every client.
      - text: In a client profile
      - paragraph: Engagement, one client
      - link "Open Engagement":
        - /url: /modules/engagement
    - article:
      - link "Workspace":
        - /url: /modules/workspace
        - heading "Workspace" [level=2]
      - paragraph: Hill Day packets, drafts and proposal templates.
      - text: In a client profile
      - paragraph: Workspace, one client
      - link "Open":
        - /url: /modules/workspace
    - article:
      - link "Planner":
        - /url: /modules/planner
        - heading "Planner" [level=2]
      - paragraph: Tasks, projects and deadlines across the firm.
      - text: In a client profile
      - paragraph: Planner, one client
      - link "Open":
        - /url: /modules/planner
    - article:
      - link "Strategies":
        - /url: /modules/strategies
        - heading "Strategies" [level=2]
      - paragraph: Strategy and context libraries, agent review and runs.
      - text: In a client profile
      - paragraph: Objectives and Strategies
      - link "Open":
        - /url: /modules/strategies
  - region "Know the landscape":
    - heading "Know the landscape" [level=2]
    - article:
      - link "Intelligence":
        - /url: /modules/intelligence
        - heading "Intelligence" [level=2]
      - paragraph: Legislation, budgets, funding and geography, searchable across everything the platform tracks.
      - text: In a client profile
      - paragraph: Intelligence and Opportunities, matched to that client
      - link "Open":
        - /url: /modules/intelligence
    - article:
      - link "Directory":
        - /url: /modules/directory
        - heading "Directory" [level=2]
      - paragraph: Members, staff, committees and Department of War officials.
      - text: In a client profile
      - paragraph: Relationships, the offices that client touches
      - link "Open":
        - /url: /modules/directory
    - article:
      - link "Research Portfolios":
        - /url: /modules/research-portfolios
        - heading "Research Portfolios" [level=2]
      - paragraph: Saved collections of companies and topics.
      - text: In a client profile
      - paragraph: Firm-wide only
      - link "Open":
        - /url: /modules/research-portfolios
- complementary "Local test fixture": Explicit local test fixture · synthetic identity and records
```

# Test source

```ts
  29  |   });
  30  |   const geometry = await intelligence.boundingBox();
  31  |   await info.attach("baseline-landscape-width", {
  32  |     body: JSON.stringify(geometry),
  33  |     contentType: "application/json",
  34  |   });
  35  |   expect(geometry!.width).toBeCloseTo(646, 0);
  36  | });
  37  | 
  38  | test("Figma Modules card SVGs preserve native rendered geometry", async ({
  39  |   page,
  40  | }, info) => {
  41  |   for (const name of [
  42  |     "Planner",
  43  |     "Strategies",
  44  |     "Intelligence",
  45  |     "Research Portfolios",
  46  |   ]) {
  47  |     const icon = page
  48  |       .getByRole("article")
  49  |       .filter({ has: page.getByRole("heading", { name, exact: true }) })
  50  |       .getByRole("link", { name, exact: true })
  51  |       .locator("img");
  52  |     const rect = await icon.boundingBox();
  53  |     await info.attach(`asset-${name}`, {
  54  |       body: JSON.stringify(rect),
  55  |       contentType: "application/json",
  56  |     });
  57  |     expect.soft(rect!.width).toBeCloseTo(24, 0);
  58  |     expect.soft(rect!.height).toBeCloseTo(24, 0);
  59  |   }
  60  | });
  61  | 
  62  | for (const [width, colorScheme] of [
  63  |   [1440, "light"],
  64  |   [390, "light"],
  65  |   [1440, "dark"],
  66  |   [390, "dark"],
  67  |   [320, "light"],
  68  | ] as const) {
  69  |   test(`Figma Modules information is available by keyboard at ${width}px ${colorScheme} without changing the heading`, async ({
  70  |     page,
  71  |   }, info) => {
  72  |     await page.setViewportSize({ width, height: width === 1440 ? 1040 : 844 });
  73  |     await page.emulateMedia({ colorScheme, reducedMotion: "reduce" });
  74  |     const help = page.getByRole("button", {
  75  |       name: "About Modules",
  76  |       exact: true,
  77  |     });
  78  |     await expect(help).toBeVisible();
  79  |     const target = await help.boundingBox();
  80  |     expect(target!.width).toBeGreaterThanOrEqual(24);
  81  |     expect(target!.height).toBeGreaterThanOrEqual(24);
  82  |     await tabTo(page, help);
  83  |     await expectFocusEvidence(help, info);
  84  |     const tooltip = page.getByRole("tooltip");
  85  |     await expect(tooltip).toContainText("Every client and every activity");
  86  |     await expect(tooltip).toHaveCount(1);
  87  |     await expect(help).toHaveAccessibleDescription(
  88  |       "Every client and every activity, across the whole firm. Choose a client profile to show just that client’s work.",
  89  |     );
  90  |     await expect(help).toHaveAttribute(
  91  |       "aria-describedby",
  92  |       (await tooltip.getAttribute("id"))!,
  93  |     );
  94  |     await expect(page.getByRole("main").getByRole("tooltip")).toHaveCount(1);
  95  |     const visibleContent = page.locator('[data-slot="tooltip-content"]');
  96  |     const bounds = await visibleContent.boundingBox();
  97  |     expect(bounds!.x).toBeGreaterThanOrEqual(0);
  98  |     expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(width);
  99  |     await page.screenshot({ path: info.outputPath("information-focus.png") });
  100 |     const surface = await visibleContent.evaluate((element) => {
  101 |       const style = getComputedStyle(element);
  102 |       return {
  103 |         background: style.backgroundColor,
  104 |         color: style.color,
  105 |         zIndex: style.zIndex,
  106 |         padding: style.paddingTop,
  107 |         radius: style.borderRadius,
  108 |       };
  109 |     });
  110 |     await info.attach("information-surface", {
  111 |       body: JSON.stringify(surface),
  112 |       contentType: "application/json",
  113 |     });
  114 |     expect.soft(surface.background).toBe("rgb(10, 10, 10)");
  115 |     expect.soft(surface.color).toBe("rgb(245, 245, 244)");
  116 |     expect.soft(Number(surface.zIndex)).toBeGreaterThanOrEqual(110);
  117 |     expect.soft(parseFloat(surface.padding)).toBeGreaterThanOrEqual(6);
  118 |     expect.soft(parseFloat(surface.radius)).toBeGreaterThanOrEqual(6);
  119 |     await expectAccessibleHome(page, info);
  120 |     await page.keyboard.press("Escape");
  121 |     await expect(tooltip).toBeHidden();
  122 |     await expect(help).toBeFocused();
  123 |     await expect(
  124 |       page.getByRole("heading", {
  125 |         name: "Everything in Capiro, across the whole firm",
  126 |         exact: true,
  127 |         level: 1,
  128 |       }),
> 129 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  130 |   });
  131 | }
  132 | 
```