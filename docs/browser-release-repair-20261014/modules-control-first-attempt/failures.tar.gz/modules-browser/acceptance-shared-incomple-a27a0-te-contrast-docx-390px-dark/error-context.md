# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance-shared-incompletes.spec.ts >> Shared incomplete contrast docx 390px dark
- Location: test/browser/acceptance-shared-incompletes.spec.ts:21:7

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator: getByRole('button', { name: 'New conversation', exact: true })
Expected: disabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeDisabled" with timeout 5000ms
  - waiting for getByRole('button', { name: 'New conversation', exact: true })

```

```yaml
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
    - link "Portfolio":
      - /url: /portfolio/abcdef00-0000-4000-8000-000000000009
    - link "Modules":
      - /url: /modules?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Quick log":
    - /url: /?log=1&clientId=abcdef00-0000-4000-8000-000000000009
  - link "Master calendar":
    - /url: /calendar?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Search":
    - /url: /modules/intelligence?clientId=abcdef00-0000-4000-8000-000000000009
  - button "Updates — unavailable" [disabled]
  - link "Account settings":
    - /url: /settings/personal
- navigation "Meri sections":
  - link "Conversations":
    - /url: /meri?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Files":
    - /url: /meri/files?clientId=abcdef00-0000-4000-8000-000000000009
  - link "Recommendation actions":
    - /url: /meri/actions?clientId=abcdef00-0000-4000-8000-000000000009
- main:
  - heading "Files" [level=1]
  - paragraph: "Client: Synthetic action client. The service checks current authority for every request."
  - status: Operations run only when you choose an action.
  - region "Create a document":
    - heading "Create a document" [level=2]
    - paragraph: Write the text to save as a Word document or a plain text file.
    - text: Document title
    - textbox "Document title"
    - text: File format
    - combobox "File format":
      - option "Word document (.docx)" [selected]
      - option "Plain text (.txt)"
    - text: Document text
    - textbox "Document text"
    - paragraph: Each line becomes a normal paragraph, including blank lines. Up to 1,000 paragraphs and 100,000 characters.
    - button "Create document" [disabled]
    - paragraph: Enter a document title.
  - region "Immutable version":
    - heading "Immutable version" [level=2]
    - paragraph: Inspect a version ID you already know, or select one returned in this view. This is not a file library.
    - text: Known version ID
    - textbox "Known version ID"
    - button "Inspect version ID" [disabled]
    - paragraph: No verified version is selected.
- contentinfo:
  - note: Document files require a verified document connection. Generated files remain drafts; native Office rendering is unverified.
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { expectRenderedContrast } from "../rendered-contrast";
  3  | import { tabTo, expectFocusEvidence } from "../accessibility-interaction";
  4  | import {
  5  |   filesFixture,
  6  |   filesUrl,
  7  |   actionClient,
  8  |   connectFiles,
  9  |   expectFilesIsolation,
  10 | } from "./meri-files-fixtures";
  11 | 
  12 | for (const width of [1440, 390]) {
  13 |   for (const theme of ["light", "dark"] as const) {
  14 |     for (const view of [
  15 |       "home",
  16 |       "docx",
  17 |       "xlsx",
  18 |       "unavailable",
  19 |       "modules",
  20 |     ] as const) {
  21 |       test(`Shared incomplete contrast ${view} ${width}px ${theme}`, async ({
  22 |         page,
  23 |       }, info) => {
  24 |         const fixture = await filesFixture(
  25 |           page,
  26 |           view === "xlsx" ? "xlsx" : "docx",
  27 |         );
  28 |         await page.setViewportSize({
  29 |           width,
  30 |           height: width === 1440 ? 1040 : 844,
  31 |         });
  32 |         await page.emulateMedia({
  33 |           colorScheme: theme,
  34 |           reducedMotion: "reduce",
  35 |         });
  36 |         const route =
  37 |           view === "home"
  38 |             ? `/meri/fixture/home?clientId=${actionClient.id}`
  39 |             : view === "modules"
  40 |               ? `/modules?clientId=${actionClient.id}`
  41 |               : filesUrl(actionClient.id, view === "xlsx" ? "xlsx" : "docx") +
  42 |                 (view === "unavailable" ? "&documents-disabled=1" : "");
  43 |         await page.goto(route);
  44 |         if (view === "home")
  45 |           await expect(
  46 |             page.getByLabel("Message draft", { exact: true }),
  47 |           ).toBeVisible();
  48 |         else if (view === "modules")
  49 |           await expect(
  50 |             page.getByRole("heading", {
  51 |               name: /^Everything in Capiro/,
  52 |             }),
  53 |           ).toBeVisible();
  54 |         else if (view !== "unavailable")
  55 |           await connectFiles(page, view === "xlsx" ? "xlsx" : "docx");
  56 |         else await expect(page.getByRole("main")).toContainText("not enabled");
  57 |         const control =
  58 |           view === "modules"
  59 |             ? page.getByRole("link", { name: "Open Engagement", exact: true })
  60 |             : width === 1440
  61 |               ? page.getByRole("button", {
  62 |                   name: view === "home" ? "New conversation" : "Files",
  63 |                   exact: true,
  64 |                 })
  65 |               : page
  66 |                   .getByRole("navigation", { name: "Meri sections" })
  67 |                   .getByRole("link", { name: "Files", exact: true });
  68 |         if (view !== "home" && view !== "modules")
  69 |           await expect(
  70 |             page.getByRole("button", { name: "New conversation", exact: true }),
> 71 |           ).toBeDisabled();
     |             ^ Error: expect(locator).toBeDisabled() failed
  72 |         await page.mouse.move(0, 0);
  73 |         await expectRenderedContrast(control, info, "rest");
  74 |         await control.hover();
  75 |         await expectRenderedContrast(control, info, "hover");
  76 |         await tabTo(page, control);
  77 |         await expectFocusEvidence(control, info);
  78 |         await expectRenderedContrast(control, info, "focus");
  79 |         if (view !== "modules" && width === 390)
  80 |           await expect(
  81 |             page.getByRole("button", { name: "New conversation", exact: true }),
  82 |           ).toBeHidden();
  83 |         expect(
  84 |           await page.evaluate(() => document.documentElement.scrollWidth),
  85 |         ).toBeLessThanOrEqual(width);
  86 |         expect(fixture.requests).toEqual([]);
  87 |         expectFilesIsolation(fixture);
  88 |       });
  89 |     }
  90 |   }
  91 | }
  92 | 
```