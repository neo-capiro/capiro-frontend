import original from '/workspace/capiro-preview-read-only-20261013/apps/web/vitest.config.ts';
export default {...original, root:'/workspace/capiro-preview-read-only-20261013/apps/web', cacheDir:'/workspace/capiro-preview-read-only-evidence-20261013/vite-cache'};
