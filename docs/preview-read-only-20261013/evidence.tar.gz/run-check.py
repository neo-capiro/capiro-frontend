import json, os, subprocess, sys, time
from pathlib import Path
from datetime import datetime, timezone

root = Path('/workspace/capiro-preview-read-only-20261013')
out = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
def source():
    return {key: subprocess.check_output(['git', *args], cwd=root, text=True).strip() for key, args in {
        'head':['rev-parse','HEAD'], 'applicationTree':['rev-parse','HEAD:apps/web'],
        'productionTree':['rev-parse','HEAD:apps/web/src'], 'status':['status','--porcelain'],
    }.items()}
env = dict(os.environ, NEXT_TELEMETRY_DISABLED='1', NODE_DISABLE_COMPILE_CACHE='1', NODE_PATH='', TMPDIR=str(out/'tmp'))
(out/'tmp').mkdir(exist_ok=True)
for key in ['NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY','CLERK_SECRET_KEY','CORE_API_BASE_URL','STRATEGY_API_BASE_URL','WORKSPACE_API_BASE_URL','INTELLIGENCE_API_BASE_URL','MERI_API_BASE_URL','ONBOARD_API_BASE_URL','MERI_ACTION_WORKFLOW_ENABLED','MERI_DOCUMENT_WORKFLOW_ENABLED','MERI_DOCUMENT_OPERATION','TRACKER_BACKEND','CAPIRO_EXISTING_APP_URL']:
    env[key] = ''
env.pop('CAPIRO_PREVIEW_READ_ONLY', None)
env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']='/usr/bin/chromium'
before=source(); started=time.monotonic()
record={'name':name,'command':command,'sourceBefore':before,'startedUTC':datetime.now(timezone.utc).isoformat()}
with (out/f'{name}.log').open('x') as log:
    result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,durationSeconds=time.monotonic()-started,sourceAfter=source(),endedUTC=datetime.now(timezone.utc).isoformat())
(out/f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(result.returncode)
