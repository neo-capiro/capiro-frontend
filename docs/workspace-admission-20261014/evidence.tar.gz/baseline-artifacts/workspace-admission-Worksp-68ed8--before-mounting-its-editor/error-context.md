# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workspace-admission.spec.ts >> Workspace refuses a different returned Newsletter draft ID before mounting its editor
- Location: test/browser/workspace-admission.spec.ts:15:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "The returned document does not match this link."
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('alert')

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - link "Capiro Home":
    - /url: /
    - img "Capiro"
  - navigation "Product modes":
    - link "Meri":
      - /url: /meri
    - link "Portfolio":
      - /url: /
    - link "Modules":
      - /url: /modules
  - navigation "Workspace actions":
    - link "Quick log":
      - /url: /?log=1
    - link "Master calendar":
      - /url: /calendar
    - link "Search intelligence":
      - /url: /modules/intelligence
    - button "Updates — unavailable" [disabled]
    - link "Account settings":
      - /url: /settings/personal
- complementary:
  - paragraph: Modules
  - navigation "Modules":
    - link "Module hub":
      - /url: /modules
    - link "Engagement":
      - /url: /modules/engagement
    - link "Planner":
      - /url: /modules/planner
    - link "Calendar":
      - /url: /modules/calendar
    - link "Workspace":
      - /url: /modules/workspace
    - link "Strategies":
      - /url: /modules/strategies
    - link "Directory":
      - /url: /modules/directory
    - link "Intelligence":
      - /url: /modules/intelligence
    - link "Research portfolios":
      - /url: /modules/research-portfolios
  - link "Settings":
    - /url: /settings/personal
- main:
  - navigation "Breadcrumb":
    - link "← Modules":
      - /url: /modules
    - combobox "Switch module": Workspace
  - group:
    - navigation:
      - button "Workspace"
      - text: / Wrong document must remain concealed
    - heading "Wrong document must remain concealed" [level=1]
    - paragraph: Newsletter builder
    - button "Save and exit"
    - button "Preview & review"
    - button "Stage in Outreach"
    - text: All changes saved
    - button "Save draft"
    - button "Desktop" [pressed]
    - button "Mobile"
    - text: Subject
    - textbox "Subject"
    - text: Preview text
    - textbox "Preview text"
    - button "Undo" [disabled]
    - button "Redo" [disabled]
    - complementary:
      - strong: Add content
      - button "Heading"
      - button "Paragraph"
      - button "Image"
      - button "Button"
      - button "Divider"
      - button "Spacer"
      - button "Social"
      - button "Logo"
      - button "Code"
      - paragraph: Images and links are reviewed before use.
    - article:
      - paragraph: CLIENT UPDATE
      - paragraph: WEEKLY POLICY BRIEF / 10/14/2026
      - heading "The week in policy. What it means for you." [level=2]
      - button "Edit"
      - button "↑" [disabled]
      - button "↓"
      - button "Remove"
      - paragraph: A focused briefing on the developments shaping your priorities in Washington.
      - button "Edit"
      - button "↑"
      - button "↓"
      - button "Remove"
      - heading "Legislative watch" [level=2]
      - button "Edit"
      - button "↑"
      - button "↓"
      - button "Remove"
      - paragraph: Add this week’s developments, client context and practical next steps.
      - button "Edit"
      - button "↑"
      - button "↓"
      - button "Remove"
      - heading "Plan for the week ahead." [level=2]
      - button "Edit"
      - button "↑"
      - button "↓"
      - button "Remove"
      - paragraph: Coordinate priorities, prepare for key conversations and keep your team aligned.
      - button "Edit"
      - button "↑"
      - button "↓"
      - button "Remove"
      - strong: Read the full briefing
      - button "Edit"
      - button "↑"
      - button "↓" [disabled]
      - button "Remove"
      - paragraph
    - complementary:
      - heading "Newsletter settings" [level=3]
      - text: Document name
      - textbox "Document name": Wrong document must remain concealed
      - text: Client
      - combobox "Client" [disabled]: Firm newsletter
      - text: Firm name
      - textbox "Firm name"
      - text: Mailing address
      - textbox "Mailing address"
      - button "Change template"
      - button "Save as a template" [disabled]
      - text: Newsletter template publication does not have a verified backend contract.
- complementary "Local test fixture": Explicit local test fixture · synthetic identity and records
```

# Test source

```ts
  1  | import { expect, test, type Route } from "@playwright/test";
  2  | import { onlyLocalRequests, operationFixtures } from "./fixtures";
  3  | import { moduleRouteFixtures } from "./module-route-fixtures";
  4  | import { draft, otherId } from "../../tests/prospect-resources-fixtures";
  5  | 
  6  | const ordinary = {
  7  |   ...draft,
  8  |   prospectId: null,
  9  |   docTitle: "Synthetic ordinary document",
  10 |   config: { sections: ["Body"], sectionContent: { Body: "Stored synthetic text" } },
  11 | };
  12 | const path = `/modules/workspace?draftId=${ordinary.id}`;
  13 | 
  14 | for (const product of [null, "Newsletter"]) {
  15 |   test(`Workspace refuses a different returned ${product ?? "ordinary"} draft ID before mounting its editor`, async ({ page }) => {
  16 |     await onlyLocalRequests(page);
  17 |     await operationFixtures(page, moduleRouteFixtures);
  18 |     let wrong = true;
  19 |     const writes: string[] = [], inputs: unknown[] = [], errors: string[] = [];
  20 |     page.on("pageerror", (error) => errors.push(error.message));
  21 |     page.on("request", (request) => {
  22 |       if (new URL(request.url()).pathname.startsWith("/api/") && request.method() !== "GET") writes.push(request.url());
  23 |     });
  24 |     await page.route("**/api/capiro/workspace.draft?*", (route) => {
  25 |       inputs.push(JSON.parse(new URL(route.request().url()).searchParams.get("input")!));
  26 |       const id = wrong ? otherId : ordinary.id;
  27 |       return route.fulfill({ json: {
  28 |         ...ordinary, id,
  29 |         product: wrong ? product : null,
  30 |         docTitle: wrong ? "Wrong document must remain concealed" : ordinary.docTitle,
  31 |         documents: ordinary.documents.map((document) => ({ ...document, draftId: id })),
  32 |       } });
  33 |     });
  34 |     await page.goto(path);
> 35 |     await expect(page.getByRole("alert")).toContainText("The returned document does not match this link.");
     |                                           ^ Error: expect(locator).toContainText(expected) failed
  36 |     await expect(page.getByLabel("Document title", { exact: true })).toHaveCount(0);
  37 |     await expect(page.getByText("Wrong document must remain concealed", { exact: true })).toHaveCount(0);
  38 |     await expect(page.getByRole("button", { name: "Save draft", exact: true })).toHaveCount(0);
  39 |     expect(writes).toEqual([]);
  40 |     wrong = false;
  41 |     await page.getByRole("button", { name: "Try again", exact: true }).click();
  42 |     await expect(page.getByLabel("Document title", { exact: true })).toHaveValue(ordinary.docTitle);
  43 |     await expect(page.getByLabel("Body content", { exact: true })).toHaveValue("Stored synthetic text");
  44 |     expect(inputs).toEqual(Array(2).fill({ params: { id: ordinary.id } }));
  45 |     expect(writes).toEqual([]);
  46 |     expect(errors).toEqual([]);
  47 |   });
  48 | }
  49 | 
  50 | for (const phase of ["update", "snapshot"] as const) {
  51 |   test(`ordinary Workspace section input stays stable through held ${phase} and reopens after rejection`, async ({ page }) => {
  52 |     await onlyLocalRequests(page);
  53 |     await operationFixtures(page, { ...moduleRouteFixtures, "workspace.draft": ordinary });
  54 |     let held: Route | undefined;
  55 |     const writes: { operation: string; body: unknown }[] = [];
  56 |     for (const operation of ["update", "snapshot"] as const)
  57 |       await page.route(`**/api/capiro/workspace.draft.${operation}`, (route) => {
  58 |         writes.push({ operation, body: route.request().postDataJSON() });
  59 |         if (operation === phase) { held = route; return; }
  60 |         return route.fulfill({ json: ordinary });
  61 |       });
  62 |     await page.goto(path);
  63 |     await page.getByLabel("Body content", { exact: true }).fill("Exact submitted ordinary text");
  64 |     await page.getByRole("button", { name: "Save draft", exact: true }).click();
  65 |     await expect.poll(() => Boolean(held)).toBe(true);
  66 |     await expect(page.getByLabel("Body content", { exact: true })).toBeDisabled();
  67 |     await expect(page.getByLabel("Document title", { exact: true })).toBeDisabled();
  68 |     await held!.fulfill({ status: 400, json: { message: "Synthetic rejected save phase" } });
  69 |     await expect(page.getByRole("alert")).toContainText("Synthetic rejected save phase");
  70 |     await expect(page.getByLabel("Body content", { exact: true })).toBeEnabled();
  71 |     await expect(page.getByLabel("Body content", { exact: true })).toHaveValue("Exact submitted ordinary text");
  72 |     expect(writes[0]).toEqual({ operation: "update", body: {
  73 |       params: { id: ordinary.id }, body: { docTitle: ordinary.docTitle, config: { sectionContent: { Body: "Exact submitted ordinary text" } } },
  74 |     } });
  75 |     expect(writes.map((write) => write.operation)).toEqual(phase === "update" ? ["update"] : ["update", "snapshot"]);
  76 |   });
  77 | }
  78 | 
```