# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workspace-admission.spec.ts >> ordinary Workspace section input stays stable through held update and reopens after rejection
- Location: test/browser/workspace-admission.spec.ts:51:3

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByLabel('Body content', { exact: true })
Expected: disabled
Received: enabled
Timeout:  5000ms

Call log:
  - Expect "toBeDisabled" with timeout 5000ms
  - waiting for getByLabel('Body content', { exact: true })
    14 × locator resolved to <textarea data-slot="textarea" aria-label="Body content" class="border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:…>Exact submitted ordinary text</textarea>
       - unexpected value "enabled"

```

```yaml
- textbox "Body content": Exact submitted ordinary text
```

# Test source

```ts
  1  | import { expect, test, type Route } from "@playwright/test";
  2  | import { onlyLocalRequests, operationFixtures } from "./fixtures";
  3  | import { moduleRouteFixtures } from "./module-route-fixtures";
  4  | import { draft, otherId } from "../../tests/prospect-resources-fixtures";
  5  | 
  6  | const ordinary = {
  7  |   ...draft,
  8  |   prospectId: null,
  9  |   docTitle: "Synthetic ordinary document",
  10 |   config: { sections: ["Body"], sectionContent: { Body: "Stored synthetic text" } },
  11 | };
  12 | const path = `/modules/workspace?draftId=${ordinary.id}`;
  13 | 
  14 | for (const product of [null, "Newsletter"]) {
  15 |   test(`Workspace refuses a different returned ${product ?? "ordinary"} draft ID before mounting its editor`, async ({ page }) => {
  16 |     await onlyLocalRequests(page);
  17 |     await operationFixtures(page, moduleRouteFixtures);
  18 |     let wrong = true;
  19 |     const writes: string[] = [], inputs: unknown[] = [], errors: string[] = [];
  20 |     page.on("pageerror", (error) => errors.push(error.message));
  21 |     page.on("request", (request) => {
  22 |       if (new URL(request.url()).pathname.startsWith("/api/") && request.method() !== "GET") writes.push(request.url());
  23 |     });
  24 |     await page.route("**/api/capiro/workspace.draft?*", (route) => {
  25 |       inputs.push(JSON.parse(new URL(route.request().url()).searchParams.get("input")!));
  26 |       const id = wrong ? otherId : ordinary.id;
  27 |       return route.fulfill({ json: {
  28 |         ...ordinary, id,
  29 |         product: wrong ? product : null,
  30 |         docTitle: wrong ? "Wrong document must remain concealed" : ordinary.docTitle,
  31 |         documents: ordinary.documents.map((document) => ({ ...document, draftId: id })),
  32 |       } });
  33 |     });
  34 |     await page.goto(path);
  35 |     await expect(page.getByRole("alert")).toContainText("The returned document does not match this link.");
  36 |     await expect(page.getByLabel("Document title", { exact: true })).toHaveCount(0);
  37 |     await expect(page.getByText("Wrong document must remain concealed", { exact: true })).toHaveCount(0);
  38 |     await expect(page.getByRole("button", { name: "Save draft", exact: true })).toHaveCount(0);
  39 |     expect(writes).toEqual([]);
  40 |     wrong = false;
  41 |     await page.getByRole("button", { name: "Try again", exact: true }).click();
  42 |     await expect(page.getByLabel("Document title", { exact: true })).toHaveValue(ordinary.docTitle);
  43 |     await expect(page.getByLabel("Body content", { exact: true })).toHaveValue("Stored synthetic text");
  44 |     expect(inputs).toEqual(Array(2).fill({ params: { id: ordinary.id } }));
  45 |     expect(writes).toEqual([]);
  46 |     expect(errors).toEqual([]);
  47 |   });
  48 | }
  49 | 
  50 | for (const phase of ["update", "snapshot"] as const) {
  51 |   test(`ordinary Workspace section input stays stable through held ${phase} and reopens after rejection`, async ({ page }) => {
  52 |     await onlyLocalRequests(page);
  53 |     await operationFixtures(page, { ...moduleRouteFixtures, "workspace.draft": ordinary });
  54 |     let held: Route | undefined;
  55 |     const writes: { operation: string; body: unknown }[] = [];
  56 |     for (const operation of ["update", "snapshot"] as const)
  57 |       await page.route(`**/api/capiro/workspace.draft.${operation}`, (route) => {
  58 |         writes.push({ operation, body: route.request().postDataJSON() });
  59 |         if (operation === phase) { held = route; return; }
  60 |         return route.fulfill({ json: ordinary });
  61 |       });
  62 |     await page.goto(path);
  63 |     await page.getByLabel("Body content", { exact: true }).fill("Exact submitted ordinary text");
  64 |     await page.getByRole("button", { name: "Save draft", exact: true }).click();
  65 |     await expect.poll(() => Boolean(held)).toBe(true);
> 66 |     await expect(page.getByLabel("Body content", { exact: true })).toBeDisabled();
     |                                                                    ^ Error: expect(locator).toBeDisabled() failed
  67 |     await expect(page.getByLabel("Document title", { exact: true })).toBeDisabled();
  68 |     await held!.fulfill({ status: 400, json: { message: "Synthetic rejected save phase" } });
  69 |     await expect(page.getByRole("alert")).toContainText("Synthetic rejected save phase");
  70 |     await expect(page.getByLabel("Body content", { exact: true })).toBeEnabled();
  71 |     await expect(page.getByLabel("Body content", { exact: true })).toHaveValue("Exact submitted ordinary text");
  72 |     expect(writes[0]).toEqual({ operation: "update", body: {
  73 |       params: { id: ordinary.id }, body: { docTitle: ordinary.docTitle, config: { sectionContent: { Body: "Exact submitted ordinary text" } } },
  74 |     } });
  75 |     expect(writes.map((write) => write.operation)).toEqual(phase === "update" ? ["update"] : ["update", "snapshot"]);
  76 |   });
  77 | }
  78 | 
```