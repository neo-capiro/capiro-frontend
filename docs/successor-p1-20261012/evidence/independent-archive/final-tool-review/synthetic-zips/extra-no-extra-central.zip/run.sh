#!/bin/sh
printf synthetic\n
