Synthetic archive review
