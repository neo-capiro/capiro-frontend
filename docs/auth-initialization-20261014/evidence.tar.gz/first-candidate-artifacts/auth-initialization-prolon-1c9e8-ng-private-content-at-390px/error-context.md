# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-initialization.spec.ts >> prolonged sign-in loading offers keyboard reload without admitting private content at 390px
- Location: test/browser/auth-initialization.spec.ts:13:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 20

- Array []
+ Array [
+   Object {
+     "id": "aria-allowed-role",
+     "impact": "minor",
+     "targets": Array [
+       Array [
+         "main",
+       ],
+     ],
+   },
+   Object {
+     "id": "landmark-one-main",
+     "impact": "moderate",
+     "targets": Array [
+       Array [
+         "html",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- status [ref=e3]:
  - heading "Sign-in is taking longer than expected" [level=1] [ref=e4]
  - paragraph [ref=e5]: The sign-in service has not finished loading. Reload to try again.
  - paragraph [ref=e6]: If this continues, contact your administrator.
  - button "Reload" [ref=e7] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, type Page, type TestInfo } from "@playwright/test";
  2  | import axe from "axe-core";
  3  | 
  4  | export async function expectAccessibleHome(page: Page, testInfo: TestInfo) {
  5  |   await page.evaluate(() => document.fonts.ready);
  6  |   await page.addScriptTag({ content: axe.source });
  7  |   const result = await page.evaluate(() =>
  8  |     (window as unknown as Window & { axe: typeof axe }).axe.run(document),
  9  |   );
  10 |   await testInfo.attach("axe-full-default-results", {
  11 |     body: JSON.stringify(result, null, 2),
  12 |     contentType: "application/json",
  13 |   });
  14 |   expect(
  15 |     result.violations.map(({ id, impact, nodes }) => ({
  16 |       id,
  17 |       impact,
  18 |       targets: nodes.map((node) => node.target),
  19 |     })),
> 20 |   ).toEqual([]);
     |     ^ Error: expect(received).toEqual(expected) // deep equality
  21 |   return result;
  22 | }
  23 | 
```