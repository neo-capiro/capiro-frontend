# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-initialization.spec.ts >> prolonged sign-in loading offers keyboard reload without admitting private content at 1440px
- Location: test/browser/auth-initialization.spec.ts:13:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Sign-in is taking longer than expected', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Sign-in is taking longer than expected', exact: true })

```

```yaml
- status: Loading sign-in…
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { expectAccessibleHome } from "../accessibility";
  3  | import { onlyLocalRequests, operationFixtures, testIdentity } from "./fixtures";
  4  | 
  5  | const path = "/test-auth-initialization?providerStatus=loading";
  6  | test.beforeEach(async ({ page }) => {
  7  |   await onlyLocalRequests(page);
  8  |   await operationFixtures(page, { "me.read": testIdentity });
  9  |   await page.clock.install();
  10 | });
  11 | 
  12 | for (const width of [1440, 390]) {
  13 |   test(`prolonged sign-in loading offers keyboard reload without admitting private content at ${width}px`, async ({ page }, info) => {
  14 |     const reads: string[] = [];
  15 |     page.on("request", (request) => { if (new URL(request.url()).pathname.startsWith("/api/")) reads.push(request.url()); });
  16 |     await page.setViewportSize({ width, height: 1000 });
  17 |     await page.goto(path);
  18 |     await expect(page.getByText("Loading sign-in…", { exact: true })).toBeVisible();
  19 |     await page.clock.fastForward(15_000);
> 20 |     await expect(page.getByRole("heading", { name: "Sign-in is taking longer than expected", exact: true })).toBeVisible();
     |                                                                                                              ^ Error: expect(locator).toBeVisible() failed
  21 |     await expect(page.getByText(/contact your administrator/)).toBeVisible();
  22 |     await expect(page.getByTestId("identity")).toHaveCount(0);
  23 |     expect(reads).toEqual([]);
  24 |     await expectAccessibleHome(page, info);
  25 |     await page.screenshot({ path: info.outputPath(`auth-loading-${width}.png`), fullPage: true });
  26 |     const reload = page.getByRole("button", { name: "Reload", exact: true });
  27 |     await reload.focus();
  28 |     await expect(reload).toBeFocused();
  29 |     const navigation = page.waitForEvent("load");
  30 |     await page.keyboard.press("Enter");
  31 |     await navigation;
  32 |     await expect(page.getByText("Loading sign-in…", { exact: true })).toBeVisible();
  33 |     await expect(page.getByRole("heading", { name: "Sign-in is taking longer than expected", exact: true })).toHaveCount(0);
  34 |     expect(reads).toEqual([]);
  35 |   });
  36 | }
  37 | 
  38 | test("SDK ready disposes delayed loading state and permits only the existing protected path", async ({ page }) => {
  39 |   await page.goto(path);
  40 |   await expect(page.getByText("Loading sign-in…", { exact: true })).toBeVisible();
  41 |   await page.clock.fastForward(10_000);
  42 |   await page.evaluate(() => dispatchEvent(new CustomEvent("test:session", { detail: { providerStatus: "ready", isLoaded: true } })));
  43 |   await expect(page.getByTestId("identity")).toContainText(testIdentity.tenant.name);
  44 |   await page.clock.fastForward(20_000);
  45 |   await expect(page.getByRole("button", { name: "Reload", exact: true })).toHaveCount(0);
  46 |   await expect(page.getByTestId("identity")).toBeVisible();
  47 | });
  48 | 
  49 | test("SDK failed replaces delayed loading with the existing failure state and no private reads", async ({ page }) => {
  50 |   const reads: string[] = [];
  51 |   page.on("request", (request) => { if (new URL(request.url()).pathname.startsWith("/api/")) reads.push(request.url()); });
  52 |   await page.goto(path);
  53 |   await expect(page.getByText("Loading sign-in…", { exact: true })).toBeVisible();
  54 |   await page.clock.fastForward(15_000);
  55 |   await expect(page.getByRole("heading", { name: "Sign-in is taking longer than expected", exact: true })).toBeVisible();
  56 |   await page.evaluate(() => dispatchEvent(new CustomEvent("test:session", { detail: { providerStatus: "error", isLoaded: false } })));
  57 |   await expect(page.getByRole("heading", { name: "Sign-in unavailable", exact: true })).toBeVisible();
  58 |   await page.clock.fastForward(20_000);
  59 |   await expect(page.getByRole("heading", { name: "Sign-in is taking longer than expected", exact: true })).toHaveCount(0);
  60 |   expect(reads).toEqual([]);
  61 | });
  62 | 
```