import original from '/workspace/capiro-existing-api-feedback-20261014/apps/web/vitest.config.ts';
export default {...original,root:'/workspace/capiro-existing-api-feedback-20261014/apps/web',cacheDir:'/workspace/capiro-existing-api-feedback-evidence-20261014/vite-cache'};
