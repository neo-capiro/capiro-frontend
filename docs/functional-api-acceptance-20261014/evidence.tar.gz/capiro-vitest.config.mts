import original from '/workspace/capiro-existing-api-feedback-20261014/apps/web/src/shared/capiro/vitest.config.mts';
export default {...original,root:'/workspace/capiro-existing-api-feedback-20261014/apps/web/src/shared/capiro',cacheDir:'/workspace/capiro-existing-api-feedback-evidence-20261014/capiro-vite-cache'};
