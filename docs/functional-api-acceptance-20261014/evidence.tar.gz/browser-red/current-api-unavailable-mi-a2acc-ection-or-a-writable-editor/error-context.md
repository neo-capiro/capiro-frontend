# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: current-api-unavailable.spec.ts >> missing objective collection is unavailable, never an empty collection or a writable editor
- Location: apps/web/tests/browser/current-api-unavailable.spec.ts:34:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "The requested action or record is unavailable from the current service."
Received string:    "Cannot GET /api/backend/core/clients/10000000-0000-4000-8000-000000000001/objectivesRetry"
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('alert')
    14 × locator resolved to <div role="alert" class="status error">…</div>
       - unexpected value "Cannot GET /api/backend/core/clients/10000000-0000-4000-8000-000000000001/objectivesRetry"

```

```yaml
- alert:
  - paragraph: Cannot GET /api/backend/core/clients/10000000-0000-4000-8000-000000000001/objectives
  - button "Retry"
```

# Test source

```ts
  1   | import { expect, test, type Route } from "@playwright/test";
  2   | import { proxyRequest } from "../../src/shared/portfolio/api/proxy";
  3   | import { readConfig } from "../../src/shared/portfolio/config/config";
  4   | import { clientId, installFixtures } from "./fixtures";
  5   | import { installProfileCurrentState } from "./profile-current-state-fixtures";
  6   | 
  7   | const message =
  8   |   "The requested action or record is unavailable from the current service.";
  9   | async function unavailable(route: Route) {
  10  |   const url = new URL(route.request().url());
  11  |   const [service, ...path] = url.pathname
  12  |     .slice("/api/backend/".length)
  13  |     .split("/");
  14  |   const response = await proxyRequest(
  15  |     new Request(url),
  16  |     service!,
  17  |     path,
  18  |     readConfig({
  19  |       CORE_API_BASE_URL: "https://backend.synthetic.invalid/api",
  20  |       NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: "pk_live_c3ludGhldGljJA==",
  21  |       CLERK_SECRET_KEY: "sk_live_synthetic",
  22  |     }),
  23  |     async () => "synthetic-session-token",
  24  |     async () =>
  25  |       Response.json({ message: `Cannot GET ${url.pathname}` }, { status: 404 }),
  26  |   );
  27  |   await route.fulfill({
  28  |     status: response.status,
  29  |     body: await response.text(),
  30  |     contentType: "application/json",
  31  |   });
  32  | }
  33  | 
  34  | test("missing objective collection is unavailable, never an empty collection or a writable editor", async ({
  35  |   page,
  36  | }) => {
  37  |   const unexpected = await installFixtures(page);
  38  |   await page.route(`**/clients/${clientId}/objectives**`, unavailable);
  39  |   await page.goto(`/portfolio/${clientId}/objectives?new=1`);
> 40  |   await expect(page.getByRole("alert")).toContainText(message);
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  41  |   await expect(
  42  |     page.getByRole("button", { name: "New objective", exact: true }),
  43  |   ).toBeDisabled();
  44  |   await expect(
  45  |     page.getByText("No current objectives", { exact: true }),
  46  |   ).toHaveCount(0);
  47  |   await expect(
  48  |     page.getByRole("region", { name: "New objective", exact: true }),
  49  |   ).toHaveCount(0);
  50  |   expect(unexpected).toEqual([]);
  51  | });
  52  | 
  53  | test("missing owner source never renders an empty owner assignment", async ({
  54  |   page,
  55  | }) => {
  56  |   const { state, unexpected } = await installProfileCurrentState(page);
  57  |   state.ownersStatus = 404;
  58  |   await page.goto("/profile-current-state.html?mode=team");
  59  |   await page.getByRole("button", { name: "Manage owners" }).click();
  60  |   const dialog = page.getByRole("dialog", { name: "Owners", exact: true });
  61  |   await expect(dialog.getByRole("alert")).toContainText("Owners unavailable");
  62  |   await expect(
  63  |     dialog.getByRole("list", { name: "Ordered account owners" }),
  64  |   ).toHaveCount(0);
  65  |   await expect(
  66  |     dialog.getByRole("combobox", { name: "Primary owner", exact: true }),
  67  |   ).toHaveCount(0);
  68  |   await expect(
  69  |     dialog.getByRole("button", { name: "Save owners", exact: true }),
  70  |   ).toBeDisabled();
  71  |   await dialog.getByRole("button", { name: "Read current owners" }).click();
  72  |   await expect.poll(() => state.reads.owners).toBe(2);
  73  |   await expect(
  74  |     dialog.getByRole("list", { name: "Ordered account owners" }),
  75  |   ).toHaveCount(0);
  76  |   expect(state.writes).toEqual([]);
  77  |   expect(unexpected).toEqual([]);
  78  | });
  79  | 
  80  | test("missing effective-date feed leaves its failure visible and other calendar sources usable", async ({
  81  |   page,
  82  | }) => {
  83  |   const unexpected = await installFixtures(page);
  84  |   await page.route(
  85  |     "**/core/federal-register/effective-date-calendar?*",
  86  |     unavailable,
  87  |   );
  88  |   await page.goto("/calendar?view=agenda&date=2026-10-08");
  89  |   await expect(page.getByRole("alert")).toContainText(message);
  90  |   await expect(
  91  |     page.getByText("No events match this view", { exact: true }),
  92  |   ).toHaveCount(0);
  93  |   await expect(
  94  |     page.getByRole("heading", { name: "Master Calendar", exact: true }),
  95  |   ).toBeVisible();
  96  |   await expect(
  97  |     page.getByRole("button", { name: "New meeting", exact: true }),
  98  |   ).toBeEnabled();
  99  |   await page
  100 |     .getByRole("combobox", { name: "Calendar view", exact: true })
  101 |     .selectOption("month");
  102 |   await expect(page.getByRole("alert")).toHaveCount(0);
  103 |   expect(unexpected).toEqual([]);
  104 | });
  105 | 
```