export default Math.random;
