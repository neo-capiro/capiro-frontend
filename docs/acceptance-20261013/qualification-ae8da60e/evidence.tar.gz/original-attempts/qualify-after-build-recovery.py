import subprocess,sys,json,pathlib,hashlib,shutil,datetime
out=pathlib.Path(__file__).parent
root=pathlib.Path('/workspace/capiro-acceptance-batch-20261013')
work='/tmp/capiro-acceptance-final-runtime-20261013'
source=json.loads((out/'FROZEN-SOURCE.json').read_text())['head']
assert json.loads((out/'clean-install-exit.json').read_text())['exitCode']==0

def retire_cache(path,label):
    p=pathlib.Path(path)
    assert str(p) in ['/tmp/capiro-acceptance-final-npm-cache','/tmp/capiro-acceptance-batch-execution-20261013/apps/web/.next/cache']
    files=[]
    for f in sorted(p.rglob('*')):
        if f.is_file():files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
    receipt={'path':str(p),'scope':'Only owned reproducible download/compile cache; source, runtime and original evidence preserved.','files':files,'bytes':sum(f['bytes'] for f in files),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    shutil.rmtree(p)

def gate(name,*command):
    rc=subprocess.run([sys.executable,str(out/'run-gate.py'),name,*command],cwd=root).returncode
    if rc: raise SystemExit(rc)

assert json.loads((out/'build-recovery-exit.json').read_text())['exitCode']==0
retire_cache('/tmp/capiro-acceptance-batch-execution-20261013/apps/web/.next/cache','build-cache-retirement')
# Move already-verified root-owned archives back after build-cache retirement.
relocated=[]
for name in ['capiro-preserved-elements-files-corrected-20261013.tar.gz','capiro-preserved-elements-83f54f5a-20261013.tar.gz']:
    target=pathlib.Path('/tmp')/name
    source=pathlib.Path('/workspace/capiro-generated-preserved-20261013/historical')/name
    assert target.is_symlink() and target.resolve()==source and source.is_file()
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    temporary=target.with_name(name+'.copy')
    shutil.copyfile(source,temporary)
    assert hashlib.sha256(temporary.read_bytes()).hexdigest()==digest
    target.unlink();temporary.rename(target);source.unlink();source.symlink_to(target)
    relocated.append({'path':str(target),'alias':str(source),'sha256':digest})
(out/'post-build-archive-relocation.json').write_text(json.dumps(relocated,indent=2)+'\n')
pathlib.Path(work).mkdir(exist_ok=True)
gate('production' ,'env','PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium',f'TMPDIR={work}','ONBOARD_API_BASE_URL=','MERI_ACTION_WORKFLOW_ENABLED=','npm','run','test:production','--',str(out/'production'))
gate('served-newsletter-assets','node',str(out/'verify-assets.mjs'))
gate('actual-additions','env',f'TMPDIR={work}','node',str(out/'verify-additions-v2.mjs'))
gate('modules-browser','env','CAPIRO_QA_CHROMIUM_EXECUTABLE=/usr/bin/chromium',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/modules-browser-results.json',f'TMPDIR={work}','npm','run','test:browser:modules','--workspace','@capiro/web','--','--workers=2',f'--output={work}/acceptance-final-modules-browser-artifacts')
gate('portfolio-discovery','env',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/portfolio-discovery.json','npm','run','test:browser','--','--list')
rc=subprocess.run([sys.executable,str(out/'run-portfolio-shards.py')],cwd=root).returncode
if rc:raise SystemExit(rc)
(out/'ALL-GATES-COMPLETE.json').write_text(json.dumps({'source':source,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Offline combined gates; not native, full design, AT, musl image or deployment acceptance.'},indent=2)+'\n')
