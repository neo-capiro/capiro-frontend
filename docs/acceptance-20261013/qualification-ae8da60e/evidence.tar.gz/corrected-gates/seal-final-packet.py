import pathlib,hashlib,json,tarfile,os,datetime,subprocess
out=pathlib.Path(__file__).parent
root=pathlib.Path('/workspace/capiro-acceptance-batch-20261013')
assert (out/'ALL-GATES-COMPLETE.json').is_file()
complete=json.loads((out/'ALL-GATES-COMPLETE.json').read_text())
assert complete['verificationSource']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert json.loads((out/'portfolio-aggregate.json').read_text())['passed']==1266
assert json.loads((out/'modules-browser-recovery-results.json').read_text())['stats']['expected']==350
published=root/'docs/acceptance-20261013/qualification-ae8da60e'
published.mkdir(exist_ok=True)
archive=published/'evidence.tar.gz'
assert not archive.exists()
roots={
 'corrected-gates':out,
 'original-attempts':pathlib.Path('/workspace/capiro-unified-acceptance-final-20261013'),
 'shared-original-artifacts':pathlib.Path('/tmp/capiro-acceptance-final-runtime-20261013/acceptance-final-modules-browser-artifacts'),
 'final-browser-artifacts':pathlib.Path('/workspace/capiro-acceptance-browser-artifacts-20261013'),
 'source-review':pathlib.Path('/tmp/capiro-acceptance-source-preservation-review-20261013'),
 'infrastructure-review':pathlib.Path('/tmp/capiro-acceptance-ae8da-infra-review-20261013'),
 'dependency-preservation-review':pathlib.Path('/tmp/capiro-acceptance-dependency-preservation-addendum-20261013'),
 'final-gate-review':pathlib.Path('/tmp/capiro-acceptance-final-gate-review-20261013'),
}
members=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for label,base in roots.items():
  assert base.is_dir(),str(base)
  for p in sorted(base.rglob('*')):
   if not p.is_file() and not p.is_symlink():continue
   assert not p.is_symlink(),str(p)
   rel=f'{label}/{p.relative_to(base)}';data=p.read_bytes();h=hashlib.sha256(data).hexdigest()
   members.append({'path':rel,'source':str(p),'bytes':len(data),'sha256':h,'mode':oct(p.stat().st_mode&0o777)})
   t.add(p,arcname=rel,recursive=False)
 for label,path in [('corrected-elements','elements-corrected-20261013.tar.gz'),('original-elements','elements-final-original-20261013.tar.gz')]:
  with tarfile.open('/workspace/capiro-generated-preserved-20261013/'+path) as source:
   for name in ['elements/qualification.json','elements/runtime/process.json','elements/ssr/build.process.json','elements/ssr/discovery/build.process.json','elements/tool/linux-x64/metadata.json']:
    m=source.getmember(name);f=source.extractfile(m);data=f.read();rel=label+'/'+name
    members.append({'path':rel,'source':path+'!'+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':oct(m.mode)})
    import io
    m.name=rel;t.addfile(m,io.BytesIO(data))
with tarfile.open(archive) as t:
 actual={m.name:m for m in t.getmembers()}
 assert len(actual)==len(members)
 for record in members:assert hashlib.sha256(t.extractfile(actual[record['path']]).read()).hexdigest()==record['sha256'],record['path']
manifest={'schema':'capiro-sealed-qualification/1','verificationSource':complete['verificationSource'],'compiledApplicationSource':complete['compiledApplicationSource'],'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'memberCount':len(members),'uncompressedBytes':sum(m['bytes'] for m in members),'members':members,'scope':'Complete raw gate receipts, browser reports and artifacts, retained failed attempts, source/infra review; expanded generated package/build outputs preserved in separately verified archives bound by included manifests.'}
(published/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2))
