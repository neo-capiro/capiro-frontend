import pathlib,json,subprocess,sys,datetime
out=pathlib.Path(__file__).parent
root=pathlib.Path('/workspace/capiro-acceptance-batch-20261013')
work='/tmp/capiro-acceptance-final-runtime-20261013'
assert json.loads((out/'production-exit.json').read_text())['exitCode']==0
proof=json.loads((out/'BUILD-INSTALL-INPUT-IDENTITY.json').read_text())
for path in [proof['cleanInstallation'],proof['completedProductionBuild']]:
    result=json.loads(pathlib.Path(path).read_text());assert result['exitCode']==0 and not result['sourceChanged']
def gate(name,*cmd):
    code=subprocess.run([sys.executable,str(out/'run-gate.py'),name,*cmd],cwd=root).returncode
    if code:raise SystemExit(code)
gate('check','npm','run','check')
gate('elements','node','apps/web/deployment/portfolio/qualify-elements.mjs',str(out/'elements'))
gate('public-newsletter-browser','env','PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium','node','packages/qualification-newsletter/browser-check.mjs',str(out/'public-newsletter-browser'))
gate('served-newsletter-assets','node',str(out/'verify-assets.mjs'))
gate('actual-additions','env',f'TMPDIR={work}','node',str(out/'verify-additions-v2.mjs'))
gate('modules-browser','env','CAPIRO_QA_CHROMIUM_EXECUTABLE=/usr/bin/chromium',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/modules-browser-results.json',f'TMPDIR={work}','npm','run','test:browser:modules','--workspace','@capiro/web','--','--workers=2',f'--output={work}/acceptance-final-modules-browser-artifacts')
gate('portfolio-discovery','env',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/portfolio-discovery.json','npm','run','test:browser','--','--list')
code=subprocess.run([sys.executable,str(out/'run-portfolio-shards.py')],cwd=root).returncode
if code:raise SystemExit(code)
(out/'ALL-GATES-COMPLETE.json').write_text(json.dumps({'verificationSource':proof['verificationSource'],'compiledApplicationSource':proof['compiledApplicationSource'],'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'buildAndInstallReuse':'Byte-identical production/install inputs; exact one-line verification-only successor independently reviewed.','scope':'Combined offline gates, not native provider/authentication/Office/AT/musl/deployment acceptance.'},indent=2)+'\n')
