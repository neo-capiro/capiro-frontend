import pathlib,json,subprocess,sys,datetime
out=pathlib.Path(__file__).parent
root=pathlib.Path('/workspace/capiro-acceptance-batch-20261013')
proof=json.loads((out/'BUILD-INSTALL-INPUT-IDENTITY.json').read_text())
def gate(name,*cmd):
 code=subprocess.run([sys.executable,str(out/'run-gate.py'),name,*cmd],cwd=root).returncode
 if code:raise SystemExit(code)
for name in ['check','elements','public-newsletter-browser','served-newsletter-assets','actual-additions','production']:
 r=json.loads((out/(name+'-exit.json')).read_text());assert r['exitCode']==0 and not r['sourceChanged']
gate('modules-browser-recovery','env','CAPIRO_QA_CHROMIUM_EXECUTABLE=/usr/bin/chromium',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/modules-browser-recovery-results.json','TMPDIR=/tmp/capiro-acceptance-final-runtime-20261013','npm','run','test:browser:modules','--workspace','@capiro/web','--','--workers=2','--output=/workspace/capiro-acceptance-browser-artifacts-20261013/modules-recovery')
j=json.loads((out/'modules-browser-recovery-results.json').read_text());assert j['stats']['expected']==350 and not any(j['stats'][k] for k in ['skipped','unexpected','flaky']) and not j.get('errors')
gate('portfolio-discovery','env',f'PLAYWRIGHT_JSON_OUTPUT_FILE={out}/portfolio-discovery.json','npm','run','test:browser','--','--list')
code=subprocess.run([sys.executable,str(out/'run-portfolio-shards.py')],cwd=root).returncode
if code:raise SystemExit(code)
(out/'ALL-GATES-COMPLETE.json').write_text(json.dumps({'verificationSource':proof['verificationSource'],'compiledApplicationSource':proof['compiledApplicationSource'],'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'buildAndInstallReuse':'Byte-identical production/install inputs; exact one-line verification-only successor independently reviewed.','retainedFailures':['Original build ENOSPC before same-source recovery','Original actual-server probe locator ambiguity before verification-only correction','Shared browser first full attempt: 349 pass, one screenshot/trace ENOSPC; full same-source suite rerun after verified archival capacity recovery'],'scope':'Combined offline gates, not native provider/authentication/Office/AT/musl/deployment acceptance.'},indent=2)+'\n')
