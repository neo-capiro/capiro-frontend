from pathlib import Path
import hashlib,json,tarfile,datetime,collections,subprocess
OUT=Path(__file__).parent
RAW=Path('/workspace/capiro-unified-acceptance-corrected-20261013')
REPO=Path('/workspace/capiro-acceptance-batch-20261013')
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while chunk:=f.read(1048576):h.update(chunk)
 return h.hexdigest()
def bound(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def write(n,x): (OUT/n).write_text(json.dumps(x,indent=2)+'\n')
archive_results=[]
for name in ['inactive-next-package-archive.json','inactive-native-next-archive.json','inactive-dependency-remainder-archive.json']:
 receipt=RAW/name;x=json.loads(receipt.read_text());p=Path(x['archive']);actual={};unsupported=[]
 with tarfile.open(p,'r:gz') as tar:
  members=tar.getmembers();index={m.name:m for m in members};non_dirs=[m for m in members if not m.isdir()]
  for m in non_dirs:
   relative=m.name.split('/',1)[1]
   if m.isfile():
    h=hashlib.sha256()
    with tar.extractfile(index[m.name]) as f:
     while chunk:=f.read(1048576):h.update(chunk)
    actual[relative]={'bytes':m.size,'sha256':h.hexdigest()}
   elif m.issym():actual[relative]={'symlink':m.linkname}
   else:unsupported.append({'name':m.name,'type':str(m.type),'linkname':m.linkname})
 expected=x['members'];b=bound(p)
 result={'receipt':bound(receipt),'source':x['source'],'archive':b,'producerCompletedUTC':x['utc'],'archiveHashMatches':b['sha256']==x['sha256'],'archiveSizeMatches':b['bytes']==x['archiveBytes'],'expectedMembers':x['verifiedMembers'],'actualMembers':len(actual),'regularFiles':sum('sha256' in v for v in actual.values()),'symlinks':sum('symlink' in v for v in actual.values()),'duplicateTarPaths':len(members)-len(index),'missing':sorted(expected.keys()-actual.keys()),'unexpected':sorted(actual.keys()-expected.keys()),'mismatches':sorted(n for n in expected.keys()&actual.keys() if expected[n]!=actual[n]),'unsupported':unsupported,'allMembersExact':actual==expected}
 archive_results.append(result);print(name,len(actual),result['allMembersExact'],result['archiveHashMatches'],flush=True)
write('ARCHIVE-VERIFICATION.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Indexed tar.getmembers lookup, regular-member bytes streamed and SHA256 compared, symlink target text compared. No extraction, dependency execution or alteration.','archives':archive_results})
def cases(x):
 found=[]
 def walk(s):
  for spec in s.get('specs',[]):
   for test in spec['tests']:found.append((spec,test))
  for child in s.get('suites',[]):walk(child)
 walk(x);return found
browser=[]
allids=[]
for name in ['modules-browser-recovery','portfolio-shard-1','portfolio-shard-2']:
 p=RAW/(name+'-results.json');x=json.loads(p.read_text());rows=cases(x);r=json.loads((RAW/(name+'-exit.json')).read_text());ids=[a['id'] for a,t in rows]
 if name.startswith('portfolio'):allids.extend(ids)
 browser.append({'name':name,'results':bound(p),'log':bound(RAW/(name+'.log')),'exitReceipt':bound(RAW/(name+'-exit.json')),'receipt':r,'stats':x['stats'],'testCount':len(rows),'uniqueIds':len(set(ids)),'ids':ids,'outcomes':dict(collections.Counter(t['status'] for a,t in rows)),'retryIndices':dict(collections.Counter(v['retry'] for a,t in rows for v in t['results'])),'resultStatusCounts':dict(collections.Counter(v['status'] for a,t in rows for v in t['results'])),'timeoutCounts':dict(collections.Counter(t['timeout'] for a,t in rows)),'workers':x['config']['workers'],'projects':[{k:v.get(k) for k in ['retries','timeout','repeatEach','name']} for v in x['config']['projects']],'globalErrors':x.get('errors',[])})
 if name=='modules-browser-recovery':
  baseline=json.loads((RAW/'modules-browser-results.json').read_text());baseids={a['id'] for a,t in cases(baseline)}
  browser[-1]['sameExactIdSetAsFailedAttempt']=baseids==set(ids)
  selected=[(a,t) for a,t in rows if a['id']=='d670bbef234c16ef3571-263d7b524bcec6b5589c'];browser[-1]['previouslyAffectedCase']=selected
  art=Path('/workspace/capiro-acceptance-browser-artifacts-20261013/modules-recovery');matches=list(art.rglob('linked-task-detail.png'));browser[-1]['linkedTaskScreenshotArtifacts']=[bound(z) for z in matches]
 print(name,len(ids),dict(collections.Counter(t['status'] for a,t in rows)),flush=True)
write('COMPLETED-BROWSER-RECEIPTS.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Completed shared recovery and Portfolio shards 1/2 only; not final combined acceptance.','portfolioFirstTwoTotal':len(allids),'portfolioFirstTwoUnique':len(set(allids)),'receipts':browser})
relocations=[]
for name in ['browser-artifact-capacity.json','browser-capacity-build-archive-relocation.json','capacity-restored-after-verified-archival.json']:
 p=RAW/name;items=json.loads(p.read_text());verified=[]
 for item in items:
  a=Path(item['archive']);alias=Path(item['alias']);verified.append({'entry':item,'archiveExists':a.exists(),'aliasExists':alias.exists(),'archiveRealpath':str(a.resolve()),'aliasRealpath':str(alias.resolve()),'samefile':a.samefile(alias),'sha256':digest(a),'shaMatches':digest(a)==item['sha256']})
 relocations.append({'receipt':bound(p),'entries':verified})
write('RELOCATION-VERIFICATION.json',relocations)
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
placeholder=Path('/workspace/capiro-remaining/node_modules/ARCHIVED.json');x=json.loads(placeholder.read_text());component=json.loads((RAW/'inactive-dependency-remainder-archive.json').read_text())
identity={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'statusPorcelain':git('status','--porcelain'),'sourceTree':git('rev-parse','HEAD:apps/web/src'),'rootLock':bound(REPO/'package-lock.json'),'currentInstallation':{'path':str(REPO/'node_modules'),'realpath':str((REPO/'node_modules').resolve()),'nextPackage':bound(REPO/'node_modules/next/package.json'),'nativeNextDirectoryExists':(REPO/'node_modules/@next').is_dir(),'hasArchivePlaceholder':(REPO/'node_modules/ARCHIVED.json').exists()},'inactiveInstallation':{'path':'/workspace/capiro-remaining/node_modules','realpath':str(placeholder.parent.resolve()),'restorationReceipt':bound(placeholder),'restorationData':x,'receiptMatchesProducerExceptMembers':x=={k:v for k,v in component.items() if k!='members'}},'priorSealedInfraManifest':bound('/tmp/capiro-acceptance-ae8da-infra-review-20261013/MANIFEST.json'),'priorSealedSourceManifest':bound('/tmp/capiro-acceptance-source-preservation-review-20261013/MANIFEST.json'),'buildID':bound(REPO/'apps/web/.next/BUILD_ID')}
write('SOURCE-INSTALLATION-IDENTITY.json',identity)
print('finished',OUT,flush=True)
