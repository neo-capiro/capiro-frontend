# Dependency archival and completed-browser addendum

**Preservation verified; this is not final acceptance.** No tests, browser, server, build, install, scanner, source edit or restoration ran during this review. Prior sealed review packets remain unchanged.

The three inactive predecessor dependency archives match their producer indexes exactly after independent compressed-archive SHA256 and indexed per-member verification. There are no missing, additional, duplicate, unsupported or mismatched members.

| Inactive dependency archive | Members | Archive SHA256 |
| --- | ---: | --- |
| `installed-next-predecessor-20261013.tar.gz` | 8,688 regular files | `c498984be7747e4c440f8748ff3064e734a2090631b12d3f4ef1a927220c7dc6` |
| `installed-native-next-predecessor-20261013.tar.gz` | 84 regular files | `6925b8139fa6eaacd614f17b90513a725205e98d6357b8ee385ebecbc6132470` |
| `installed-remainder-predecessor-20261013.tar.gz` | 39,257 regular files + 52 symlinks | `9b54f9e78eb400b76e3c566107c35433b5c1ac48403763fae339d3676e2e6942` |

The 48,081 indexed members are preserved across the three archives. Symlink target text is verified; external target contents are not implied to be archived. The restoration receipt at `/workspace/capiro-remaining/node_modules/ARCHIVED.json` exactly matches the remainder producer receipt excluding its member index and identifies the required component archives. Restore remainder first, then the Next and native Next components as instructed, replacing component placeholders. No extraction or restore test was performed. The inactive tracked source/lock state is recorded separately from generated dependencies in [SOURCE-INSTALLATION-IDENTITY.json](SOURCE-INSTALLATION-IDENTITY.json).

The current candidate has a **distinct installation** at `/tmp/capiro-acceptance-batch-execution-20261013/node_modules`; Next and native Next remain present there and there is no archive placeholder. Source remains clean `ae8da60e6d63d02b65a6ff9eb71c90554f213a10`, source tree `207898a469653870d113c24139cd96c894bdef5c`. Current root-lock SHA256 remains `6acaf74b4fb676b59731245e04a6c2d54865fb71727b6f6d5f99b4cfa5e1fed7`; reused build BUILD_ID SHA256 remains `2bab56cdc59b2cc19131f81b456de80f9ef83c24527043d5cea3fa0bf61eacec`. This confirms location separation and observed retained installation inputs; it does not claim a fresh installation or independently hash every current installed dependency. All six relocation entries resolve to the same files as their aliases and independently match the recorded archive hashes.

Completed receipts under `/workspace/capiro-unified-acceptance-corrected-20261013` establish:

- `modules-browser-recovery`: **350/350 passed**, exact same ID set as the failed 349/350 attempt. All retry indexes are zero, repeatEach 1, two workers, original 30-second timeout. The previously affected case `d670bbef234c16ef3571-263d7b524bcec6b5589c` passed and saved `linked-task-detail.png` (103,891 bytes; SHA256 `12d647e416767862ad57af44e890b0a651c48dad7829cd3e69a615a98712df05`). It is a separately recorded complete recovery, not an automatic test retry. The original ENOSPC attempt remains failed and unchanged.
- Portfolio shard 1: **322/322 passed**; shard 2: **331/331 passed**. The combined 653 IDs are unique, with zero skipped, flaky, failed or global-error entries. Each ran with two workers, repeatEach 1 and retry index zero. Configured timeout remains 30 seconds; shard 2 records three explicitly declared 90-second test timeouts, with no command-level override. All completed receipts show identical clean ae8da source before/after.

See [COMPLETED-BROWSER-RECEIPTS.json](COMPLETED-BROWSER-RECEIPTS.json) for exact IDs, commands, counts and raw-input hashes. Shards 3 and 4 are outside this addendum and were not accepted while still running. Full combined acceptance awaits their completion and root's final audit release. Native authorization/provider/Office, all 337 final acceptance rows, and broader design/assistive-technology/deployment acceptance remain open.
