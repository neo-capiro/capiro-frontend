from pathlib import Path
import json,hashlib,datetime,collections,subprocess,re
OUT=Path(__file__).parent
RAW=Path('/workspace/capiro-unified-acceptance-corrected-20261013')
OLD=Path('/workspace/capiro-unified-acceptance-final-20261013')
REPO=Path('/workspace/capiro-acceptance-batch-20261013')
VERIFIER='ae8da60e6d63d02b65a6ff9eb71c90554f213a10'
COMPILED='0ba64efcd5372291d9b9cc7b8a2cd1f600c25fe6'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def bind(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(Path(p).read_text())
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
def cases(x):
 out=[]
 def walk(s):
  for a in s.get('specs',[]):
   for t in a['tests']:out.append((a,t))
  for child in s.get('suites',[]):walk(child)
 walk(x);return out
if not (RAW/'ALL-GATES-COMPLETE.json').exists():
 print('WAITING: ALL-GATES-COMPLETE.json absent; no final report or seal written.')
 raise SystemExit(0)
issues=[]
def require(ok,message):
 if not ok:issues.append(message)
completion=load(RAW/'ALL-GATES-COMPLETE.json')
receipts=[]
for n in ['check','elements','public-newsletter-browser','production','served-newsletter-assets','actual-additions','modules-browser-recovery','portfolio-discovery',*[f'portfolio-shard-{i}' for i in range(1,5)]]:
 p=RAW/(n+'-exit.json');r=load(p);receipts.append({'binding':bind(p),'receipt':r})
 require(r['exitCode']==0,n+' exit not zero')
 require(r['sourceBefore']==r['sourceAfter'] and r['sourceBefore']['head']==VERIFIER and not r['sourceBefore']['sourceDiff'] and not r['sourceChanged'],n+' source binding mismatch')
reportsets=[]
for n in ['modules-browser-recovery',*[f'portfolio-shard-{i}' for i in range(1,5)]]:
 p=RAW/(n+'-results.json');x=load(p);rows=cases(x);ids=[a['id'] for a,t in rows];runs=[v for a,t in rows for v in t['results']]
 require(len(ids)==len(set(ids)),n+' duplicate IDs')
 require(all(t['status']=='expected' and t['expectedStatus']=='passed' and len(t['results'])==1 and t['results'][0]['status']=='passed' and t['results'][0]['retry']==0 for a,t in rows),n+' unexpected/skipped/flaky/repeated outcome')
 require(not x.get('errors') and x['stats']['skipped']==0 and x['stats']['unexpected']==0 and x['stats']['flaky']==0,n+' error/skip/flaky')
 require(x['config']['workers']==2 and all(v['retries']==0 and v['repeatEach']==1 and v['timeout']==30000 for v in x['config']['projects']),n+' worker/retry/repeat/default timeout mismatch')
 reportsets.append({'name':n,'results':bind(p),'log':bind(RAW/(n+'.log')),'count':len(rows),'uniqueCount':len(set(ids)),'ids':ids,'stats':x['stats'],'workers':x['config']['workers'],'projects':[{k:v.get(k) for k in ['name','retries','repeatEach','timeout']} for v in x['config']['projects']],'testTimeoutCounts':dict(collections.Counter(t['timeout'] for a,t in rows)),'retryCounts':dict(collections.Counter(v['retry'] for v in runs)),'globalErrors':x.get('errors',[]),'testsWithStderr':sum(bool(v.get('stderr')) for v in runs)})
d=load(RAW/'portfolio-discovery.json');dr=cases(d);discovery=[a['id'] for a,t in dr];portfolio=[i for r in reportsets[1:] for i in r['ids']]
require(len(discovery)==1266 and len(set(discovery))==1266,'discovery differs from 1266 unique')
require(len(portfolio)==1266 and len(set(portfolio))==1266 and set(portfolio)==set(discovery),'four-shard ID union differs from exact discovery')
shared=reportsets[0]['ids'];original=cases(load(RAW/'modules-browser-results.json'))
require(len(shared)==350 and set(shared)=={a['id'] for a,t in original},'shared recovery IDs differ from original full 350')
save('BROWSER-ID-RECONCILIATION.json',{'discovery':bind(RAW/'portfolio-discovery.json'),'discoveryCount':len(discovery),'discoveryUnique':len(set(discovery)),'discoveryOnlyNote':'--list JSON labels listed but unexecuted cases skipped. It is an inventory, not the execution outcome. All four executed shards are checked separately.','portfolioTotal':len(portfolio),'portfolioUnique':len(set(portfolio)),'missing':sorted(set(discovery)-set(portfolio)),'extra':sorted(set(portfolio)-set(discovery)),'duplicateCount':len(portfolio)-len(set(portfolio)),'sharedMatchesOriginalFullIDSet':set(shared)=={a['id'] for a,t in original},'executedReports':reportsets})
source={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'applicationTree':git('rev-parse','HEAD:apps/web'),'sourceTree':git('rev-parse','HEAD:apps/web/src'),'status':git('status','--porcelain'),'compiledSource':COMPILED,'verifierSource':VERIFIER,'sourceDiff':git('diff',COMPILED,VERIFIER),'changedPaths':git('diff','--name-only',COMPILED,VERIFIER).splitlines(),'lock':bind(REPO/'package-lock.json'),'buildID':bind(REPO/'apps/web/.next/BUILD_ID')}
require(source['head']==VERIFIER and not source['status'],'current source is not clean exact verifier')
require(source['changedPaths']==['apps/web/tests/production/verify-meri-theme.mjs'],'compiled-source delta not exact known probe-only path')
require(source['lock']['sha256']=='6acaf74b4fb676b59731245e04a6c2d54865fb71727b6f6d5f99b4cfa5e1fed7','lock mismatch')
require(source['buildID']['sha256']=='2bab56cdc59b2cc19131f81b456de80f9ef83c24527043d5cea3fa0bf61eacec','reused BUILD_ID mismatch')
prior=load('/tmp/capiro-acceptance-source-preservation-review-20261013/PRESERVATION.json')
blobs={line.split('\t',1)[1]:line.split()[2] for line in git('ls-tree','-r','HEAD').splitlines()}
changed=[r['path'] for r in prior['originalTestBlobs'] if blobs.get(r['path'])!=r['baseBlob']]
source['originalTestCount']=len(prior['originalTestBlobs']);source['changedOriginalTests']=changed;source['ancestries']=[]
require(source['originalTestCount']==351 and not changed,'original 351 test/spec preservation mismatch')
for a in prior['sevenInputAncestries']:
 ok=subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',a['pin'],VERIFIER],capture_output=True).returncode==0
 source['ancestries'].append({'ref':a['ref'],'pin':a['pin'],'ancestor':ok});require(ok,'input ancestry missing: '+a['pin'])
source['compilationInputTrees']={n:{s:git('rev-parse',s+':'+n) for s in [COMPILED,VERIFIER]} for n in ['apps/web/src','apps/web/public','packages','vendor','apps/web/next.config.ts','apps/web/package.json','apps/web/tsconfig.json','package.json','package-lock.json']}
require(all(len(set(v.values()))==1 for v in source['compilationInputTrees'].values()),'compiled input differs')
save('SOURCE-AND-BUILD.json',source)
ledger=load('/workspace/capiro-portfolio-acceptance-map-20261013/RECONCILED-337.json')
state={'sourceLedger':bind('/workspace/capiro-portfolio-acceptance-map-20261013/RECONCILED-337.json'),'count':len(ledger),'unique':len({r['audit_id'] for r in ledger}),'states':dict(collections.Counter(r['acceptance_state'] for r in ledger)),'categories':dict(collections.Counter(r['primary_category'] for r in ledger)),'limitation':'Historical reconciliation of 90cc behavior plus separately retained post-batch delta; no whole native row is accepted by this synthetic/standalone qualification.'}
require(state['count']==337 and state['unique']==337 and state['states']=={'OPEN_FINAL_ACCEPTANCE':337},'native ledger not exactly337 open')
save('NATIVE-ACCEPTANCE-LIMIT.json',state)
failed=[('initial-build',OLD/'build-exit.json'),('initial-actual-server',OLD/'production-exit.json'),('initial-shared-browser',RAW/'modules-browser-exit.json')]
failure=[]
for n,p in failed:
 x=load(p);require(x['exitCode']!=0,n+' failed attempt was not preserved as failure');failure.append({'name':n,'binding':bind(p),'receipt':x})
build=load(OLD/'build-recovery-exit.json');initial=load(OLD/'build-exit.json')
require(build['exitCode']==0 and build['sourceBefore']==build['sourceAfter'] and build['sourceBefore']['head']==COMPILED,'build recovery binding invalid')
require(build['command']==initial['command'],'build recovery command differs')
save('GATE-RECEIPTS.json',{'completionBinding':bind(RAW/'ALL-GATES-COMPLETE.json'),'producerCompletion':completion,'successfulVerifierReceipts':receipts,'originalCleanInstallation':{'binding':bind(OLD/'clean-install-exit.json'),'receipt':load(OLD/'clean-install-exit.json')},'completedBuild':{'binding':bind(OLD/'build-recovery-exit.json'),'receipt':build},'retainedFailures':failure,'reuseIdentity':{'binding':bind(RAW/'BUILD-INSTALL-INPUT-IDENTITY.json'),'content':load(RAW/'BUILD-INSTALL-INPUT-IDENTITY.json')}})
smoke=load(RAW/'production/production-smoke.json');extra=load(RAW/'actual-additions-v2/results.json');assets=load(RAW/'actual-served-assets/asset-results.json');newsletter=load(RAW/'public-newsletter-browser/browser-results.json')
require(len(smoke['results'])==30 and not smoke['pageErrors'],'production smoke count/error mismatch')
require(extra['success'] and len(extra['http'])==23 and len(extra['assets'])==6 and len(extra['browser'])==2 and not extra['pageErrors'] and not extra['remoteRequests'],'additional actual-server receipt mismatch')
require(assets['success'] and assets['count']==179 and len(assets['entries'])==179,'asset receipt mismatch')
require(newsletter['passedCharacterizations']==116 and newsletter['passedReceivingCases']==130 and not newsletter['requests'] and not newsletter['pageErrors'],'public Newsletter browser mismatch')
check=(RAW/'check.log').read_text();summary=[l for l in check.splitlines() if re.search(r'^(?:ℹ|#) (?:tests|pass|fail|skipped|cancelled|todo) |problems \(|All matched files|Test Files|Tests +\d|"passed":8',l)]
save('OTHER-GATES.json',{'canonicalSummary':summary,'architecture':load(RAW/'architecture-summary-extracted.json'),'actualStandaloneResults':len(smoke['results']),'actualStandalonePageErrors':smoke['pageErrors'],'actualStandaloneScope':smoke['scope'],'publicBrowser':newsletter,'additionalActualServer':{k:v for k,v in extra.items() if k not in ['http','assets','browser']},'additionalCounts':{'http':len(extra['http']),'assets':len(extra['assets']),'viewports':len(extra['browser'])},'servedAssets':{'count':assets['count'],'bytes':assets['bytes'],'success':assets['success']}})
inputs=[RAW/'ALL-GATES-COMPLETE.json',RAW/'FROZEN-SOURCE.json',RAW/'REUSED-BUILD-MANIFEST.json',RAW/'REMOTE-HEADS-REFRESH.json',RAW/'check.log',RAW/'elements.log',RAW/'production/production-smoke.json',RAW/'production/preview-root-smoke.json',RAW/'actual-additions-v2/results.json',RAW/'actual-served-assets/asset-results.json',RAW/'public-newsletter-browser/browser-results.json',OLD/'clean-install.log',OLD/'build.log',OLD/'build-recovery.log',OLD/'production.log',RAW/'modules-browser.log',RAW/'modules-browser-results.json',Path('/tmp/capiro-acceptance-source-preservation-review-20261013/MANIFEST.json'),Path('/tmp/capiro-acceptance-ae8da-infra-review-20261013/MANIFEST.json'),Path('/tmp/capiro-acceptance-dependency-preservation-addendum-20261013/MANIFEST.json')]
save('INPUT-BINDINGS.json',[bind(p) for p in inputs])
save('AUDIT-STATUS.json',{'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only final checkpoint audit. No execution, installation, scanner, browser, build or source mutation.','issues':issues,'readyForBoundedAcceptance':not issues,'portfolioShardCounts':[r['count'] for r in reportsets[1:]],'sharedCount':len(shared),'nativeRowsAccepted':0})
print(json.dumps({'issues':issues,'portfolio':[r['count'] for r in reportsets[1:]],'shared':len(shared),'source':source['head']},indent=2))
